// Deriv client for the customer's browser. Talks straight to Deriv; the token never goes to our servers.
// Supports Deriv's NEW API (api.derivws.com: PAT + App ID -> account -> one-time WebSocket URL)
// and keeps the legacy app_id WebSocket as a fallback.
export const BLOCKED_SCOPES = ["payments", "admin"];
const REST = "https://api.derivws.com/trading/v1/options";
export const PUBLIC_WS = "wss://api.derivws.com/trading/v1/options/ws/public";

async function rest(path, { method = "GET", token, appId }) {
  let res;
  try {
    res = await fetch(REST + path, { method, headers: { Authorization: `Bearer ${token}`, "Deriv-App-ID": String(appId), "Content-Type": "application/json" } });
  } catch (e) {
    throw new Error("Browser could not reach Deriv's account service (network or CORS block). Send this message to support.");
  }
  let body = {}; try { body = await res.json(); } catch {}
  if (!res.ok) {
    const m = body?.errors?.[0]?.message || `HTTP ${res.status}`;
    throw new Error(res.status === 401 || res.status === 403 ? `Deriv rejected the token or App ID (${m}).` : `Deriv error: ${m}`);
  }
  return body;
}

const pick = (o, keys) => { for (const k of keys) if (o && o[k] !== undefined && o[k] !== null) return o[k]; };

export class DerivClient {
  // mode "public": no login (charts). mode "pat": new API with token + appId. mode "legacy": old app_id socket.
  constructor({ mode = "pat", appId, wsUrl, token, accountPref } = {}) {
    this.mode = mode; this.appId = appId; this.legacyUrl = wsUrl; this.token = token; this.accountPref = accountPref;
    this.nextId = 1;
    this.pending = new Map(); this.streams = new Map(); this.subIds = new Map();
    this.closed = false; this.onclose = () => {}; this.account = null; this.trace = () => {};
  }

  async _url() {
    if (this.mode === "public") return PUBLIC_WS;
    if (this.mode === "legacy") return `${this.legacyUrl}?app_id=${encodeURIComponent(this.appId)}`;
    this.trace("Asking Deriv for your accounts...");
    const list = await rest("/accounts", { token: this.token, appId: this.appId });
    const rows = Array.isArray(list?.data) ? list.data : Array.isArray(list) ? list : (list?.data?.accounts || []);
    if (!rows.length) throw new Error("No Deriv trading accounts found for this token.");
    const norm = rows.map((r) => ({
      id: pick(r, ["account_id", "accountId", "id", "loginid"]),
      type: String(pick(r, ["account_type", "type"]) || "").toLowerCase(),
      virtual: pick(r, ["is_virtual"]) === 1 || pick(r, ["is_virtual"]) === true || /demo|virtual/i.test(String(pick(r, ["account_type", "type"]) || "")) || /^VR/i.test(String(pick(r, ["account_id", "accountId", "id", "loginid"]) || "")),
      currency: pick(r, ["currency"]) || "USD",
      balance: Number(pick(r, ["balance"]) ?? 0),
    })).filter((a) => a.id);
    if (!norm.length) throw new Error("Deriv returned accounts in a format this site does not understand: " + JSON.stringify(rows[0]).slice(0, 200));
    const want = this.accountPref; // "demo" | "real"
    const chosen = norm.find((a) => (want === "real" ? !a.virtual : a.virtual)) || norm[0];
    this.account = { loginid: chosen.id, is_virtual: chosen.virtual ? 1 : 0, currency: chosen.currency, balance: chosen.balance, scopes: [] };
    this.trace(`Using account ${chosen.id} (${chosen.virtual ? "demo" : "REAL"}). Getting a one-time connection...`);
    const otp = await rest(`/accounts/${encodeURIComponent(chosen.id)}/otp`, { method: "POST", token: this.token, appId: this.appId });
    const url = otp?.data?.url || otp?.url;
    if (!url) throw new Error("Deriv did not return a connection address.");
    return url;
  }

  async connect() {
    const url = await this._url();
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(url);
      this.ws = ws;
      ws.onopen = () => resolve();
      ws.onerror = () => reject(new Error("Could not open the Deriv connection."));
      ws.onmessage = (ev) => { try { this._onMessage(JSON.parse(ev.data)); } catch {} };
      ws.onclose = () => {
        this.closed = true;
        for (const p of this.pending.values()) p.reject(new Error("Connection closed"));
        this.pending.clear();
        this.onclose();
      };
    });
  }

  _onMessage(msg) {
    const id = msg.req_id;
    if (msg.subscription && this.streams.has(id)) this.subIds.set(id, msg.subscription.id);
    const p = this.pending.get(id);
    if (p) {
      this.pending.delete(id);
      if (msg.error) p.reject(Object.assign(new Error(msg.error.message || "Deriv error"), { code: msg.error.code }));
      else p.resolve(msg);
      if (this.streams.has(id) && !msg.error) this.streams.get(id)(msg);
      return;
    }
    const h = this.streams.get(id);
    if (h) h(msg);
  }

  // The new API renamed symbol -> underlying_symbol. Strategies keep the old name; we translate.
  _fix(req) {
    if (this.mode === "legacy") return req;
    const r = { ...req };
    if ((r.proposal || r.contracts_for) && r.symbol && !r.underlying_symbol) { r.underlying_symbol = r.symbol; delete r.symbol; }
    if (r.buy && r.parameters && r.parameters.symbol && !r.parameters.underlying_symbol) { r.parameters = { ...r.parameters, underlying_symbol: r.parameters.symbol }; delete r.parameters.symbol; }
    return r;
  }

  send(req) {
    if (this.closed) return Promise.reject(new Error("Connection closed"));
    const req_id = this.nextId++;
    return new Promise((resolve, reject) => {
      this.pending.set(req_id, { resolve, reject });
      this.ws.send(JSON.stringify({ ...this._fix(req), req_id }));
    });
  }

  async subscribe(req, handler) {
    const req_id = this.nextId++;
    this.streams.set(req_id, (m) => { if (m.error) handler(null, m.error); else handler(m); });
    const first = new Promise((resolve, reject) => this.pending.set(req_id, { resolve, reject }));
    this.ws.send(JSON.stringify({ ...this._fix(req), subscribe: 1, req_id }));
    await first;
    return async () => {
      this.streams.delete(req_id);
      const sid = this.subIds.get(req_id);
      this.subIds.delete(req_id);
      if (sid && !this.closed) { try { await this.send({ forget: sid }); } catch {} }
    };
  }

  // Resolves to {loginid, currency, balance, is_virtual, scopes}. Refuses legacy tokens that can move money.
  async authorize(token) {
    if (this.mode !== "legacy") {
      try { const b = await this.send({ balance: 1 }); const v = Number(b?.balance?.balance); if (Number.isFinite(v)) this.account.balance = v; } catch {}
      return this.account;
    }
    const res = await this.send({ authorize: token });
    const a = res.authorize;
    const bad = (a.scopes || []).filter((s) => BLOCKED_SCOPES.includes(s));
    if (bad.length) { this.close(); throw new Error(`This token has the "${bad.join('", "')}" permission, which can move money. Create a new token with only Read and Trade.`); }
    return a;
  }

  close() { this.closed = true; try { this.ws.close(); } catch {} }
}
