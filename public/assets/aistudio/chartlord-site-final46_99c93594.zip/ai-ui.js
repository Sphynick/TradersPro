// The AI screen shown while an automated bot runs: scanning markets 3-2-1, market found, entry scan,
// entry found, placing trade, live trade. It only draws what the bot reports through handle(event).
// Nothing here trades. The bot places the trade the moment its entry is found; the screen only shows it.
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

export const marketName = (s) => {
  const m = /^(R_|1HZ)(\d+)V?$/.exec(s || "");
  if (!m) return s || "-";
  return m[1] === "R_" ? `Volatility ${m[2]} Index` : `Volatility ${m[2]} (1s) Index`;
};
const money = (v) => `${v >= 0 ? "+" : "-"}${Math.abs(v).toFixed(2)}`;

// Original artwork: a glowing AI core with scanning rings.
export const CORE_SVG = `<svg viewBox="0 0 220 220" class="coresvg" aria-hidden="true"><circle class="spinring" cx="110" cy="110" r="106" fill="none" stroke="#22c55e" stroke-width="4" stroke-linecap="round" stroke-dasharray="150 520"/>
 <defs><radialGradient id="cg" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#22c55e" stop-opacity=".55"/><stop offset="1" stop-color="#22c55e" stop-opacity="0"/></radialGradient></defs>
 <circle cx="110" cy="110" r="104" fill="url(#cg)"/>
 <circle class="ring r1" cx="110" cy="110" r="98" fill="none" stroke="#22c55e" stroke-width="2" stroke-dasharray="6 10"/>
 <circle class="ring r2" cx="110" cy="110" r="82" fill="none" stroke="#22d3ee" stroke-width="1.5" stroke-dasharray="40 14"/>
 <path d="M62 78 L110 52 L158 78 L158 138 L110 168 L62 138 Z" fill="#0b1224" stroke="#22c55e" stroke-width="3"/>
 <path d="M80 92 L110 76 L140 92" fill="none" stroke="#22c55e" stroke-width="2" opacity=".6"/>
 <rect x="76" y="104" width="26" height="12" rx="4" fill="#22c55e" class="eye"/><rect x="118" y="104" width="26" height="12" rx="4" fill="#22c55e" class="eye"/>
 <path d="M90 142 H130" stroke="#22d3ee" stroke-width="3" stroke-linecap="round"/><path d="M98 152 H122" stroke="#22d3ee" stroke-width="2" stroke-linecap="round" opacity=".6"/>
 <path d="M110 40 V52 M62 78 L52 72 M158 78 L168 72" stroke="#22c55e" stroke-width="3" stroke-linecap="round"/>
</svg>`;

export class AIScreen {
  // opts: {title, onStop(), accumulator: bool, symbols: [..]}
  constructor(opts) {
    this.o = opts; this.phase = "scan"; this.count = 3; this.rows = []; this.profit = null; this.session = null;
    this.queue = []; this.hold = 0; this.stopped = false; this.target = null; this.tick = null; this.pos = null;
    this.dlg = document.createElement("dialog"); this.dlg.className = "aiscreen";
    this.dlg.innerHTML = `
     <div class="aibar"><div><b>${esc(opts.title)}</b><span class="aisub2" id="aiMode">AI CORE · LIVE</span></div><button class="btn ghost" type="button" data-min>Minimize</button></div>
     <div class="aicore">
      <div class="aiside"><h4>MARKET SCAN</h4><div class="aimarkets" id="aiRows"></div></div>
      <div class="aihero">${CORE_SVG}<div class="aiphase"><div class="aicount" id="aiCount">3</div><b id="aiTitle">SCANNING MARKETS</b><span id="aiSub"></span></div></div>
      <div class="aiside"><h4>AI POSITION READ</h4><dl class="airead"><dt>MARKET</dt><dd id="aiMkt">scanning</dd><dt>CONTRACT</dt><dd id="aiCon">-</dd><dt>LIVE P/L</dt><dd id="aiPl">-</dd><dt>STAKE</dt><dd id="aiStake">-</dd></dl></div>
     </div>
     <div class="aitick" id="aiTick" hidden></div>
     <div class="ailive" id="aiLive"><i></i><span>LIVE TRADE</span><b id="aiLiveTxt">No trade yet</b></div>
     <div class="aistats" id="aiStats"></div>
     <div class="row aibtns">${opts.sellable ? `<button class="btn big sellnow" type="button" data-sell hidden>SELL NOW</button>` : ""}<button class="btn danger big" type="button" data-stop>STOP AI TRADING</button></div>`;
    document.body.append(this.dlg);
    this.dlg.addEventListener("click", (e) => {
      if (e.target.closest("[data-min]")) this.minimize();
      if (e.target.closest("[data-sell]")) { const b = this.dlg.querySelector("[data-sell]"); if (b && !b.disabled) { b.disabled = true; b.textContent = "SELLING..."; this.o.onSell?.(); } }
      if (e.target.closest("[data-stop]")) { if (this.stopped) this.destroy(); else this.o.onStop?.(); }
    });
    this.timer = setInterval(() => this.tickDown(), 1000);
    this.paintRows(); this.paintPhase(); this.dlg.showModal();
  }
  open() { if (!this.dlg.open) this.dlg.showModal(); }
  minimize() { try { this.dlg.close(); } catch {} }
  destroy() { clearInterval(this.timer); clearTimeout(this.holdT); try { this.dlg.close(); } catch {} this.dlg.remove(); this.o.onDestroy?.(); }
  $(id) { return this.dlg.querySelector("#" + id); }

  // 3-2-1 while scanning for a market or for an entry. It only counts; the bot is never delayed by it.
  tickDown() { return; if (this.phase !== "scan" && this.phase !== "wait") return; this.count = this.count <= 1 ? 3 : this.count - 1; const c = this.$("aiCount"); if (c) c.textContent = this.count; }

  handle(e) {
    if (!e || this.stopped) return;
    switch (e.type) {
      case "scan": this.rows = e.rows || []; this.paintRows(); if (this.phase === "scan") { this.count = 3; this.$("aiCount").textContent = 3; } break;
      case "ticks": this.rows = e.rows || []; this.pos = e.pos || null; this.paintRows(); this.paintTick(); break;
      case "market": this.target = e; this.show("found", "MARKET FOUND", `${marketName(e.symbol)} · ${e.label || ""}`, 1300, () => this.show("wait", "SCANNING FOR ENTRY", `${marketName(e.symbol)}`)); this.$("aiMkt").textContent = marketName(e.symbol); break;
      case "entry": this.show("entry", "ENTRY FOUND", `${marketName(e.symbol)} · ${e.label || ""}`, 900); this.$("aiMkt").textContent = marketName(e.symbol); this.$("aiCon").textContent = e.label || "-"; break;
      case "placing": this.show("placing", "PLACING TRADE", `${marketName(e.symbol)} · stake ${e.stake ?? ""}`, 700); this.$("aiStake").textContent = e.stake ?? "-"; break;
      case "placed": this.profit = 0; this.show("open", "TRADE OPEN", "A confirmed contract is being monitored until Deriv settles it."); this.$("aiLiveTxt").textContent = `${e.label || e.contract || ""} on ${marketName(e.symbol)}`; this.$("aiCon").textContent = e.label || "-"; this.$("aiStake").textContent = e.stake ?? "-"; this.$("aiPl").textContent = "0.00"; this.$("aiLive").classList.add("on"); this.sellBtn(true, 0); break;
      case "live": this.sellBtn(true, e.profit); this.profit = e.profit; this.$("aiPl").textContent = money(e.profit); this.$("aiPl").className = e.profit >= 0 ? "up" : "dn"; break;
      case "result": this.sellBtn(false); this.session = e.session; this.profit = null; this.$("aiLive").classList.remove("on"); this.$("aiLiveTxt").textContent = `${e.won ? "WON" : "LOST"} ${money(e.profit)} on ${marketName(e.symbol)}`; this.$("aiPl").textContent = money(e.profit); this.$("aiPl").className = e.won ? "up" : "dn"; this.show(e.won ? "won" : "lost", e.won ? `WON ${money(e.profit)}` : `LOST ${money(e.profit)}`, "Back to scanning", 1800, () => this.show("scan", "SCANNING MARKETS", "")); this.paintStats(); break;
      case "lost": this.show("scan", "SCANNING MARKETS", "The setup faded"); break;
    }
  }
  // Shows a phase for at least `ms`, then runs `next` (or moves on to the next queued phase).
  show(phase, title, sub, ms = 0, next) {
    this.phase = phase; this.paintPhase(title, sub);
    clearTimeout(this.holdT);
    if (ms) this.holdT = setTimeout(() => { if (next) next(); }, ms);
  }
  paintPhase(title = "SCANNING MARKETS", sub = "") {
    const t = this.$("aiTitle"), s = this.$("aiSub"), c = this.$("aiCount"); if (!t) return;
    t.textContent = title; s.textContent = sub || (this.phase === "scan" ? `Reading ${this.rows.length || 10} markets` : "");
    const counting = this.phase === "scan" || this.phase === "wait";
    c.hidden = true;
    this.dlg.dataset.phase = this.phase;
  }
  paintRows() {
    const box = this.$("aiRows"); if (!box) return;
    const list = this.rows.length ? this.rows : (this.o.symbols || []).map((symbol) => ({ symbol, score: 0, label: "reading" }));
    box.innerHTML = list.map((r) => {
      const pct = Math.round((r.score || 0) * 100), hot = r.qualifies || (r.score || 0) >= 0.5;
      return `<div class="aim ${hot ? "hot" : ""} ${this.target && this.target.symbol === r.symbol ? "pick" : ""}"><div><b>${esc(marketName(r.symbol))}</b><span>${esc(r.label || "no setup")}</span></div><div class="aibar2"><i style="width:${Math.max(3, pct)}%"></i></div></div>`;
    }).join("");
  }
  // Accumulator tick counter: the run in progress on the market being traded (or the best market being counted to entry).
  paintTick() {
    const box = this.$("aiTick"); if (!box || !this.o.accumulator) return;
    const p = this.pos, top = this.rows.find((r) => r.qualifies);
    box.hidden = false;
    if (p) box.innerHTML = `<span>TICKS IN TRADE · ${esc(marketName(p.symbol))}</span><b>${p.current} <small>/ ${p.exitAt}</small></b><div class="aibar2"><i style="width:${Math.min(100, Math.round((p.current / p.exitAt) * 100))}%"></i></div><span>Closes at ${p.exitAt} ticks</span>`;
    else if (top) box.innerHTML = `<span>COUNTING TO ENTRY · ${esc(marketName(top.symbol))}</span><b>${top.current} <small>/ 5</small></b><div class="aibar2"><i style="width:${Math.min(100, Math.round((top.current / 5) * 100))}%"></i></div><span>Last run lasted ${top.prev} ticks</span>`;
    else box.innerHTML = `<span>TICK COUNTER</span><b>-</b><span>Waiting for a run of over 15 ticks to end</span>`;
  }
  paintStats() {
    const s = this.session, b = this.$("aiStats"); if (!b || !s) return;
    b.innerHTML = `<div class="stat"><b class="${s.pnl >= 0 ? "up" : "dn"}">${money(s.pnl)}</b><span>Profit / loss</span></div><div class="stat"><b>${s.wins}</b><span>Wins</span></div><div class="stat"><b>${s.losses}</b><span>Losses</span></div><div class="stat"><b>${s.trades}</b><span>Trades</span></div>`;
  }
  // The bot has ended (stopped by you, stop loss, take profit, or the connection dropped).
  sellBtn(show, profit) { const b = this.dlg.querySelector("[data-sell]"); if (!b) return; b.hidden = !show; if (show && !b.disabled) b.textContent = `SELL NOW · ${money(profit ?? 0)}`; if (!show) { b.disabled = false; } }
  finish(reason) {
    this.stopped = true; clearInterval(this.timer); clearTimeout(this.holdT);
    this.phase = "stopped"; this.paintPhase("STOPPED", reason || "AI trading has stopped."); this.dlg.querySelector("[data-stop]").textContent = "CLOSE";
    this.$("aiMode").textContent = "AI CORE · STOPPED"; this.$("aiCount").hidden = true;
  }
}
