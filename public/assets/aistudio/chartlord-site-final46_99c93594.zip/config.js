// Edit this file after you deploy. Nothing here is secret.
export const CONFIG = {
  brand: "TRADERSPRO254",
  // Deriv: register an app at Deriv's developer dashboard, choose Read + Trade scopes only,
  // set the redirect URL to your site address, and put the App ID here.
  derivAppId: "34PK2G5ky2wwBzvxpqWV1",
  // Not verified against current Deriv docs. Change here if Deriv moves the endpoint.
  derivWs: "wss://ws.derivws.com/websockets/v3",
  derivOAuth: "https://oauth.deriv.com/oauth2/authorize",
  // Address of your Cloudflare Worker (see README). Leave empty until deployed.
  // The separate AI Analyser site (TRADERSPROMarketengine). The two sites share one login through the same Worker.
  engineUrl: "https://traderspromarketengine.samuellusava539.workers.dev",
  payApi: "https://chartlord-pay.samuellusava539.workers.dev",
  payMode: "manual",            // "manual" = Pochi only. "both" = customer picks prompt or Pochi (use once Daraja is LIVE). "stk" = prompt only.
  pochi: "0758414027",
  whatsapp: "254758414027",
  contact: "", // e.g. "https://wa.me/2547XXXXXXXX" shown on locked bots without a payUrl
};
