// News calendar helpers: impact groups, countdown, the pre-news lean and the after-release signal.
// The signal is a rule, not a prediction: nobody knows how price will react. It only follows the reaction that has already started.
export const IMPACT_GROUP = (i) => (/^(high|medium)$/i.test(i) ? "impact" : "non");
export const PAIRS = { USD: ["XAUUSD", "EURUSD", "GBPUSD", "USDJPY"], EUR: ["EURUSD"], GBP: ["GBPUSD"], JPY: ["USDJPY"], AUD: ["AUDUSD"], CAD: ["USDCAD"], NZD: ["NZDUSD"], CHF: ["USDCHF"] };
export const derivSymbol = (pair) => "frx" + pair;
const INVERSE = /unemployment|jobless|claims|deficit|inventor/i;   // for these, a higher number is bad for the currency
export function parseNum(s) {
  const m = String(s ?? "").replace(/,/g, "").match(/-?\d+(\.\d+)?/); if (!m) return null;
  let v = Number(m[0]); const u = String(s).trim().slice(-1).toUpperCase();
  if (u === "K") v *= 1e3; else if (u === "M") v *= 1e6; else if (u === "B") v *= 1e9; else if (u === "T") v *= 1e12;
  return v;
}
export function fmtCountdown(ms) {
  const neg = ms < 0, s = Math.floor(Math.abs(ms) / 1000), d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60), x = s % 60, p = (n) => String(n).padStart(2, "0");
  return (neg ? "-" : "") + (d ? d + "d " : "") + p(h) + ":" + p(m) + ":" + p(x);
}
export const WINDOW_MS = 30 * 60 * 1000;
export const eventState = (ev, now) => (now < ev.ts ? "upcoming" : now - ev.ts <= WINDOW_MS ? "live" : "past");
// which way the currency should lean if the number comes in as forecast (vs previous)
export function currencyLean(ev) {
  const f = parseNum(ev.forecast), p = parseNum(ev.previous);
  if (f == null || p == null || f === p) return { sign: 0, why: "No forecast change to lean on." };
  let sign = f > p ? 1 : -1; if (INVERSE.test(ev.title)) sign = -sign;
  const word = sign > 0 ? "stronger" : "weaker";
  return { sign, why: `${ev.title}: forecast ${ev.forecast} against ${ev.previous} before, so ${ev.country} tends to be ${word} if it prints as expected.` };
}
export function pairDir(pair, ccy, sign) { if (!sign) return 0; return pair.startsWith(ccy) ? sign : pair.endsWith(ccy) ? -sign : 0; }
export function preLean(ev) {
  const L = currencyLean(ev);
  return (PAIRS[ev.country] || []).map((pair) => {
    const dir = pairDir(pair, ev.country, L.sign), name = pair === "XAUUSD" ? "Gold" : pair;
    return { pair, dir, text: dir ? `${name} lean ${dir > 0 ? "BUY" : "SELL"}: ${L.why}${pair === "XAUUSD" ? " Gold moves the opposite way to the dollar." : ""}` : `${name}: no clear lean.` };
  });
}
// candles: [{epoch (s, candle open), open, high, low, close}] oldest first
export function reactionSignal(pair, ev, candles, now = Date.now()) {
  const rel = Math.floor(ev.ts / 1000), name = pair === "XAUUSD" ? "Gold" : pair;
  if (now < ev.ts) return { status: "wait", text: `Waiting for the release. Live signal starts at the release time.` };
  if (now - ev.ts > WINDOW_MS) return { status: "expired", text: "The 30 minute window after the release has ended. No new signal." };
  const pre = candles.filter((c) => c.epoch + 60 <= rel), post = candles.filter((c) => c.epoch >= rel - 59 && c.epoch + 60 <= now / 1000);
  if (pre.length < 5) return { status: "wait", text: "Loading prices." };
  const last = candles[candles.length - 1];
  if (!post.length) return { status: "wait", text: "Released. Waiting for the first candle to close to read the reaction." };
  const base = pre[pre.length - 1].close, w = pre.slice(-14), atr = w.reduce((a, c) => a + (c.high - c.low), 0) / w.length || 1e-9;
  const px = last.close, move = px - base, dir = move > 0 ? 1 : -1, mult = Math.abs(move) / atr;
  const mins = Math.max(1, Math.round((now - ev.ts) / 60000));
  if (mult < 2) return { status: "none", text: `${name} has moved ${move >= 0 ? "+" : ""}${move.toFixed(pair.endsWith("JPY") || pair === "XAUUSD" ? 2 : 5)} (${mult.toFixed(1)}x normal 1 minute range) in ${mins} min. Not a clear reaction yet, so no trade.` };
  const lastClosed = post[post.length - 1];
  if ((lastClosed.close - lastClosed.open) * dir <= 0) return { status: "none", text: `${name} jumped ${mult.toFixed(1)}x its normal range but the last candle went back against it. Waiting for it to settle.` };
  const ext = post.slice(-3).reduce((a, c) => (dir > 0 ? Math.min(a, c.low) : Math.max(a, c.high)), dir > 0 ? Infinity : -Infinity);
  let risk = Math.max(1.5 * atr, Math.abs(px - ext)); risk = Math.min(risk, 5 * atr);
  const dp = pair.endsWith("JPY") || pair === "XAUUSD" ? 2 : 5, f = (v) => v.toFixed(dp);
  const lean = currencyLean(ev), exp = pairDir(pair, ev.country, lean.sign);
  const agree = exp === 0 ? "" : exp === dir ? " This is the same direction as the forecast lean." : " This is against the forecast lean, which can mean the number surprised the market.";
  return { status: "signal", dir, side: dir > 0 ? "BUY" : "SELL", entry: px, sl: px - dir * risk, tp1: px + dir * 1.5 * risk, tp2: px + dir * 2.5 * risk, fmt: f,
    text: `${name} ${dir > 0 ? "rose" : "fell"} ${f(Math.abs(move))} (${mult.toFixed(1)}x its normal 1 minute range) within ${mins} min of ${ev.country} ${ev.title}, and the last closed candle confirms it. Entry follows the reaction; the stop sits ${dir > 0 ? "below" : "above"} the reaction low/high.${agree}` };
}
// The time a signal first appeared: replay the candles one close at a time and return the first close where the rule said BUY/SELL.
export function signalTime(pair, ev, candles) {
  const rel = Math.floor(ev.ts / 1000);
  for (let k = 0; k < candles.length; k++) {
    const c = candles[k]; if (c.epoch < rel - 59) continue;
    const at = (c.epoch + 60) * 1000 + 1, r = reactionSignal(pair, ev, candles.slice(0, k + 1), at);
    if (r.status === "signal") return at;
  }
  return null;
}
