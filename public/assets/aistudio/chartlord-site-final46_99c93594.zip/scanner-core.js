// Live market scanner. Shared by the Scanner tab and by the automated bots (passed to bots as ctx.lib).
// Pure signal functions work on a DigitWindow, so they can be tested without Deriv.
export const SYMBOLS = ["R_10", "R_25", "R_50", "R_75", "R_100", "1HZ10V", "1HZ25V", "1HZ50V", "1HZ75V", "1HZ100V"];

export function lastDigit(price, pip) {
  const s = Number(price).toFixed(Number.isFinite(pip) ? pip : 2);
  return Number(s[s.length - 1]);
}

export class DigitWindow {
  constructor(size = 100) { this.size = size; this.digits = []; this.prices = []; this.pip = 2; this.epoch = 0; }
  push(price, pip, epoch) {
    if (Number.isFinite(pip)) this.pip = pip;
    this.digits.push(lastDigit(price, this.pip)); this.prices.push(Number(price));
    if (this.digits.length > this.size) { this.digits.shift(); this.prices.shift(); }
    this.epoch = epoch || this.epoch;
  }
  get n() { return this.digits.length; }
  get last() { return this.digits[this.digits.length - 1]; }
  get price() { return this.prices[this.prices.length - 1]; }
  counts() { const c = Array(10).fill(0); for (const d of this.digits) c[d]++; return c; }
  pct() { const n = this.n || 1; return this.counts().map((x) => x / n); }
  share(fn, tail) { const a = tail ? this.digits.slice(-tail) : this.digits; return a.length ? a.filter(fn).length / a.length : 0; }
  // length of the run of same parity at the end, and which parity ("even" | "odd")
  parityStreak() {
    const a = this.digits; if (!a.length) return { len: 0, parity: null };
    const p = a[a.length - 1] % 2; let len = 0;
    for (let i = a.length - 1; i >= 0 && a[i] % 2 === p; i--) len++;
    return { len, parity: p ? "odd" : "even" };
  }
}

// ---- signals: each returns null or {strength, ...} ----
export function overUnderSignal(w, { min = 0.58, minTicks = 50 } = {}) {
  if (w.n < minTicks) return null;
  const under = w.share((d) => d < 5), over = 1 - under;
  const recentUnder = w.share((d) => d < 5, 20);
  if (under >= min && recentUnder >= 0.5) return { side: "under", contract: "DIGITUNDER", barrier: 8, recoveryContract: "DIGITOVER", recoveryBarrier: 4, strength: under, why: `${(under * 100).toFixed(0)}% of the last ${w.n} ticks ended under 5`, label: "Under 8" };
  if (over >= min && 1 - recentUnder >= 0.5) return { side: "over", contract: "DIGITOVER", barrier: 2, recoveryContract: "DIGITOVER", recoveryBarrier: 4, strength: over, why: `${(over * 100).toFixed(0)}% of the last ${w.n} ticks ended 5 or higher`, label: "Over 2" };
  return null;
}
export function evenOddSignal(w, { minStreak = 3, maxStreak = 4 } = {}) {
  const s = w.parityStreak();
  if (s.len < minStreak || s.len > maxStreak) return null;
  const next = s.parity === "even" ? "odd" : "even";
  return { side: next, contract: next === "odd" ? "DIGITODD" : "DIGITEVEN", barrier: null, strength: s.len / maxStreak, why: `${s.len} ${s.parity} ticks in a row, trading ${next}`, label: next === "odd" ? "Odd" : "Even" };
}
export function differsSignal(w, { minTicks = 100, maxPct = 1 } = {}) { // the least appearing digit, always; no minimum rarity
  if (w.n < minTicks) return null;
  const p = w.pct(); let d = 0; for (let i = 1; i < 10; i++) if (p[i] < p[d]) d = i;
  if (p[d] > maxPct) return null;
  return { digit: d, contract: "DIGITDIFF", barrier: d, strength: 1 - p[d], enterNow: w.last === d, why: `digit ${d} is the least appearing at ${(p[d] * 100).toFixed(0)}% of the last ${w.n} ticks. Waiting for it to print again, then Differs ${d}`, label: `Differs ${d}` };
}
export function matchesSignal(w, { minTicks = 100, minPct = 0.13 } = {}) {
  if (w.n < minTicks) return null;
  const p = w.pct(); let d = 0; for (let i = 1; i < 10; i++) if (p[i] > p[d]) d = i;
  if (p[d] < minPct) return null;
  return { digit: d, contract: "DIGITMATCH", barrier: d, strength: p[d], enterNow: w.last === d, why: `digit ${d} is the hottest at ${(p[d] * 100).toFixed(0)}% of the last ${w.n} ticks, entering when it prints`, label: `Matches ${d}` };
}
export function riseFallSignal(w, { moves = 5, need = 4 } = {}) {
  if (w.prices.length < moves + 1) return null;
  const a = w.prices.slice(-(moves + 1)); let up = 0, dn = 0;
  for (let i = 1; i < a.length; i++) { if (a[i] > a[i - 1]) up++; else if (a[i] < a[i - 1]) dn++; }
  if (up >= need) return { side: "rise", contract: "CALL", barrier: null, ticks: 5, strength: up / moves, why: `${up} of the last ${moves} ticks moved up`, label: "Rise" };
  if (dn >= need) return { side: "fall", contract: "PUT", barrier: null, ticks: 5, strength: dn / moves, why: `${dn} of the last ${moves} ticks moved down`, label: "Fall" };
  return null;
}
// ---- AI signals: the digit frequencies of the last ticks are tested against what pure chance would give. ----
const zScore = (seen, theory, n) => (seen - theory) / Math.sqrt((theory * (1 - theory)) / Math.max(1, n));

// Matches or Differs: the AI looks at the hottest digit (Matches) and the rarest digit (Differs) and takes whichever stands out more.
export function digitMatchSignal(w, { minTicks = 100, minZ = 0.9 } = {}) {
  if (w.n < minTicks) return null;
  const p = w.pct(); let hot = 0, cold = 0;
  for (let i = 1; i < 10; i++) { if (p[i] > p[hot]) hot = i; if (p[i] < p[cold]) cold = i; }
  const zHot = zScore(p[hot], 0.1, w.n), zCold = (0.1 - p[cold]) / Math.sqrt(0.09 / w.n);
  if (Math.max(zHot, zCold) < minZ) return null;
  if (zHot >= zCold) return { digit: hot, contract: "DIGITMATCH", barrier: hot, strength: Math.min(1, zHot / 4), enterNow: w.last === hot, why: `digit ${hot} is the hottest at ${(p[hot] * 100).toFixed(0)}% of the last ${w.n} ticks, entering when it prints`, label: `Matches ${hot}` };
  return { digit: cold, contract: "DIGITDIFF", barrier: cold, strength: Math.min(1, zCold / 4), enterNow: w.last === cold, why: `digit ${cold} is the rarest at ${(p[cold] * 100).toFixed(0)}% of the last ${w.n} ticks, entering when it prints`, label: `Differs ${cold}` };
}
// Over or Under with the digit chosen by the AI: every Over 1-7 and Under 2-8 is tested and the one that beats chance the most wins.
export function overUnderAISignal(w, { minTicks = 50, minZ = 1.2 } = {}) {
  if (w.n < minTicks) return null;
  let best = null;
  const tryIt = (over, b) => {
    const theory = over ? (9 - b) / 10 : b / 10, f = over ? (d) => d > b : (d) => d < b;
    const seen = w.share(f), recent = w.share(f, 20), z = zScore(seen, theory, w.n);
    if (z >= minZ && recent >= theory - 0.05 && (!best || z > best.z)) best = { z, over, b, seen, theory };
  };
  for (let b = 1; b <= 7; b++) tryIt(true, b);
  for (let b = 2; b <= 8; b++) tryIt(false, b);
  if (!best) return null;
  const c = best.over ? "DIGITOVER" : "DIGITUNDER", name = `${best.over ? "Over" : "Under"} ${best.b}`;
  return { side: best.over ? "over" : "under", contract: c, barrier: best.b, recoveryContract: c, recoveryBarrier: best.b, strength: Math.min(1, best.z / 4), why: `${name} came in ${(best.seen * 100).toFixed(0)}% of the last ${w.n} ticks (chance alone gives ${(best.theory * 100).toFixed(0)}%)`, label: name };
}
export const SIGNALS = { "digit-match": digitMatchSignal, "over-under-ai": overUnderAISignal, "over-under": overUnderSignal, "even-odd": evenOddSignal, differs: differsSignal, matches: matchesSignal, "rise-fall": riseFallSignal };

// One row per market for the AI screen: how strong the setup is (0 to 1) and what it would trade.
export function scanRows(mode, windows) {
  const fn = SIGNALS[mode], rows = [];
  for (const [symbol, w] of windows) { const sig = fn(w); rows.push({ symbol, ticks: w.n, score: sig ? Math.min(1, sig.strength) : 0, label: sig ? sig.label : null }); }
  return rows; // fixed market order so the AI screen never jumps
}
// Picks the strongest market for a mode. windows: Map(symbol -> DigitWindow).
export function bestMarket(mode, windows) {
  const fn = SIGNALS[mode]; let best = null;
  for (const [symbol, w] of windows) {
    const s = fn(w); if (s && (!best || s.strength > best.signal.strength)) best = { symbol, signal: s };
  }
  return best;
}

// Subscribes to ticks on many markets and keeps a DigitWindow for each.
export class MarketScanner {
  constructor(client, symbols = SYMBOLS, { size = 100, onTick = () => {} } = {}) {
    this.client = client; this.symbols = symbols; this.size = size; this.onTick = onTick;
    this.windows = new Map(); this.unsubs = []; this.stopped = false;
  }
  async start() {
    for (const symbol of this.symbols) {
      const w = new DigitWindow(this.size); this.windows.set(symbol, w);
      try {
        const h = await this.client.send({ ticks_history: symbol, count: this.size, end: "latest", style: "ticks" });
        const prices = h?.history?.prices || [], pip = h?.pip_size;
        for (const p of prices) w.push(p, pip);
      } catch {}
      try {
        const un = await this.client.subscribe({ ticks: symbol }, (m, err) => {
          if (this.stopped || err || !m?.tick) return;
          w.push(m.tick.quote, m.tick.pip_size, m.tick.epoch);
          this.onTick(symbol, w);
        });
        this.unsubs.push(un);
      } catch { this.windows.delete(symbol); }
    }
    return this.windows.size;
  }
  async stop() {
    this.stopped = true;
    for (const u of this.unsubs) { try { await u(); } catch {} }
    this.unsubs = [];
  }
}
