// Rule bot engine. The admin page puts a line "const RULES = {...};" in front of this file and locks the result, so the rules stay private.
// Digit contracts only (plus Rise/Fall). One real trade at a time. Every market is scanned.
export const meta = { id: "rules-bot", name: "Rule bot" };
const nextStake = ({ base, current, won, multiplier, step, maxSteps }) => (won || step >= maxSteps ? { stake: base, step: 0 } : { stake: Math.round(current * multiplier * 100) / 100, step: step + 1 });
const fires = (t, w, armed) => {
  const d = w.last; if (d === undefined) return null;
  if (t.kind === "always") return { digit: d };
  if (t.kind === "least-digit") return armed !== undefined && d === armed ? { digit: d, least: armed } : null;
  if (t.kind === "streak") { const par = t.parity === "odd" ? 1 : 0; const a = w.digits; if (a.length < t.length) return null; for (let i = a.length - t.length; i < a.length; i++) if (a[i] % 2 !== par) return null; return { digit: d }; }
  const ok = t.cmp === "gte" ? d >= t.value : t.cmp === "lte" ? d <= t.value : t.cmp === "eq" ? d === t.value : t.cmp === "ne" ? d !== t.value : (t.list || []).includes(d);
  return ok ? { digit: d } : null;
};
const leastDigit = (w) => { if (w.n < 50) return undefined; const c = w.counts(); let b = 0; for (let i = 1; i < 10; i++) if (c[i] < c[b]) b = i; return b; };
const barrierOf = (c, hit, least) => (c.barrier === "trigger" ? hit.digit : c.barrier === "least" ? least : c.barrier);
// Would the signal have won? Used for paper signals before the real trade.
const wouldWin = (c, barrier, d, p0, p1) => ({ DIGITUNDER: () => d < barrier, DIGITOVER: () => d > barrier, DIGITDIFF: () => d !== barrier, DIGITMATCH: () => d === barrier, DIGITEVEN: () => d % 2 === 0, DIGITODD: () => d % 2 === 1, CALL: () => p1 > p0, PUT: () => p1 < p0 }[c.type]());
const label = (c, b) => ({ DIGITUNDER: "Under", DIGITOVER: "Over", DIGITDIFF: "Differs", DIGITMATCH: "Matches", DIGITEVEN: "Even", DIGITODD: "Odd", CALL: "Rise", PUT: "Fall" }[c.type]) + (b !== undefined && b !== null ? " " + b : "");

export function create(ctx) {
  const R = RULES, c = ctx.config, { client, log, onState, lib } = ctx, currency = ctx.account.currency;
  const ai = (e) => { try { ctx.ai?.(e); } catch {} };
  const session = { pnl: 0, wins: 0, losses: 0, trades: 0 };
  let stake = c.stake, step = 0, lossStreak = 0, busy = false, stopped = false, scanner = null, unsub = null, virt = null, cool = 0, lastRows = 0, paper = 0;
  const armed = new Map(), ticksSince = new Map();
  const emit = () => onState({ ...session, open: busy ? "contract open" : "none", market: "scanning", running: !stopped });
  const rule = () => (step > 0 && R.recovery.enabled ? { trigger: R.recovery.trigger || R.trigger, contract: R.recovery.contract || R.contract } : { trigger: R.trigger, contract: R.contract });
  const maxSteps = () => (R.recovery.enabled ? R.recovery.maxSteps : 0);

  async function stop(reason) {
    if (stopped) return; stopped = true;
    log(reason ? `Stopped: ${reason}` : "Stopped.", reason ? "warn" : "info");
    try { await scanner?.stop(); } catch {} try { await unsub?.(); } catch {}
    emit(); ctx.finish?.();
  }
  function rows() {
    const now = Date.now(); if (now - lastRows < 400) return; lastRows = now;
    const t = rule().trigger;
    ai({ type: "scan", fixed: true, next: 0, found: false, rows: [...scanner.windows.entries()].map(([symbol, w]) => { const hit = fires(t, w, armed.get(symbol)); return { symbol, ticks: w.n, score: hit ? 1 : 0, label: w.last === undefined ? "reading" : `last digit ${w.last}${t.kind === "least-digit" ? (armed.get(symbol) !== undefined ? `, waiting for ${armed.get(symbol)}` : ", reading") : ""}${hit ? " - SIGNAL" : ""}` }; }) });
  }
  function onTick(symbol, w) {
    if (stopped) return;
    // finish the paper signal on its market
    if (virt && virt.symbol === symbol && w.n > virt.n0) {
      virt.left--; if (virt.left <= 0) {
        const won = wouldWin(virt.c, virt.barrier, w.last, virt.p0, w.price); virt = null;
        lossStreak = won ? 0 : lossStreak + 1;
        log(`Paper signal on ${symbol}: ${won ? "would have WON" : "would have LOST"}. Losing signals in a row: ${lossStreak} of ${R.gate.afterLosses}.`, "info");
        if (lossStreak >= R.gate.afterLosses) log("Gate open: the next signal is a real trade.", "ok");
      }
      return;
    }
    if (busy || virt) return;
    if (cool > 0) { cool--; return; }
    const { trigger, contract } = rule(), t = trigger;
    if (t.kind === "least-digit") { // pick the least appearing digit, then wait for it to print on a LATER tick
      const a = armed.get(symbol), n = (ticksSince.get(symbol) || 0) + 1; ticksSince.set(symbol, n);
      if (a === undefined || n > 60) { armed.set(symbol, leastDigit(w)); ticksSince.set(symbol, 0); return rows(); }
    }
    const hit = fires(t, w, armed.get(symbol));
    if (!hit) return rows();
    const barrier = barrierOf(contract, hit, armed.get(symbol));
    armed.delete(symbol);
    const real = R.gate.afterLosses === 0 || lossStreak >= R.gate.afterLosses;
    if (real) return trade(symbol, contract, barrier, hit);
    virt = { symbol, c: contract, barrier, left: contract.ticks, n0: w.n, p0: w.price }; paper++;
    log(`Paper signal on ${symbol}: ${label(contract, barrier)} (no money).`, "info");
  }
  async function trade(symbol, contract, barrier, hit) {
    if (busy || stopped) return; busy = true;
    ai({ type: "market", symbol, label: `signal, digit ${hit.digit}`, why: `${symbol}: ${label(contract, barrier)}` });
    ai({ type: "entry", symbol, label: label(contract, barrier) }); ai({ type: "placing", symbol, label: label(contract, barrier), stake });
    const parameters = { amount: stake, basis: "stake", contract_type: contract.type, currency, duration: contract.ticks, duration_unit: "t", symbol };
    if (barrier !== undefined && barrier !== null) parameters.barrier = String(barrier);
    try {
      const r = await client.send({ buy: 1, price: stake, parameters }); session.trades++;
      log(`TRADE ${symbol}: ${label(contract, barrier)}, stake ${stake} ${currency}${step ? ` (recovery step ${step})` : ""}.`, "info");
      ai({ type: "placed", symbol, label: label(contract, barrier), stake }); emit();
      unsub = await client.subscribe({ proposal_open_contract: 1, contract_id: r.buy.contract_id }, (m, err) => {
        if (err || !m) return; const p = m.proposal_open_contract;
        if (p && !p.is_sold && p.profit !== undefined) ai({ type: "live", profit: Number(p.profit) });
        if (p && p.is_sold) settle(p, symbol);
      });
    } catch (e) { log(`Buy failed: ${e.message}`, "error"); busy = false; if (/balance|insufficient/i.test(e.message)) stop("not enough balance"); }
  }
  async function settle(p, symbol) {
    if (!busy) return; const profit = Number(p.profit), un = unsub; unsub = null; try { await un?.(); } catch {}
    session.pnl = Math.round((session.pnl + profit) * 100) / 100; const won = profit > 0; won ? session.wins++ : session.losses++;
    const n = nextStake({ base: c.stake, current: stake, won, multiplier: R.recovery.multiplier, step, maxSteps: maxSteps() }); stake = n.stake; step = n.step;
    if (won || step === 0) lossStreak = 0; // back to waiting for the gate after a win (or after recovery ran out)
    log(`${won ? "WON" : "LOST"} ${profit >= 0 ? "+" : ""}${profit.toFixed(2)} ${currency}. Session ${session.pnl.toFixed(2)}.${R.gate.afterLosses && lossStreak === 0 ? " Back to waiting for losing signals." : ""}`, won ? "ok" : "warn");
    cool = R.limits.cooldownTicks; busy = false; ai({ type: "result", won, profit, symbol, session: { ...session } }); emit();
    if (c.stopLoss > 0 && session.pnl <= -c.stopLoss) return stop(`stop loss of ${c.stopLoss} ${currency} reached`);
    if (c.takeProfit > 0 && session.pnl >= c.takeProfit) return stop(`take profit of ${c.takeProfit} ${currency} reached`);
    if (R.limits.maxTrades && session.trades >= R.limits.maxTrades) return stop(`${R.limits.maxTrades} trades done`);
  }
  async function start() {
    log("Rules: " + [`${R.markets === "all" ? "all markets" : R.markets.join(", ")}`, R.gate.afterLosses ? `real trades only after ${R.gate.afterLosses} losing signals` : "trades every signal", `stake ${stake} ${currency}`].join(", ") + ".", "info"); emit();
    scanner = new lib.MarketScanner(client, R.markets === "all" ? lib.SYMBOLS : lib.SYMBOLS.filter((s) => R.markets.includes(s)), { size: 100, onTick });
    const n = await scanner.start(); if (!n) return stop("no market could be scanned");
    log(`Scanner ready on ${n} markets.`, "ok"); rows();
  }
  return { start, stop: () => stop("stopped by you") };
}
