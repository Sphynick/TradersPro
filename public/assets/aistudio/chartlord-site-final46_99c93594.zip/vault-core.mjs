// Shared by the build script (Node) and the browser. AES-256-GCM, key from PBKDF2-SHA256.
// Anything stored in site/vault is ciphertext: useless without the bot's key.
const ITER = 200000;
const enc = new TextEncoder();
const dec = new TextDecoder();

const b64 = (u8) => {
  let s = "";
  for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode(...u8.subarray(i, i + 0x8000));
  return btoa(s);
};
const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

async function deriveKey(secret, salt) {
  const base = await crypto.subtle.importKey("raw", enc.encode(secret), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", salt, iterations: ITER, hash: "SHA-256" },
    base,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"]
  );
}

export async function seal(bytes, secret) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(secret, salt);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, bytes));
  return { salt: b64(salt), iv: b64(iv), data: b64(ct) };
}

// Returns Uint8Array, or null when the secret is wrong.
export async function unseal(box, secret) {
  try {
    const key = await deriveKey(secret.trim(), unb64(box.salt));
    const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: unb64(box.iv) }, key, unb64(box.data));
    return new Uint8Array(pt);
  } catch {
    return null;
  }
}

// entry = { file, mime, box, ownerWrap }
// box holds the bot encrypted with the bot's own key.
// ownerWrap holds that key encrypted with the owner's master key.
export async function openEntry(entry, secret) {
  let bytes = await unseal(entry.box, secret);
  if (bytes) return { bytes, via: "bot-key" };
  const botKey = await unseal(entry.ownerWrap, secret);
  if (!botKey) return null;
  bytes = await unseal(entry.box, dec.decode(botKey));
  return bytes ? { bytes, via: "owner" } : null;
}

export async function sealEntry(file, mime, bytes, botKey, ownerKey) {
  return {
    file,
    mime,
    box: await seal(bytes, botKey),
    ownerWrap: await seal(enc.encode(botKey), ownerKey),
  };
}

export const text = (bytes) => dec.decode(bytes);
