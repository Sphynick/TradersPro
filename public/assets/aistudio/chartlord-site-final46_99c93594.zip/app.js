import { CONFIG } from "./config.js";
import { ITEMS, CATEGORIES, CURRENCY } from "./catalog.generated.js";
import { openEntry, sealEntry, text } from "./vault-core.mjs";
import { DerivClient } from "./deriv-client.js";
import * as LIB from "./scanner-core.js";
import { AIScreen, CORE_SVG, marketName } from "./ai-ui.js";
import * as PO from "./po-core.js";
import * as N from "./news-core.js";
import { cleanRules, describeRules, PRESETS as RULE_PRESETS, DEFAULT_RULES, CONTRACTS, NEEDS_BARRIER } from "./rules-core.js";
const pub = () => ITEMS.filter((i) => i.status === "live" && !i.hidden);
const SMART = { "over-under-auto": "over-under-ai", "even-odd-auto": "even-odd", "differs-auto": "differs", "matches-auto": "digit-match", "rise-fall-auto": "rise-fall" };

const $ = (s, r = document) => r.querySelector(s);
const el = (html) => { const t = document.createElement("template"); t.innerHTML = html.trim(); return t.content.firstChild; };
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const store = {
  get(k, d = null) { try { return localStorage.getItem("cl." + k) ?? d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem("cl." + k, v); } catch {} },
  del(k) { try { localStorage.removeItem("cl." + k); } catch {} },
};
const sess = {
  get(k) { try { return sessionStorage.getItem("cl." + k); } catch { return null; } },
  set(k, v) { try { sessionStorage.setItem("cl." + k, v); } catch {} },
  del(k) { try { sessionStorage.removeItem("cl." + k); } catch {} },
};
function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("on"); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove("on"), 3200); }

const state = { broker: "pocket", tab: "home", mode: null, cat: "all", sub: "all", run: null, preBot: null, conn: null, ai: null, autoTab: "ai", autoBot: null, autoForm: null, history: [], pnl: 0, logBuf: [] };
const TABS = { binary: [["deriv", "Deriv"], ["pocket", "Broker signals"], ["scanner", "Scanner"], ["charts", "Live charts"], ["settings", "Settings"]], forex: [["signals", "Live TRADERSPRO Signals"], ["aiscan", "AI Scanner"], ["news", "News"], ["forex", "Forex bots"], ["broker", "Broker"], ["mt5", "MT5 Control"], ["settings", "Settings"]] };
/* ---------- Account: one login for bots and signals ---------- */
const SRV = { pochi: CONFIG.pochi, whatsapp: CONFIG.whatsapp, payMode: "manual", signalsPrice: 500, aiPrice: 1000, enginePrice: 27000, paypal: "", usdtAddress: "", usdtNetwork: "TRC20", usdRate: 130, country: "", currency: null };
// Prices are held in KSh (what M-Pesa charges). The client sees dollars: whole dollars, rounded up.
const usdOf = (ksh) => String(Math.ceil(Number(ksh) / (SRV.usdRate || 130)));
const inKenya = () => !SRV.country || SRV.country === "KE"; // unknown country counts as Kenya so nobody is locked out of M-Pesa
const kshText = (ksh) => `KSh ${Number(ksh).toLocaleString()}`;
// Shown on cards: dollars everywhere, plus KSh when the client is in Kenya.
const priceText = (ksh) => `$${usdOf(ksh)}${inKenya() ? ` <span class="note">(${kshText(ksh)})</span>` : ""}`;
// Shown only after a payment method is chosen: the estimate in the client's own money (KSh in Kenya, UGX, TZS and so on elsewhere in Africa, nothing for the USA).
const localEst = (ksh) => {
  if (inKenya()) return kshText(ksh);
  const c = SRV.currency; if (!c || !(c.rate > 0)) return "";
  return `about ${c.code} ${Math.round(Number(usdOf(ksh)) * c.rate).toLocaleString()}`;
};
const me = { in: false, email: "", name: "", licenses: [], subEnd: 0 };
const tokenOf = () => store.get("acctoken") || "";
const ownerKey = () => store.get("owner");
const ENGINE_BOT = { id: "engine-ai", name: "Engine AI bot (digits)", section: "automated", status: "live", builtin: true, desc: "Uses the cloud AI engine. It trades all digit contracts (Over, Under, Even, Odd, Matches, Differs) only on markets the engine has flagged and the live ticks confirm. Fixed stake, no doubling, stops on your stop loss and take profit. Stops if the engine goes offline. Digit results are random: these are pattern triggers, not predictions, and every contract has a house edge.", how: "Log in, paste your Deriv token, choose Demo or Real, set stake and stop loss, press Start. Test on demo first." };
const unlocked = (it) => it.builtin || (it.locked && (ownerKey() || me.licenses.includes(it.id)));

function paintAcct() {
  const b = $("#acctBtn"); if (!b) return;
  b.textContent = me.in ? (me.name || me.email).split(" ")[0].slice(0, 14) : "Log in";
  b.classList.toggle("on", me.in);
  if ($("#drawer")?.classList.contains("open")) paintNav();
}
function logoutLocal() { store.del("acctoken"); Object.assign(me, { in: false, email: "", name: "", licenses: [], subEnd: 0 }); paintAcct(); if (state.booted) { state.mode = null; state.tab = "home"; render(); } }
// One place for every call to the Worker. A 401 or 403 means this login is no longer valid.
async function api(path, body, raw = false) {
  const r = await fetch(CONFIG.payApi + path, { method: body ? "POST" : "GET", headers: { "Content-Type": "application/json", "X-Token": tokenOf() }, body: body ? JSON.stringify(body) : undefined });
  let d = {}; try { d = await r.json(); } catch {}
  if ((r.status === 401 || r.status === 403) && tokenOf() && !path.startsWith("/auth/")) logoutLocal();
  if (raw) return { status: r.status, d };
  if (!r.ok) { const e = new Error(d.error || "Something went wrong."); e.status = r.status; e.data = d; throw e; }
  return d;
}
async function refreshMe() {
  if (!tokenOf()) return logoutLocal();
  try { const d = await api("/me"); Object.assign(me, { in: true, email: d.email, name: d.name, licenses: d.licenses, subEnd: d.subEnd }); } catch (e) { if (e.status !== 401 && e.status !== 403) me.in = !!me.email; }
  paintAcct();
  if (me.in && typeof engStart === "function") engStart();
}

// Login / register form, used in the dialog and inside the signals screen.
function authForm(box, onDone, note = "") {
  const done = async (d) => { store.set("acctoken", d.token); store.set("acctemail", d.email); await refreshMe(); onDone(); };
  const form = (err, mode) => {
    const reg = mode === "register";
    box.innerHTML = `<form class="form" id="acct"><h2 style="margin-top:0">${reg ? "Create your TRADERSPRO254 account" : "Log in to TRADERSPRO254"}</h2>${note ? `<p class="note">${note}</p>` : ""}
      ${reg ? `<div class="field"><label for="an">Your name</label><input id="an" autocomplete="name" required minlength="2"></div>` : ""}
      <div class="field"><label for="ae">Email</label><input id="ae" type="email" required autocomplete="email" placeholder="you@email.com" value="${esc(store.get("acctemail", ""))}"></div>
      <div class="field"><label for="ap">Password${reg ? " (8 or more characters)" : ""}</label><input id="ap" type="password" required minlength="${reg ? 8 : 1}" autocomplete="${reg ? "new-password" : "current-password"}"></div>
      <div class="row"><button class="btn big">${reg ? "Create account" : "Log in"}</button><button class="btn ghost" id="swap" type="button">${reg ? "I already have an account" : "Create an account"}</button></div><p class="note" id="aerr">${esc(err || "")}</p></form>`;
    $("#swap", box).onclick = () => form("", reg ? "login" : "register");
    $("#acct", box).onsubmit = async (e) => {
      e.preventDefault(); const em = $("#ae", box).value.trim(), pw = $("#ap", box).value; $("#aerr", box).textContent = "Please wait...";
      try {
        if (!reg) return done(await api("/auth/login", { email: em, password: pw }));
        const d = await api("/auth/register", { name: $("#an", box).value.trim(), email: em, password: pw });
        if (d.needCode) return codeForm(em);
        done(d);
      } catch (er) { if (er.data?.login) return form(er.message, "login"); if (er.data?.gone) return form(er.message, "register"); $("#aerr", box).textContent = er.message; }
    };
  };
  const codeForm = (em, err) => {
    box.innerHTML = `<form class="form" id="codeF"><h2 style="margin-top:0">Check your email</h2><p class="note">We sent a 6-digit code to <b>${esc(em)}</b>. It can take a minute. Check spam too.</p>
      <div class="field"><label for="cd">Code</label><input id="cd" inputmode="numeric" maxlength="6" autocomplete="one-time-code" required></div><button class="btn big">Confirm</button><p class="note" id="aerr">${esc(err || "")}</p></form>`;
    $("#codeF", box).onsubmit = async (e) => { e.preventDefault(); try { done(await api("/auth/verify", { email: em, code: $("#cd", box).value.trim() })); } catch (er) { if (er.data?.login) return form(er.message, "login"); $("#aerr", box).textContent = er.message; } };
  };
  form("", store.get("acctemail") ? "login" : "register");
}
function authDialog(then) {
  const dlg = el(`<dialog class="pay"><div id="adBox"></div><div class="row" style="margin-top:10px"><button class="btn ghost" id="adX" type="button">Close</button></div></dialog>`);
  document.body.append(dlg); dlg.showModal();
  const close = () => { dlg.close(); dlg.remove(); };
  $("#adX", dlg).onclick = close;
  authForm($("#adBox", dlg), () => { close(); if (then) then(); });
}
const requireLogin = (then) => (me.in ? then() : authDialog(then));
function acctMenu() {
  if (!me.in) return authDialog(() => render());
  const dlg = el(`<dialog class="pay"><h2 style="margin-top:0">${esc(me.name || "Your account")}</h2><p class="note">${esc(me.email)}</p><p class="note">Bots on this account: ${me.licenses.length}${me.subEnd > Date.now() ? ". Forex signals active." : "."}</p><div class="row"><button class="btn ghost" id="lo" type="button">Log out</button><button class="btn" id="ox" type="button">Close</button></div></dialog>`);
  document.body.append(dlg); dlg.showModal();
  const close = () => { dlg.close(); dlg.remove(); };
  $("#ox", dlg).onclick = close; $("#lo", dlg).onclick = () => { logoutLocal(); close(); render(); };
}

async function fetchEntry(id) {
  const it = ITEMS.find((i) => i.id === id);
  const r = await fetch(it?.extra ? `${CONFIG.payApi}/botfile?id=${encodeURIComponent(id)}` : `vault/${id}.json`, { cache: "no-store" });
  if (!r.ok) throw new Error("Bot file not found on the server.");
  return r.json();
}
// The server gives the bot's key only to an account that bought it. The owner opens everything with the owner key.
async function secretFor(it) {
  if (ownerKey()) return ownerKey();
  if (!me.in) throw new Error("Log in first.");
  return (await api("/license/key?bot=" + encodeURIComponent(it.id))).key;
}
async function openBot(it, entry) {
  if (ownerKey()) { const o = await openEntry(entry, ownerKey()); if (o) return o; }
  if (!me.in) throw new Error("Log in first.");
  return openEntry(entry, (await api("/license/key?bot=" + encodeURIComponent(it.id))).key);
}
async function tryOpen(it) { return openBot(it, await fetchEntry(it.id)); }

/* ---------- Deriv login (OAuth return) ---------- */
function captureOAuth() {
  const q = new URLSearchParams(location.search);
  const t = q.get("token1");
  if (t) {
    sess.set("token", t);
    sess.set("acct", q.get("acct1") || "");
    history.replaceState(null, "", location.pathname + "#automated");
  }
}

/* ---------- views ---------- */
function setTab(tab) {
  state.tab = tab; state.cat = "all"; state.sub = "all";
  if (tab === "home") state.mode = null;
  else if (tab === "signals" || tab === "aiscan" || tab === "news" || tab === "broker" || tab === "mt5" || tab === "forex") state.mode = "forex";
  else if (["deriv", "automated", "scanner", "pocket"].includes(tab)) state.mode = "binary";
  try { location.hash = tab === "home" ? "" : tab; } catch {}
  render();
}

const PARENT = { brokers: "home", signals: "home", settings: "home", deriv: "brokers", pocket: "brokers", scanner: "deriv", charts: "deriv", automated: "deriv", markets: "deriv", trades: "deriv", aiscan: "signals", news: "signals", broker: "home", mt5: "home", forex: "signals" };
function paintBack() { const b = $("#backBtn"); if (b) b.hidden = !me.in || state.tab === "home"; }
function goBack() {
  if (document.getElementById("eaFull")) return $("#eBack").click();
  if (document.querySelector("dialog.sheet")) return closeSheets();
  if (state.tab === "markets" && state.mkSec) { state.mkSec = ""; return render(); }
  setTab(PARENT[state.tab] || "home");
}
function paintNav() {
  const nav = $("#nav");
  const b = (attr, id, name) => `<button ${attr}="${id}" type="button">${name}</button>`;
  nav.innerHTML = b("data-tab", "home", "Home")
    + "<h4>Binary trading</h4>" + b("data-tab", "deriv", "Deriv bots") + b("data-tab", "pocket", "Broker signals") + b("data-tab", "scanner", "Scanner") + b("data-tab", "charts", "Live charts") + b("data-tab", "markets", "Markets") + b("data-tab", "trades", "Trades")
    + "<h4>Forex trading</h4>" + b("data-tab", "signals", "Live signals") + b("data-tab", "aiscan", "AI Scanner") + b("data-tab", "news", "Impact and non-impact news") + b("data-tab", "forex", "Forex bots") + b("data-act", "ea", "ChartLord system") + b("data-act", "ea2", "Straddle System")
    + "<h4>Tools</h4>" + b("data-tab", "mt5", "MT5 Control") + b("data-tab", "broker", "Broker account") + '<a class="navlink" href="https://app.deriv.com/account/api-token" target="_blank" rel="noopener">Get Deriv API</a>' + b("data-tab", "settings", "Settings");
  nav.querySelectorAll("button[data-tab]").forEach((b) => b.setAttribute("aria-current", String(b.dataset.tab === state.tab || (state.tab === "automated" && b.dataset.tab === "deriv"))));
  $("#drawAcct").innerHTML = me.in ? `<b>${esc(me.name || "Your account")}</b><div class="note">${esc(me.email)}</div><button class="btn ghost" data-d="out" type="button">Log out</button>` : `<b>Not logged in</b><div class="note">Log in to see your bots and signals.</div><button class="btn" data-d="in" type="button">Log in or create account</button>`;
  $("#drawFoot").innerHTML = `<a class="btn ghost" href="https://wa.me/${SRV.whatsapp}" target="_blank" rel="noopener">Chat with us on WhatsApp</a><span>Trading carries a high risk of loss. Bots do not guarantee profit.</span>`;
}
function openDrawer(on) {
  const d = $("#drawer"); d.classList.toggle("open", on); d.setAttribute("aria-hidden", String(!on)); $("#scrim").hidden = !on; $("#menuBtn").setAttribute("aria-expanded", String(on));
  if (on) paintNav();
}
const BNAV = [["deriv", "Home", "M3 11l9-8 9 8v10h-6v-6H9v6H3z"], ["markets", "Markets", "M12 3a9 9 0 100 18 9 9 0 000-18zm0 0c3 3 3 15 0 18m0-18c-3 3-3 15 0 18M3 12h18"], ["ai", "AI", ""], ["trades", "Trades", "M5 4h11a3 3 0 013 3v13H8a3 3 0 01-3-3zM9 8h6M9 12h6"], ["more", "More", "M4 7h16M4 12h16M4 17h16"]];
function paintBnav() {
  let b = $("#bnav");
  if (state.mode !== "binary") { b?.remove(); document.body.classList.remove("hasbnav"); return; }
  if (!b) { b = document.createElement("nav"); b.id = "bnav"; b.setAttribute("aria-label", "App"); document.body.append(b); }
  document.body.classList.add("hasbnav");
  const on = state.tab === "automated" ? state.autoTab : ["markets", "trades"].includes(state.tab) ? state.tab : "";
  b.innerHTML = BNAV.map(([id, n, d]) => id === "ai" ? `<button class="bai ${on === "ai" ? "on" : ""}" data-b="ai" type="button" aria-label="AI"><svg viewBox="0 0 24 24"><path d="M12 3v3M8 9h8a3 3 0 013 3v4a3 3 0 01-3 3H8a3 3 0 01-3-3v-4a3 3 0 013-3zM9 13v1M15 13v1"/></svg></button>` : `<button data-b="${id}" class="${on === id ? "on" : ""}" type="button"><svg viewBox="0 0 24 24"><path d="${d}"/></svg><span>${n}</span></button>`).join("");
  b.onclick = (e) => { const x = e.target.closest("button"); if (!x) return; const k = x.dataset.b;
    if (k === "more") return openDrawer(true);
    if (k === "deriv") return setTab("home"); // Home goes back to the Binary / Forex chooser
    if (k === "markets" || k === "trades") return setTab(k);
    state.autoTab = k; setTab("automated"); };
}
// The first thing anyone sees: log in or sign up. Nothing else shows until they do.
function viewGate(main) {
  main.append(el(`<section class="gate"><span class="badge">TRADERSPRO254</span><h1>Welcome <em>back</em></h1><p class="lede">Log in or create your account to continue.</p><div id="gateBox"></div></section>`));
  authForm($("#gateBox", main), () => { state.mode = null; state.tab = "home"; render(); });
}
function render() {
  document.body.classList.toggle("gated", !me.in); paintBack();
  if (!me.in) {
    document.documentElement.dataset.mode = "home"; paintNav(); paintBnav(); openDrawer(false);
    const g = $("#main"); g.innerHTML = ""; g.onclick = null; g.onsubmit = null; stopCharts(); stopScanner(); autoPaint = () => {}; window.scrollTo(0, 0); setBalance(null);
    return viewGate(g);
  }
  document.documentElement.dataset.mode = state.mode || "home";
  paintNav(); paintBnav(); openDrawer(false);
  const main = $("#main"); main.innerHTML = ""; main.onclick = null; main.onsubmit = null;
  stopCharts(); stopScanner(); autoPaint = () => {}; window.scrollTo(0, 0);
  if (state.conn) setBalance(state.conn.account.balance, state.conn.account.currency); else setBalance(null);
  ({ home: viewHome, brokers: viewBrokers, deriv: viewHub, forex: viewForexBots, markets: viewMarkets, trades: viewTrades, signals: viewSignalsSrc, aiscan: viewAIScan, news: viewNews, broker: viewBroker, mt5: viewMt5, automated: viewAuto, pocket: viewPocket, scanner: viewScannerSrc, charts: viewCharts, settings: viewSettings })[state.tab](main);
}

function card(it) {
  const open = unlocked(it);
  const price = it.price ? `<div class="price">${priceText(it.price)}</div>` : "";
  let action = "";
  if (it.status !== "live") action = `<span class="note">Coming soon</span>`;
  else if (open && ["xml", "file"].includes(it.kind)) action = `<button class="btn" data-dl="${it.id}">Download bot</button>${it.sub === "autosystem" ? `<button class="btn ghost" data-ea="${it.id}">Control panel</button>` : ""}`;
  else if (open) action = `<button class="btn" data-run="${it.id}">Open bot</button><span class="ok note">Unlocked</span>`;
  else {
    action = `<button class="btn" data-buy="${it.id}">Buy now</button>`;
  }
  return `<article class="card"><h3>${esc(it.name)}</h3><div class="tags"><span class="tag">${esc(it.platform)}</span>${it.sub ? `<span class="tag">${esc(it.sub)}</span>` : ""}</div><p>${esc(it.desc)}</p>${open && it.how ? `<p class="note">${esc(it.how)}</p>` : ""}${price}<div class="row">${action}</div></article>`;
}

const WA_HELP = () => `https://wa.me/${SRV.whatsapp}?text=${encodeURIComponent("Hello TRADERSPRO254, I do not know how to get my Deriv API key. Please help me.")}`;
function viewHub(main) {
  const man = pub().filter((i) => i.section === "deriv"), autos = pub().filter((i) => i.section === "automated");
  main.append(el(`<section class="hub"><span class="badge">Deriv</span><h1>Choose your <em>trading</em> mode</h1><p class="lede">Ready-made bots, or fully automated systems that trade your own Deriv account.</p>
  <div class="hubgrid">
   <button class="hubcard red" data-hub="bots" type="button"><span class="hubtag">${man.length} bots</span><h2>TRADERSPRO BOTS</h2><p>Ready-made bots you import into Deriv Bot. Pay once, download, run.</p><span class="btn">Open</span></button>
   <button class="hubcard green" data-hub="auto" type="button"><span class="hubtag">${autos.length} systems</span><h2>AUTOMATED BOTS</h2><p>Scans the markets and trades for you. Connect your Deriv API key, then press Start.</p><span class="btn">Open</span></button>
  </div></section>`));
  main.onclick = (e) => { const b = e.target.closest("[data-hub]"); if (b) openSheet(b.dataset.hub); };
}
function openSheet(kind) {
  closeSheets();
  const auto = kind === "auto", list = pub().filter((i) => i.section === (auto ? "automated" : "deriv")).sort(auto ? autoSort : () => 0);
  const dlg = el(`<dialog class="sheet ${auto ? "green" : "red"}"><div class="sheethead"><div><span class="badge">${auto ? "Automated" : "Manual bots"}</span><h2>${auto ? "TRADERSPRO Automated system" : "TRADERSPRO BOTS"}</h2></div><button class="btn ghost" data-x type="button">Close</button></div>
   ${auto ? `<p class="note">Log in, pay, and the bot unlocks on your account (you also get an email). Then open the bot, paste your Deriv API key and press Start.</p><div class="row" style="margin-bottom:12px"><a class="btn ghost" href="${WA_HELP()}" target="_blank" rel="noopener">Don't know how to put API? Chat on WhatsApp</a></div>` : `<p class="note">Pay, download the bot file and import it into Deriv Bot.</p>`}
   <div class="grid">${list.map(card).join("")}</div></dialog>`);
  document.body.append(dlg); dlg.showModal();
  dlg.onclick = (e) => { if (e.target === dlg) closeSheets(); else shopClick(e); };
}
const MT5_HOW = "Pay, download the file, then in MetaTrader 5 choose File, Open Data Folder, MQL5, Experts and paste it there. Restart MT5, drag the robot onto a chart and turn on Algo Trading.";
function viewForexBots(main) {
  const all = pub().filter((i) => i.section === "forex"), auto = all.filter((i) => i.sub === "autosystem"), list = all.filter((i) => i.sub !== "autosystem");
  main.append(el(`<section class="hub"><span class="badge">Forex bots</span>
   ${list.length ? `<h1>MT5 <em>Expert Advisors</em></h1><p class="lede">Pay once, download the robot and run it on your own MetaTrader 5. Log in to buy. Your bots stay on your account.</p><div class="grid">${list.map(card).join("")}</div>` : auto.length ? `<h1>Forex <em>bots</em></h1>` : `<h1>Forex bots <em>coming soon</em></h1><p class="lede">MT5 Expert Advisors from TRADERSPRO254 are on the way. Use the Live TRADERSPRO Signals tab in the meantime.</p>`}
   ${auto.length ? `<h2 style="margin-top:28px">Auto system <em>bots</em></h2><p class="lede">These carry my own trading system. Load one into MT5, then run it from this website: start, stop, lot size, intraday or scalping.</p><div class="grid">${auto.map(card).join("")}</div>` : ""}
   <div class="row" style="justify-content:center"><button class="btn big" data-go="signals" type="button">Open live signals</button></div></section>`));
  main.onclick = shopClick;
}

function viewShop(main) {
  const sec = state.tab;
  const isDeriv = sec === "deriv";
  const cats = CATEGORIES.deriv;
  let list = pub().filter((i) => i.section === sec || (isDeriv && i.section === "automated"));
  if (isDeriv && state.cat !== "all") list = list.filter((i) => i.category === state.cat);
  if (isDeriv && state.sub !== "all") list = list.filter((i) => i.sub === state.sub);
  const chips = isDeriv ? `<div class="chips" role="group" aria-label="Category"><button class="chip" aria-pressed="${state.cat === "all"}" data-cat="all">All</button>${cats.map((c) => `<button class="chip" aria-pressed="${state.cat === c.id}" data-cat="${c.id}">${esc(c.name)}</button>`).join("")}</div>` : "";
  const subs = isDeriv ? (cats.find((c) => c.id === state.cat)?.subs || []) : [];
  const subChips = subs.length ? `<div class="chips sub" role="group" aria-label="Digit type"><button class="chip" aria-pressed="${state.sub === "all"}" data-sub="all">Both</button>${subs.map((s) => `<button class="chip" aria-pressed="${state.sub === s.id}" data-sub="${s.id}">${esc(s.name)}</button>`).join("")}</div>` : "";
  const title = isDeriv ? "Deriv bots" : "Forex bots";
  const lede = isDeriv ? "Import into Deriv Bot, or run the automated versions from the Automated tab." : "MT5 Expert Advisors. Copy the file into MQL5/Experts, restart MT5, attach to a chart and allow algo trading.";
  main.append(el(`<div><section class="hero"><span class="badge">TRADERSPRO254 bot store</span><h1>${isDeriv ? "Automate your <em>Deriv</em> trading" : "MT5 Expert Advisors"}</h1><p class="lede">${isDeriv ? "Buy a bot, pay with M-Pesa, and it unlocks on this page. Run it on your own Deriv account with a stop loss you set." : "Pay with M-Pesa, download the Expert Advisor, load it on MT5 and let it run."}</p><div class="row"><a class="btn big" href="#bots">Browse bots</a><button class="btn ghost" data-go="charts">Live charts</button></div><ul class="perks"><li>Instant unlock after M-Pesa</li><li>Runs on your own Deriv token</li><li>Stop loss on every bot</li></ul></section><section id="bots"><h1 class="h2">${title}</h1><p class="lede">${lede}</p>${chips}${subChips}<div class="grid">${list.length ? list.map(card).join("") : `<p class="note">${isDeriv ? "Nothing in this category yet." : "No MT5 Expert Advisors are listed yet."}</p>`}</div></section></div>`));
  main.onclick = shopClick;
}

function shopClick(e) {
  const b = e.target.closest("button"); if (!b) return;
  if (b.dataset.cat) { state.cat = b.dataset.cat; state.sub = "all"; render(); }
  else if (b.dataset.sub) { state.sub = b.dataset.sub; render(); }
  else if (b.dataset.go) setTab(b.dataset.go);
  else if (b.dataset.dl) download(b.dataset.dl);
  else if (b.dataset.ea) eaPanel(b.dataset.ea);
  else if (b.dataset.buy) buyFlow(b.dataset.buy);
  else if (b.dataset.run) { closeSheets(); state.preBot = b.dataset.run; setTab("automated"); }
  else if (b.dataset.x !== undefined) closeSheets();
}
function closeSheets() { document.querySelectorAll("dialog.sheet").forEach((d) => { try { d.close(); } catch {} d.remove(); }); }
function afterUnlock(it) { closeSheets(); if (it && it.section === "automated") { state.preBot = it.id; setTab("automated"); } else render(); }

/* ---------- Buying: M-Pesa prompt, or Pochi with the pasted message ---------- */
const itemInfo = (id) => (id === "engine" ? { id: "engine", name: "Market Engine site, lifetime", price: SRV.enginePrice } : id === "signals" ? { id: "signals", name: "Forex signals, 1 week", price: SRV.signalsPrice } : id === "aiscan" ? { id: "aiscan", name: "AI Scanner, 5 signals", price: SRV.aiPrice } : ITEMS.find((i) => i.id === id));
// Orders waiting for the owner. They are remembered on the device, so the unlock still happens if the customer closes the pay window.
const pendList = () => { try { return JSON.parse(store.get("pend") || "[]"); } catch { return []; } };
const pendSave = (l) => store.set("pend", JSON.stringify(l));
let pendTimer = 0;
async function payConfirmed(botId) {
  await refreshMe();
  document.querySelectorAll("dialog.pay").forEach((d) => { try { d.close(); } catch {} d.remove(); });
  const it = itemInfo(botId); afterUnlock(it);
  const dlg = el(`<dialog class="pay"><h2 style="margin-top:0">Payment confirmed</h2><p class="note">${esc(it ? it.name : "Your purchase")} is unlocked on your account.</p><button class="btn" id="okc" type="button">OK</button></dialog>`);
  document.body.append(dlg); dlg.showModal();
  const end = () => { try { dlg.close(); } catch {} dlg.remove(); };
  $("#okc", dlg).onclick = end; setTimeout(end, 7000);
}
function watchOrders() {
  clearTimeout(pendTimer);
  const l = pendList().filter((p) => Date.now() - p.t < 3 * 86400000);
  pendSave(l); if (!l.length) return;
  pendTimer = setTimeout(async () => {
    for (const p of pendList()) {
      let s; try { s = await (await fetch(`${CONFIG.payApi}/order/status?ref=${encodeURIComponent(p.ref)}`)).json(); } catch { continue; }
      if (s.approved) { pendSave(pendList().filter((x) => x.ref !== p.ref)); await payConfirmed(p.botId); }
      else if (s.status === "rejected") { pendSave(pendList().filter((x) => x.ref !== p.ref)); document.querySelectorAll("dialog.pay").forEach((d) => { try { d.close(); } catch {} d.remove(); }); toast("We could not confirm that payment. Contact us on WhatsApp " + SRV.pochi + ", reference " + p.ref + "."); }
    }
    watchOrders();
  }, 6000);
}
const doneBtn = (dlg, close, it) => { $("#pgo", dlg).hidden = true; const c = $("#pcancel", dlg); c.textContent = "Done"; c.onclick = () => { close(); afterUnlock(it); }; };

function buyFlow(id) {
  requireLogin(() => {
    const opts = payOptions();
    if (!opts.length) return toast("Payments for your country are not set up yet. Contact us on WhatsApp.");
    if (opts.length === 1) return opts[0].go(id);
    payChoice(id, opts);
  });
}
// Every way the client can pay. Dollar options appear only when the owner has filled them in on the admin Settings page.
function payOptions() {
  const o = [];
  if (inKenya()) { // M-Pesa Pochi and the prompt work in Kenya only
    if (SRV.payMode !== "manual") o.push({ k: "prompt", label: "M-Pesa prompt on my phone", go: promptBuy });
    o.push({ k: "pochi", label: "M-Pesa Pochi (paste the message)", go: manualBuy });
  }
  if (SRV.paypal) o.push({ k: "paypal", label: "PayPal (USD)", go: (id) => cryptoBuy(id, "paypal") });
  if (SRV.usdtAddress) o.push({ k: "usdt", label: `USDT wallet (${SRV.usdtNetwork})`, go: (id) => cryptoBuy(id, "usdt") });
  return o;
}
function payChoice(id, opts) {
  const it = itemInfo(id);
  const dlg = el(`<dialog class="pay"><h2 style="margin-top:0">${esc(it.name)}</h2><p class="price">${priceText(it.price)}</p><p class="note">How do you want to pay?</p>
    <div class="row" style="flex-direction:column;align-items:stretch;gap:10px">${opts.map((o, n) => `<button class="btn ${n ? "ghost" : ""} big" data-o="${n}" type="button">${esc(o.label)}</button>`).join("")}<button class="btn ghost" id="cX" type="button">Close</button></div></dialog>`);
  document.body.append(dlg); dlg.showModal();
  const end = () => { dlg.close(); dlg.remove(); };
  dlg.onclick = (e) => { if (e.target.id === "cX") return end(); const b = e.target.closest("[data-o]"); if (b) { end(); opts[Number(b.dataset.o)].go(id); } };
}
// PayPal or USDT: the client pays in dollars, pastes the transaction ID, the owner approves in admin and the bot unlocks by itself.
function cryptoBuy(id, method) {
  const it = itemInfo(id), usd = usdOf(it.price), pp = method === "paypal";
  const to = pp ? SRV.paypal : SRV.usdtAddress;
  const dlg = el(`<dialog class="pay"><form method="dialog" id="payForm"><h2 style="margin-top:0">${esc(it.name)}</h2>
    <p class="price">$${usd}${localEst(it.price) ? ` <span class="note">(${localEst(it.price)})</span>` : ""}</p>
    <p class="note"><b>Step 1.</b> ${pp ? `Open PayPal and send <b>$${usd} USD</b> as "Friends and family" (so no fees are taken) to:` : `Send exactly <b>${usd} USDT</b> on the <b>${esc(SRV.usdtNetwork)}</b> network to this address. Any other network loses your money:`}</p>
    <div class="paybox"><code id="payTo">${esc(to)}</code><button class="btn ghost" id="cp" type="button">Copy</button></div>
    <p class="note"><b>Step 2.</b> Paste the ${pp ? "PayPal transaction ID" : "transaction hash (TXID)"} and your WhatsApp or email. Your account (${esc(me.email)}) unlocks when we confirm.</p>
    <div class="field"><label for="px">${pp ? "PayPal transaction ID" : "Transaction hash"}</label><input id="px" autocomplete="off" required></div>
    <div class="field"><label for="pw">WhatsApp number (with country code)</label><input id="pw" inputmode="tel" placeholder="+1 555 123 4567" autocomplete="tel"></div>
    <p class="note" id="pmsg"></p>
    <div class="row"><button class="btn" id="pgo">Submit payment</button><button class="btn ghost" id="pcancel" type="button">Close</button></div></form></dialog>`);
  document.body.append(dlg); dlg.showModal();
  const close = () => { dlg.close(); dlg.remove(); };
  $("#pcancel", dlg).onclick = close;
  $("#cp", dlg).onclick = () => { try { navigator.clipboard.writeText(to); toast("Copied."); } catch { toast(to); } };
  $("#payForm", dlg).onsubmit = async (e) => {
    e.preventDefault(); const msg = $("#pmsg", dlg), go = $("#pgo", dlg); go.disabled = true; msg.textContent = "Sending your payment details...";
    try {
      const d = await api("/order", { botId: id, method, proof: $("#px", dlg).value, whatsapp: $("#pw", dlg).value });
      msg.textContent = 'Received. We are confirming your payment, usually within minutes. It unlocks by itself and you will see "Payment confirmed".';
      pendSave([...pendList(), { ref: d.ref, botId: id, t: Date.now() }]); watchOrders(); go.hidden = true;
    } catch (err) { msg.textContent = err.message; go.disabled = false; }
  };
}
function manualBuy(id) {
  const it = itemInfo(id);
  const dlg = el(`<dialog class="pay"><form method="dialog" id="payForm"><h2 style="margin-top:0">${esc(it.name)}</h2>
    <p class="price">$${usdOf(it.price)} <span class="note">(about ${kshText(it.price)})</span></p>
    <p class="note"><b>Step 1.</b> Open M-Pesa, choose <b>Pochi la Biashara</b>, and send <b>${CURRENCY} ${Number(it.price).toLocaleString()}</b> to <b>${esc(SRV.pochi)}</b>. <button class="btn ghost" id="cp" type="button">Copy number</button></p>
    <p class="note"><b>Step 2.</b> Add your WhatsApp number and paste the M-Pesa confirmation message you got. Your account (${esc(me.email)}) is unlocked once we confirm.</p>
    <div class="field"><label for="pw">Your WhatsApp number</label><input id="pw" inputmode="tel" placeholder="0712345678" autocomplete="tel" required></div>
    <div class="field"><label for="pm">Paste the M-Pesa message</label><textarea id="pm" rows="4" placeholder="UKB1ABCD2E Confirmed. Ksh..." required></textarea></div>
    <p class="note" id="pmsg"></p>
    <div class="row"><button class="btn" id="pgo">Submit payment</button><button class="btn ghost" id="pcancel" type="button">Close</button></div></form></dialog>`);
  document.body.append(dlg); dlg.showModal();
  let stop = false;
  const close = () => { stop = true; dlg.close(); dlg.remove(); };
  $("#pcancel", dlg).onclick = close;
  $("#cp", dlg).onclick = () => { try { navigator.clipboard.writeText(SRV.pochi); toast("Copied."); } catch { toast(SRV.pochi); } };
  $("#payForm", dlg).onsubmit = async (e) => {
    e.preventDefault();
    const msg = $("#pmsg", dlg), go = $("#pgo", dlg);
    go.disabled = true; msg.textContent = "Sending your payment details...";
    const wa = $("#pw", dlg).value, mp = $("#pm", dlg).value;
    try {
      const d = await api("/order", { botId: id, whatsapp: wa, mpesa: mp });
      const text = `NEW ORDER ${d.ref}\nProduct: ${it.name}\nPrice: ${CURRENCY} ${it.price}\nAccount: ${me.email}\nCustomer WhatsApp: ${wa}\n\nM-Pesa message:\n${mp}`;
      const link = `https://wa.me/${SRV.whatsapp}?text=${encodeURIComponent(text)}`;
      msg.innerHTML = `Received. We are confirming your payment, usually within minutes. It unlocks by itself when we confirm, and you will see "Payment confirmed". <a href="${link}" target="_blank" rel="noopener">Tap here to also send the details on WhatsApp</a>.`;
      try { window.open(link, "_blank", "noopener"); } catch {}
      pendSave([...pendList(), { ref: d.ref, botId: id, t: Date.now() }]); watchOrders();
      $("#pgo", dlg).hidden = true;
    } catch (err) { msg.textContent = err.message; go.disabled = false; }
  };
}
function promptBuy(id) {
  const it = itemInfo(id);
  const dlg = el(`<dialog class="pay"><form method="dialog" id="payForm"><h2 style="margin-top:0">${esc(it.name)}</h2>
    <p class="price">$${usdOf(it.price)} <span class="note">(about ${kshText(it.price)})</span></p>
    <div class="field"><label for="pp">M-Pesa phone</label><input id="pp" inputmode="tel" placeholder="0712345678" autocomplete="tel" required></div>
    <p class="note" id="pmsg">You get an M-Pesa prompt on your phone. Enter your PIN. When Safaricom confirms, your account (${esc(me.email)}) unlocks here and we email you.</p>
    <div class="row"><button class="btn" id="pgo">Pay ${CURRENCY} ${it.price}</button><button class="btn ghost" id="pcancel" type="button">Close</button></div></form></dialog>`);
  document.body.append(dlg); dlg.showModal();
  let stop = false;
  const close = () => { stop = true; dlg.close(); dlg.remove(); };
  $("#pcancel", dlg).onclick = close;
  $("#payForm", dlg).onsubmit = async (e) => {
    e.preventDefault();
    const msg = $("#pmsg", dlg), go = $("#pgo", dlg);
    go.disabled = true; msg.textContent = "Sending the M-Pesa prompt...";
    try {
      const d = await api("/charge", { botId: id, phone: $("#pp", dlg).value });
      msg.textContent = d.message + " Waiting for payment...";
      for (let i = 0; i < 60 && !stop; i++) {
        await new Promise((ok) => setTimeout(ok, 4000));
        let s; try { s = await (await fetch(`${CONFIG.payApi}/status?ref=${encodeURIComponent(d.reference)}`)).json(); } catch { msg.textContent = "Checking your payment... (network is slow, still trying)"; continue; }
        if (s.error) throw new Error(s.error);
        if (s.paid) { await refreshMe(); doneBtn(dlg, close, it); msg.textContent = id === "aiscan" ? "Paid. 5 AI scanner signals were added to your account." : id === "signals" ? "Paid. Your signals are unlocked for 1 week." : "Paid. The bot is now unlocked on your account. A confirmation email is on its way."; return; }
        if (s.final) throw new Error(`Payment was not completed (${s.status || "no reason given"}). If M-Pesa took your money, send the M-Pesa message and reference ${d.reference} to us on WhatsApp ${SRV.pochi}.`);
      }
      if (!stop) throw new Error(`Still waiting. If M-Pesa took your money, contact the seller with reference ${d.reference}.`);
    } catch (err) {
      msg.textContent = err.message; go.disabled = false;
      const b = el(`<button class="btn ghost" type="button">Pay to Pochi and paste the message instead</button>`); b.onclick = () => { close(); manualBuy(id); }; msg.append(" ", b);
    }
  };
}

async function download(id) {
  const it = ITEMS.find((i) => i.id === id);
  try {
    const entry = await fetchEntry(id);
    const out = await openBot(it, entry);
    if (!out) { toast("Could not open this bot. Contact support."); return; }
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([out.bytes], { type: entry.mime }));
    a.download = entry.file; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  } catch (err) { toast(err.message); }
}

/* ---------- Automated ---------- */
const PRESET_OPTS = [["over-under", "Over"], ["under", "Under"], ["differs", "Differs"], ["matches", "Matches"], ["even", "Even"], ["odd", "Odd"], ["rise", "Rise"], ["fall", "Fall"]];
const SYMS = ["R_10", "R_25", "R_50", "R_75", "R_100", "1HZ10V", "1HZ25V", "1HZ50V", "1HZ75V", "1HZ100V"];

const HAS_APPID = !!CONFIG.derivAppId && CONFIG.derivAppId !== "1089";
function showHist() {
  const h = $("#hist"); if (!h) return;
  h.innerHTML = state.history.length ? state.history.slice(0, 60).map((x) => `<div class="hrow ${x.won ? "w" : "l"}"><span>${new Date(x.t).toLocaleTimeString()}</span><b>${esc(marketName(x.symbol))}</b><em>${x.won ? "WON" : "LOST"} ${money(x.profit)}</em></div>`).join("") : `<p class="note">No trades yet.</p>`;
}
const ACC = ["killer", "ninja"]; // accumulator bots
const isRuleBot = (it) => !!it && (it.sub === "rules" || !!it.builtin); // bots built in admin Bot Studio
const TOUCH = { "under-auto": "under", "over-auto": "over" }; // Over and Under touch bots
const AUTO_ORDER = ["matches-auto", "under-auto", "over-auto", "over-under-auto", "even-odd-auto", "killer", "ninja"];
const autoSort = (a, b) => { const x = AUTO_ORDER.indexOf(a.id), y = AUTO_ORDER.indexOf(b.id); return (x < 0 ? 99 : x) - (y < 0 ? 99 : y); };
const money = (v) => `${v >= 0 ? "+" : "-"}${Math.abs(Number(v) || 0).toFixed(2)}`;
let autoPaint = () => {};

// Honest time windows in the client's own local time. They describe when the owner's tests were done, not a promise of profit.
function windowsCard() {
  const h = new Date().getHours(), W = [["Morning analysis", 7, 11], ["Midday review", 13, 15], ["Evening review", 19, 22]];
  return `<div class="winc"><h4>SMART TRADING WINDOWS</h4><p class="note">Deriv synthetic indices trade 24/7. These windows only organise your analysis in your local time. No hour is guaranteed to make a profit.</p>${W.map(([n, a, b]) => `<div class="win ${h >= a && h < b ? "now" : ""}"><b>${n}</b><span>${String(a).padStart(2, "0")}:00 - ${String(b).padStart(2, "0")}:00</span><em>${h >= a && h < b ? "Active now" : "Outside window"}</em></div>`).join("")}</div>`;
}
function viewAuto(main) {
  const autos = [...pub().filter((i) => i.section === "automated").sort(autoSort), ENGINE_BOT];
  const token = sess.get("token") || "";
  const pre = autos.find((i) => i.id === state.preBot && unlocked(i)); state.preBot = null;
  const mine = pre ? [pre] : autos.filter(unlocked);
  if (!mine.length && (state.autoTab || "ai") === "ai") {
    main.append(el(`<section class="hub"><span class="badge">Automated</span><h1>Pay to <em>unlock</em> a bot</h1><p class="lede">Open the Deriv screen, choose AUTOMATED BOTS, pay for a bot and it opens here.</p><div class="row" style="justify-content:center"><button class="btn big" data-go="deriv" type="button">Open Deriv bots</button></div></section>`));
    main.onclick = shopClick; return;
  }
  state.autoBot = pre ? pre.id : (mine.find((i) => i.id === state.autoBot) || mine[0] || autos[0]).id;
  const cur = () => autos.find((i) => i.id === state.autoBot) || mine[0] || autos[0];
  main.append(el(`<section class="auto">
   <div class="acctcard" id="acctCard"></div>
   <div class="form" id="connBox" ${state.conn ? "hidden" : ""}>
    <h2 style="margin-top:0">Connect your Deriv account</h2>
    <p class="lede" style="margin:0 0 10px">Your bots trade your own Deriv account from this page. Your token stays in this browser tab and is sent only to Deriv. Keep the tab open while it runs.</p>
    <div class="warn">Use a token with the <b>trade</b> scope only, never withdraw or transfer. Start on a demo account. Accumulators and digit contracts can lose the whole stake.</div>
    <div class="row"><div class="field"><label for="token">Deriv API token</label><input id="token" type="password" autocomplete="off" value="${esc(token)}" placeholder="Paste token"></div>
    ${HAS_APPID ? `<input id="appid" type="hidden" value="${esc(CONFIG.derivAppId)}">` : `<div class="field"><label for="appid">Deriv App ID</label><input id="appid" value="${esc(store.get("appid", ""))}" placeholder="App ID"></div>`}
    <div class="field"><label for="acctype">Account</label><select id="acctype"><option value="demo">Demo</option><option value="real">Real</option></select></div></div>
    <div class="row" style="margin-bottom:8px"><a class="btn ghost" href="${WA_HELP()}" target="_blank" rel="noopener">Don't know how to put API? Chat on WhatsApp</a></div>
    <p class="note">No Deriv account? <a href="https://deriv.com/signup" target="_blank" rel="noopener">Sign up</a>. Then create a Personal Access Token with the <b>trade</b> scope at <a href="https://developers.deriv.com" target="_blank" rel="noopener">developers.deriv.com</a>.</p>
    <div class="row"><button class="btn" id="conn" type="button">Connect and show balance</button><button class="btn ghost" id="diag" type="button">Test connection</button><button class="btn ghost" id="disc" type="button" ${state.conn ? "" : "hidden"}>Disconnect</button></div>
    <p class="note" id="cstatTxt"></p>
   </div>
   <div class="seg" id="aTabs"><button data-a="ai">AI</button><button data-a="markets">Markets</button><button data-a="trades">Trades</button></div>
   <div id="aBody"></div></section>`));

  // top card: connected state, demo or real, balance, session profit or loss
  autoPaint = () => {
    const c = state.conn, a = c?.account, card = $("#acctCard"); if (!card) return;
    card.innerHTML = `<div class="acrow"><span class="botn">${esc(cur().name)}</span><span class="chipc ${c ? "on" : ""}">${c ? "CONNECTED" : "NOT CONNECTED"}</span></div>
     <div class="aclbl">${c ? (a.is_virtual ? "DEMO ACCOUNT" : "REAL ACCOUNT") + " · " + esc(a.loginid) : "DERIV ACCOUNT"}</div>
     <div class="bigbal">${c ? Number(a.balance).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : "--"} <small>${c ? esc(a.currency) : ""}</small></div>
     <div class="acpl">SESSION P/L <b class="${(state.pnl || 0) >= 0 ? "up" : "dn"}">${c ? money(state.pnl || 0) : "-"}</b></div>
     <div class="row"><button class="btn ghost" id="manage" type="button">Manage Deriv connection</button>${state.run && state.ai ? `<button class="btn" id="openAI" type="button">Open AI screen</button>` : ""}</div>`;
    $("#disc") && ($("#disc").hidden = !c);
  };
  const saveForm = () => { const g = (i) => $(i)?.value; if (!$("#stake")) return; state.autoForm = { stake: g("#stake"), sl: g("#sl"), tp: g("#tp"), mult: g("#mult"), steps: g("#steps"), preset: g("#preset"), symbol: g("#symbol"), barrier: g("#barrier"), tpt: g("#tpt"), tpu: g("#tpu") }; };

  const tabAI = (body) => {
    const f = state.autoForm || {};
    body.innerHTML = `<div class="aicore idle"><div class="aihero">${CORE_SVG}<div class="aiphase"><b id="botTitle">${esc(cur().name)}</b><span>AI core standing by. Press start and it scans every market.</span></div></div></div>
     <p class="note" id="botDesc">${esc(cur().desc)}</p>
     <form class="form" id="auto">
      <div class="row"><div class="field" ${pre ? "hidden" : ""}><label for="bot">Bot</label><select id="bot">${mine.map((i) => `<option value="${i.id}">${esc(i.name)}</option>`).join("")}</select></div></div>
      <h2 style="margin-top:0">AI trade setup</h2>
      <div class="row"><div class="field"><label for="stake">Stake (account currency)</label><input id="stake" type="number" min="0.35" step="0.01" value="${esc(f.stake ?? 1)}"></div>
      <div class="field"><label for="sl">Stop loss (session)</label><input id="sl" type="number" min="0.01" step="0.01" value="${esc(f.sl ?? 5)}"></div>
      <div class="field"><label for="tp">Take profit (0 = off)</label><input id="tp" type="number" min="0" step="0.01" value="${esc(f.tp ?? 0)}"></div></div>
      <div class="row" id="tptRow" hidden><div class="field"><label for="tpt">Take profit: ticks to hold (empty = AI picks 5 to 10)</label><input id="tpt" type="number" min="1" max="30" step="1" inputmode="numeric" placeholder="e.g. 8" value="${esc(f.tpt ?? "")}"></div>
        <div class="field"><label for="tpu">Take profit per trade (USD, empty = off)</label><input id="tpu" type="number" min="0.1" step="0.1" inputmode="decimal" placeholder="e.g. 1" value="${esc(f.tpu ?? "")}"></div></div>
      <div id="digitOpts" hidden><div class="row">
       <div class="field"><label for="preset">Contract</label><select id="preset">${PRESET_OPTS.map(([v, n]) => `<option value="${v}">${n}</option>`).join("")}</select></div>
       <div class="field"><label for="symbol">Market</label><select id="symbol">${SYMS.map((s) => `<option>${s}</option>`).join("")}</select></div>
       <div class="field"><label for="barrier">Digit (blank = default)</label><input id="barrier" type="number" min="0" max="9" value="${esc(f.barrier ?? "")}"></div>
       <div class="field"><label for="mult">Recovery multiplier</label><input id="mult" type="number" min="1" step="0.1" value="${esc(f.mult ?? 2)}"></div>
       <div class="field"><label for="steps">Max recovery steps</label><input id="steps" type="number" min="0" max="6" value="${esc(f.steps ?? 3)}"></div></div></div>
      <label class="row"><input id="real" type="checkbox" style="width:auto"> I understand a real-money account can lose my stake and I accept that risk</label>
      <div class="row" style="margin-top:12px"><button class="btn big" id="start" ${state.run ? "disabled" : ""}>START AI TRADING</button></div>
      <p class="note">The AI scans all markets and places a trade the moment it finds an entry. It cannot promise profit. Test on a demo account first.</p>
     </form>`;
    const sel = $("#bot", body); sel.value = state.autoBot;
    const sync = () => {
      const it = cur(); state.autoBot = it.id;
      const smart = !!SMART[it.id] || !!TOUCH[it.id] || isRuleBot(it);
      $("#tptRow").hidden = it.id !== "ninja";
      $("#digitOpts").hidden = ACC.includes(it.id) || isRuleBot(it);
      for (const q of ["#preset", "#symbol", "#barrier"]) { const e = $(q); if (e) e.closest(".field").hidden = smart; }
      const allowed = it.presets || PRESET_OPTS.map((p) => p[0]);
      $("#preset").innerHTML = PRESET_OPTS.filter(([v]) => allowed.includes(v)).map(([v, n]) => `<option value="${v}">${n}</option>`).join("");
      if (f.preset) $("#preset").value = f.preset; if (f.symbol) $("#symbol").value = f.symbol;
      $("#botTitle").textContent = it.name; $("#botDesc").textContent = it.desc; autoPaint();
    };
    sel.onchange = sync; sync();
    $("#auto").onsubmit = (e) => { e.preventDefault(); startRun(); };
  };

  const tabMarkets = (body) => {
    body.innerHTML = `<span class="livepill">● LIVE DERIV FEED</span><p class="note" id="mkMsg">Connecting to live Deriv prices...</p><div id="mkList" class="mrows"></div>${windowsCard()}`;
    $("#mkList").onclick = (e) => { const b = e.target.closest("[data-sym]"); if (b) { state.autoForm = { ...(state.autoForm || {}), symbol: b.dataset.sym }; toast(`${marketName(b.dataset.sym)} is scanned by the AI automatically.`); } };
    let dead = false, client = null, scanner = null, timer = null;
    const paint = () => {
      if (dead || !scanner) return;
      $("#mkList").innerHTML = [...scanner.windows.entries()].map(([s, w]) => { const p = w.prices, first = p[0], pct = first ? ((w.price - first) / first) * 100 : 0, dn = pct < 0, t = new Date().toLocaleTimeString([], { hour12: false });
        return `<button class="mrow mk" data-sym="${s}" type="button"><div><b>${esc(marketName(s))}</b><span class="note">${s} · LIVE · ${t}</span></div><div class="mpx"><b>${w.price ?? "--"}</b><span class="px ${dn ? "d" : "u"}">${dn ? "▼" : "▲"} ${pct >= 0 ? "+" : ""}${pct.toFixed(2)}%</span></div></button>`; }).join("");
    };
    (async () => {
      try { client = new DerivClient({ mode: "public" }); await client.connect(); scanner = new LIB.MarketScanner(client, LIB.SYMBOLS, { size: 30 }); await scanner.start(); $("#mkMsg").textContent = "Live Deriv markets"; paint(); timer = setInterval(paint, 1000); }
      catch { if (!dead) $("#mkMsg").textContent = "Could not reach Deriv live data right now."; }
    })();
    scStop = () => { dead = true; clearInterval(timer); try { scanner?.stop(); } catch {} try { client?.close(); } catch {} };
  };

  const tabTrades = (body) => {
    body.innerHTML = `<div class="stats" id="stats"></div><h2>Trade history</h2><div id="hist" class="hist"></div><h2>Log</h2><div id="log" aria-live="off"></div>`;
    renderStats(state.run?.last);
    $("#hist").innerHTML = (state.history || []).length ? state.history.slice(0, 60).map((h) => `<div class="hrow ${h.won ? "w" : "l"}"><span>${new Date(h.t).toLocaleTimeString()}</span><b>${esc(marketName(h.symbol))}</b><em>${h.won ? "WON" : "LOST"} ${money(h.profit)}</em></div>`).join("") : `<p class="note">No trades yet.</p>`;
    const lg = $("#log"); for (const x of state.logBuf || []) { const d = document.createElement("div"); d.className = x.level; d.textContent = x.text; lg.append(d); }
  };

  const showTab = (t) => {
    saveForm(); stopScanner(); state.autoTab = t;
    document.querySelectorAll("#aTabs button").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.a === t)));
    const body = $("#aBody"); ({ ai: tabAI, markets: tabMarkets, trades: tabTrades }[t] || tabAI)(body);
  };
  $("#aTabs").onclick = (e) => { const b = e.target.closest("button"); if (b) showTab(b.dataset.a); };
  main.onclick = (e) => {
    const b = e.target.closest("button"); if (!b) return;
    if (b.id === "manage") { const cb = $("#connBox"); cb.hidden = !cb.hidden; }
    else if (b.id === "openAI") state.ai?.open();
    else if (b.id === "conn") doConnect();
    else if (b.id === "diag") diagnose();
    else if (b.id === "disc") { try { state.conn?.client.close(); } catch {} state.conn = null; setBalance(null); autoPaint(); $("#connBox").hidden = false; }
  };
  const doConnect = async () => {
    const t = $("#token").value.trim(); if (!t) return toast("Paste your token first.");
    $("#conn").disabled = true; $("#cstatTxt").textContent = "Connecting...";
    try { const c = await connect(t); sess.set("token", t); $("#cstatTxt").textContent = ""; log(`Connected: ${c.account.loginid} (${c.account.is_virtual ? "demo" : "REAL"}), balance ${c.account.balance} ${c.account.currency}.`, "ok"); $("#connBox").hidden = true; }
    catch (e) { log(e.message, "error"); $("#cstatTxt").textContent = e.message; toast(e.message); }
    $("#conn").disabled = false; autoPaint();
  };
  autoPaint(); showTab(state.autoTab || "ai");
}
function setStat(txt, on) { const t = $("#cstatTxt"); if (t) t.textContent = txt; autoPaint(); }
function setBalance(v, cur) {
  autoPaint();
  const b = $("#bal"); if (!b) return;
  if (v == null || state.mode !== "binary") { b.hidden = true; return; }
  b.hidden = false; b.textContent = `Balance ${Number(v).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${cur || ""}`;
}
function log(msg, level = "info") {
  const text = `${new Date().toLocaleTimeString()}  ${msg}`;
  state.logBuf.push({ level, text }); if (state.logBuf.length > 300) state.logBuf.shift();
  const box = $("#log"); if (!box) return;
  const d = document.createElement("div"); d.className = level;
  d.textContent = text;
  box.append(d); box.scrollTop = box.scrollHeight;
  while (box.childNodes.length > 400) box.firstChild.remove();
}
function renderStats(s) {
  const b = $("#stats"); if (!b) return;
  if (!s) { b.innerHTML = ""; return; }
  const c = (l, v) => `<div class="stat"><b>${esc(v)}</b><span>${l}</span></div>`;
  b.innerHTML = c("Session P/L", s.pnl.toFixed(2)) + c("Wins", s.wins) + c("Losses", s.losses) + c("Trades", s.trades) + c("Open", s.open) + c("Market", s.market || "-") + c("Status", s.running ? "Running" : "Stopped");
}

async function connect(tokenValue) {
  const appId = ($("#appid")?.value || CONFIG.derivAppId || "").trim();
  if (!appId) throw new Error("Enter the App ID (see the note under the token box).");
  try { store.set("appid", appId); } catch {}
  const pref = $("#acctype")?.value || "demo";
  if (state.conn && !state.conn.client.closed && state.conn.token === tokenValue && state.conn.pref === pref) return state.conn;
  try { state.conn?.client.close(); } catch {}
  const client = new DerivClient({ mode: "pat", appId, token: tokenValue, accountPref: pref });
  client.trace = (m) => log(m);
  await client.connect();
  const account = await client.authorize(tokenValue);
  state.conn = { client, account, token: tokenValue, pref };
  client.onclose = () => { if (state.conn?.client === client) { state.conn = null; setBalance(null); setStat("Disconnected from Deriv.", false); } };
  try { await client.subscribe({ balance: 1 }, (m) => { if (m?.balance) { account.balance = Number(m.balance.balance); setBalance(account.balance, account.currency); } }); } catch {}
  setBalance(account.balance, account.currency);
  setStat(`Connected to Deriv: ${account.loginid} (${account.is_virtual ? "demo" : "REAL"}), balance ${account.balance} ${account.currency}`, true);
  return state.conn;
}

async function startRun() {
  if (state.run) return;
  const id = $("#bot").value, it = ITEMS.find((i) => i.id === id);
  const tokenValue = $("#token").value.trim();
  const stake = Number($("#stake").value), stopLoss = Number($("#sl").value), takeProfit = Number($("#tp").value);
  if (!unlocked(it)) return toast("This bot is locked.");
  if (!tokenValue) return toast("Paste your Deriv token.");
  if (!(stake >= 0.35)) return toast("Stake must be at least 0.35.");
  if (!(stopLoss > 0)) return toast("Set a stop loss above 0.");
  $("#start").disabled = true;
  let client;
  try {
    log("Unlocking bot...");
    const out = it.builtin ? { bytes: null } : await tryOpen(it);
    if (it.builtin && !tokenOf()) throw new Error("Log in first. The engine bot needs your account to read the engine.");
    if (!out) throw new Error("Could not open this bot. Log in with the account that bought it.");
    log("Connecting to Deriv...");
    const conn = await connect(tokenValue); client = conn.client;
    const acc = conn.account;
    if (!acc.is_virtual && !$("#real").checked) throw new Error(`${acc.loginid} is a REAL account. Tick the risk box to trade it, or use a demo token.`);
    sess.set("token", tokenValue);
    log(`Connected: ${acc.loginid} (${acc.is_virtual ? "demo" : "REAL"}), balance ${acc.balance} ${acc.currency}.`, acc.is_virtual ? "ok" : "warn");
    if (stake > acc.balance) throw new Error("Stake is bigger than your balance.");
    let mod;
    if (it.builtin) mod = await import("./ai-bot.js");
    else { const url = URL.createObjectURL(new Blob([text(out.bytes)], { type: "text/javascript" })); mod = await import(url); URL.revokeObjectURL(url); }
    const config = { stake, stopLoss, takeProfit };
    if (id === "ninja") {
      const raw = String($("#tpt")?.value || "").trim();
      if (raw) { const n = Number(raw); if (!Number.isInteger(n) || n < 1 || n > 30) throw new Error("Take profit ticks must be a whole number from 1 to 30, or leave it empty."); config.tpTicks = n; }
      const rawU = String($("#tpu")?.value || "").trim();
      if (rawU) { const u = Number(rawU); if (!(u > 0)) throw new Error("Take profit in USD must be more than 0, or leave it empty."); config.tpUsd = u; }
    }
    if (TOUCH[id]) Object.assign(config, { side: TOUCH[id], multiplier: Number($("#mult").value) || 1, maxSteps: Number($("#steps").value) || 0 });
    else if (SMART[id]) Object.assign(config, { mode: SMART[id], multiplier: Number($("#mult").value) || 1, maxSteps: Number($("#steps").value) || 0 });
    else if (isRuleBot(it)) { /* the locked rules decide everything */ }
    else if (!ACC.includes(id)) {
      const b = $("#barrier").value;
      Object.assign(config, { preset: $("#preset").value, symbol: $("#symbol").value, barrier: b === "" ? undefined : Number(b), multiplier: Number($("#mult").value) || 1, maxSteps: Number($("#steps").value) || 0 });
    }
    const run = { last: null };
    state.ai?.destroy();
    state.ai = new AIScreen({ title: it.name, accumulator: ACC.includes(id), sellable: id === "ninja", onSell: () => state.run?.sellNow?.(), symbols: LIB.SYMBOLS, onStop: () => state.run?.stop(), onDestroy: () => { state.ai = null; autoPaint(); } });
    const bot = mod.create({
      client, account: acc, config, log, lib: LIB, engine: { status: () => engGet("/engine/status"), signals: (m) => engGet("/engine/signals?mkt=" + m) },
      ai: (e) => { state.ai?.handle(e); if (e.type === "result") { state.history.unshift({ t: Date.now(), symbol: e.symbol, won: e.won, profit: e.profit }); saveTrade({ t: Date.now(), symbol: e.symbol, won: e.won, profit: e.profit, bot: id }); state.pnl = Math.round(((state.pnl || 0) + e.profit) * 100) / 100; autoPaint(); const h = $("#hist"); if (h) showHist(); } },
      onState: (s) => { run.last = s; renderStats(s); },
      finish: () => { try { client.close(); } catch {} state.conn = null; setBalance(null); setStat("Stopped. Press Start to run again.", false); state.run = null; state.ai?.finish(); const st = $("#start"); if (st) st.disabled = false; autoPaint(); },
    });
    run.stop = bot.stop; run.sellNow = () => bot.sellNow?.(); state.run = run;
    client.onclose = () => { if (state.run === run) { log("Connection to Deriv dropped. Bot stopped. Check Deriv for any open contract.", "error"); state.run = null; state.ai?.finish("Connection to Deriv dropped. Check Deriv for any open contract."); const st = $("#start"); if (st) st.disabled = false; autoPaint(); } };
    setStat(`Connected to Deriv: ${acc.loginid}. Scanning markets... the bot is running.`, true);
    await bot.start();
  } catch (err) {
    log(err.message, "error"); toast(err.message);
    try { client?.close(); } catch {}
    state.run = null; const st = $("#start"); if (st) st.disabled = false; $("#stop") && ($("#stop").disabled = true);
  }
}

// Free check: does Deriv send the run history the Killer needs?
async function diagnose() {
  const tokenValue = $("#token").value.trim();
  if (!tokenValue) return toast("Paste your token first.");
  $("#diag").disabled = true;
  let client;
  try {
    const conn = await connect(tokenValue); client = conn.client;
    log(`Connected as ${conn.account.loginid}. Requesting an accumulator quote on R_100...`);
    let n = 0;
    const un = await client.subscribe({ proposal: 1, amount: 1, basis: "stake", contract_type: "ACCU", currency: conn.account.currency, growth_rate: 0.05, symbol: "R_100" }, (m, err) => {
      if (err) return log(err.message, "error");
      const cd = m.proposal.contract_details || {};
      log(`contract_details fields: ${Object.keys(cd).join(", ") || "none"}`);
      if (Array.isArray(cd.ticks_stayed_in)) log(`ticks_stayed_in = [${cd.ticks_stayed_in.slice(0, 8).join(", ")}...]`, "ok");
      else log("ticks_stayed_in is missing. The Killer cannot run on this account or endpoint.", "error");
      if (++n >= 4) { un(); $("#diag").disabled = false; }
    });
  } catch (err) { log(err.message, "error"); $("#diag").disabled = false; }
}



/* ---------- Home: choose Binary or Forex ---------- */
const ICON_BIN = `<svg viewBox="0 0 64 64" width="56" height="56" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><path d="M10 50V30M10 24v-6M26 50V20M26 14v-4M42 50V34M42 28v-8M58 50V24M58 18v-8" opacity=".35"/><rect x="6" y="30" width="8" height="14" rx="2"/><rect x="22" y="22" width="8" height="20" rx="2"/><rect x="38" y="34" width="8" height="10" rx="2"/><rect x="54" y="26" width="8" height="14" rx="2" transform="translate(-4 0)"/></svg>`;
const ICON_FX = `<svg viewBox="0 0 64 64" width="56" height="56" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M6 46l14-14 10 8 16-22 12 10"/><path d="M46 18h12v12" opacity=".6"/><path d="M6 56h52" opacity=".35"/></svg>`;

/* ---------- Auto system EA: control panel (the robot in MT5 obeys this) ---------- */
async function eaApi(body, bot) {
  const r = await fetch(CONFIG.payApi + "/ea/control" + (bot === "straddle-system" ? "?bot=straddle-system" : ""), { method: body ? "POST" : "GET", headers: { "Content-Type": "application/json", "X-Token": tokenOf(), "X-Admin": store.get("owner") || "" }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || "Could not reach the server."); return d;
}
async function eaPanel(bot = "xauusd-system") {
  const SW = bot === "straddle-system", callApi = (b) => eaApi(b, bot), TITLE = SW ? "Straddle System" : "ChartLord System";
  closeSheets(); document.getElementById("eaFull")?.remove();
  const root = el(`<div id="eaFull" class="eafull" role="dialog" aria-label="${TITLE}"><aside class="eside"><div class="elogo">Chart<span>Lord</span></div><nav id="eTabs"></nav><div class="esidefoot">Trading carries a high risk of loss.</div></aside><div class="emain"><header class="etop"><button class="btn ghost" id="eBack" type="button">&#8249; Back</button><h2>${SW ? "Straddle <em>System</em>" : "ChartLord <em>System</em>"}</h2><span class="epill" id="ePill">Loading</span><button class="btn" id="eRun" type="button" hidden></button></header><div class="ebody" id="eaBody"><p class="note">Loading...</p></div></div></div>`);
  document.body.append(root); document.body.classList.add("eaopen");
  let timer = 0, client = null, dead = false, tab = "dash", d, candles = [], feed = [];
  const close = () => { dead = true; clearInterval(timer); try { client?.close(); } catch {} root.remove(); document.body.classList.remove("eaopen"); };
  $("#eBack", root).onclick = close;
  const TABS_E = [["dash", "Dashboard"], ["scan", "Market scanner"], ["ctl", "Controls"], ["setup", "Set up"]];
  $("#eTabs", root).innerHTML = TABS_E.map(([k, n]) => `<button data-t="${k}" type="button">${n}</button>`).join("");
  $("#eTabs", root).onclick = (e) => { const b = e.target.closest("[data-t]"); if (b) { tab = b.dataset.t; paint(); } };
  const box = $("#eaBody", root);
  const ago = (t) => { const s = Math.max(0, Math.round((Date.now() - t) / 1000)); return s < 90 ? s + " s ago" : Math.round(s / 60) + " min ago"; };
  const f2 = (n) => (Number(n) || 0).toFixed(2);
  const noteFeed = (st) => { if (!st || !st.state) return; if (feed[0]?.s !== st.state) { feed.unshift({ t: Date.now(), s: st.state }); feed = feed.slice(0, 30); } };
  const stats = (st) => st ? `<div class="ecards">
    <div class="ecard"><i class="ic a">$</i><div><span>Balance</span><b>${f2(st.balance)}</b></div></div>
    <div class="ecard"><i class="ic b">&#9650;</i><div><span>Equity</span><b>${f2(st.equity)}</b></div></div>
    <div class="ecard"><i class="ic c">&#8596;</i><div><span>Today</span><b class="${st.today >= 0 ? "up" : "dn"}">${st.today >= 0 ? "+" : ""}${f2(st.today)}</b></div></div>
    <div class="ecard"><i class="ic d">#</i><div><span>Open trades</span><b>${st.open}</b></div></div></div>
    <p class="note">MT5 account ${esc(st.login)} on ${esc(st.server)} | seen ${ago(st.t)}</p>` : `<div class="epanel"><h3>Robot not connected yet</h3><p class="note">Open the Set up tab and follow the 4 steps. This screen fills in as soon as the robot in MT5 connects.</p></div>`;
  const drawChart = () => {
    const cv = $("#eCv", root); if (!cv || candles.length < 2) return;
    const g = cv.getContext("2d"), W = cv.width, H = cv.height, padR = 90, padB = 6; g.clearRect(0, 0, W, H);
    const lo = Math.min(...candles.map((c) => c.low)), hi = Math.max(...candles.map((c) => c.high)), pad = (hi - lo) * 0.06 || 1;
    const y = (p) => (H - padB) - ((p - lo + pad) / (hi - lo + 2 * pad)) * (H - padB), cw = (W - padR) / candles.length;
    g.font = "18px sans-serif"; g.fillStyle = "#8a90a6"; g.strokeStyle = "rgba(138,144,166,.18)"; g.lineWidth = 1;
    for (let i = 0; i <= 4; i++) { const v = lo - pad + ((hi - lo + 2 * pad) * i) / 4, yy = y(v); g.beginPath(); g.moveTo(0, yy); g.lineTo(W - padR, yy); g.stroke(); g.fillText(v.toFixed(2), W - padR + 6, yy + 6); }
    candles.forEach((c, i) => { const x = i * cw + cw / 2, col = c.close >= c.open ? "#2ecc71" : "#ff5b6e"; g.strokeStyle = col; g.fillStyle = col; g.lineWidth = 2; g.beginPath(); g.moveTo(x, y(c.high)); g.lineTo(x, y(c.low)); g.stroke(); g.fillRect(x - cw * .32, y(Math.max(c.open, c.close)), cw * .64, Math.max(2, Math.abs(y(c.open) - y(c.close)))); });
    const l = candles[candles.length - 1]; const px = $("#eaPx", root); if (px) px.textContent = l.close;
  };
  const startChart = async () => {
    try {
      client = new DerivClient({ mode: "public" }); await client.connect();
      await client.subscribe({ ticks_history: "frxXAUUSD", adjust_start_time: 1, count: 90, end: "latest", granularity: 300, style: "candles" }, (m, err) => {
        if (dead || err) return;
        if (m.candles) candles = m.candles.map((c) => ({ open: +c.open, high: +c.high, low: +c.low, close: +c.close, epoch: c.epoch }));
        else if (m.ohlc) { const o = { open: +m.ohlc.open, high: +m.ohlc.high, low: +m.ohlc.low, close: +m.ohlc.close, epoch: m.ohlc.open_time }; const l = candles[candles.length - 1]; if (l && l.epoch === o.epoch) candles[candles.length - 1] = o; else { candles.push(o); if (candles.length > 90) candles.shift(); } }
        drawChart();
      });
    } catch {}
  };
  const steps = (c) => SW
    ? [["News check", "Stands down all day when there is high impact USD news today"], ["Liquidity sweep", "Price takes a recent high or low and closes back inside"], ["Stretched + calm", "Price is far from its average and not trending hard"], ["Trade back to the mean", "Small stop beyond the sweep, quick break-even, profit taken early"]]
    : c.mode === "straddle"
    ? [["Calendar", "Watches the next high impact USD news"], ["Arm", `Places a buy stop and a sell stop ${c.stMin || 2} min before`], ["Trigger", "One side fills, the other is cancelled"], ["Take profit fast", "Quick target, break-even and trailing, closes after the news"]]
    : c.mode === "scalp"
    ? [["Candle close", `Waits for each ${c.scalpTf === "5" ? "5" : "1"} minute candle to close`], ["Break", "Looks for a break of the last swing"], ["Trend filter", `Must agree with the ${c.scalpTf === "5" ? "15" : "5"} minute trend`], ["Entry", "Small target, tight stop, spread checked"]]
    : [["4H direction", "Reads the 4 hour trend"], ["1H sweep or gap", "Waits for a liquidity sweep or fair value gap"], ["5M order block", "Looks for the entry on a 5 minute order block"], ["Target", "Aims at the opposite 1H liquidity"]];
  const newsCard = () => { const n = d.news; if (!n) return ""; const t = n.today || []; return `<div class="epanel newsday ${t.length ? "stand" : "go"}"><div class="ephead"><h3>Today's news</h3><span class="scanlive ${t.length ? "" : "on"}">${t.length ? "NEWS DAY: STANDING DOWN" : n.known ? "NO NEWS: SCALPING" : "CALENDAR NOT LOADED"}</span></div>${t.length ? t.map((x) => `<p class="note"><b>${new Date(x.ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false })}</b> USD ${esc(x.title)} (high impact). No new trades are opened today.</p>`).join("") : `<p class="note">${n.known ? "No high impact USD news today, so the robot trades liquidity sweeps." : "The news calendar could not be read, so the robot cannot confirm a news-free day."}</p>`}</div>`; };
  const view = {
    dash: () => `${stats(d.status)}${SW ? newsCard() : ""}<div class="egrid"><div class="epanel wide"><div class="ephead"><h3>XAUUSD live <span class="note">5 minute</span></h3><b id="eaPx" class="mono">...</b></div><canvas id="eCv" width="900" height="340"></canvas></div>
      <div class="epanel"><h3>Robot state</h3><p class="bigstate">${esc(d.status?.state || "Waiting for the robot")}</p><p class="note">Mode: <b>${SW ? "Liquidity sweep scalping" : d.cfg.mode === "scalp" ? "Scalping" : "Intraday"}</b> | ${d.cfg.run ? "Running" : "Stopped"}</p><button class="btn ghost" data-t="scan" type="button">See how it scans</button></div></div>`,
    scan: () => `<div class="epanel"><div class="ephead"><h3>How the system scans XAUUSD</h3><span class="scanlive ${d.status?.online && d.cfg.run ? "on" : ""}">${d.status?.online && d.cfg.run ? "SCANNING" : "IDLE"}</span></div><div class="scanbar"><b></b></div>
      <ol class="pipe">${steps(d.cfg).map(([t, s], i) => `<li style="--i:${i}"><span>${i + 1}</span><div><b>${t}</b><em>${s}</em></div></li>`).join("")}</ol></div>
      <div class="epanel"><h3>Live from the robot</h3><p class="bigstate">${esc(d.status?.state || "Waiting for the robot")}</p><div class="feed">${feed.length ? feed.map((x) => `<div><time>${new Date(x.t).toLocaleTimeString()}</time><span>${esc(x.s)}</span></div>`).join("") : `<p class="note">The robot's messages show here as they change.</p>`}</div></div>`,
    ctl: () => { const c = d.cfg; return `<div class="epanel"><div class="row"><button class="btn danger" id="ea-close" type="button">Close all trades now</button></div>
      ${SW ? "" : `<h3>Mode</h3>`}<div class="chips" id="ea-mode" ${SW ? "hidden" : ""}><button class="chip" data-m="intraday" aria-pressed="${c.mode === "intraday"}" type="button">Intraday</button><button class="chip" data-m="scalp" aria-pressed="${c.mode === "scalp"}" type="button">Scalping (many trades)</button></div>
      ${SW ? `<div class="row"><div class="field"><label for="ea-ph">Most trades per hour</label><input id="ea-ph" type="number" min="1" max="60" value="${c.perHour ?? 30}"></div><div class="field"><label for="ea-ls">Pause after losses in a row</label><input id="ea-ls" type="number" min="1" max="10" value="${c.lossStreak ?? 3}"></div></div><p class="note">Every trade has a stop loss. After the chosen number of losses in a row the robot pauses for 10 minutes. It cannot promise that every trade wins.</p>` : ""}${false ? `<p class="note">Before each high impact USD news the robot places a buy stop above and a sell stop below price. The one that fills is kept, the other is cancelled. It takes profit fast, moves to break-even quickly and closes everything a few minutes after the news. It does not guess the direction. Slippage and spreads are big during news, so use a demo account first.</p><div class="row"><div class="field"><label for="ea-stmin">Place orders (minutes before)</label><input id="ea-stmin" type="number" min="1" max="10" value="${c.stMin ?? 2}"></div><div class="field"><label for="ea-stmult">Distance (x normal range)</label><input id="ea-stmult" type="number" min="0.2" max="3" step="0.1" value="${c.stMult ?? 0.5}"></div></div><div class="row"><div class="field"><label for="ea-strr">Take profit (x risk)</label><input id="ea-strr" type="number" min="0.5" max="3" step="0.1" value="${c.stRR ?? 1}"></div><div class="field"><label for="ea-sthold">Close after the news (minutes)</label><input id="ea-sthold" type="number" min="3" max="30" value="${c.stHold ?? 10}"></div></div>` : ""}
      ${c.mode === "scalp" ? `<h3>Scalp after a candle closes</h3><div class="chips" id="ea-tf"><button class="chip" data-f="1" aria-pressed="${c.scalpTf !== "5"}" type="button">1 minute candle</button><button class="chip" data-f="5" aria-pressed="${c.scalpTf === "5"}" type="button">5 minute candle</button></div>` : ""}
      <h3>Lot size</h3><div class="chips" id="ea-lm"><button class="chip" data-l="fixed" aria-pressed="${c.lotMode === "fixed"}" type="button">Fixed lot</button><button class="chip" data-l="risk" aria-pressed="${c.lotMode === "risk"}" type="button">% of balance</button></div>
      <div class="row"><div class="field"><label for="ea-lot">Fixed lot</label><input id="ea-lot" type="number" min="0.01" step="0.01" value="${c.lot}"></div><div class="field"><label for="ea-risk">Risk per trade (%)</label><input id="ea-risk" type="number" min="0.1" max="5" step="0.1" value="${c.risk}"></div></div>
      <div class="row"><div class="field"><label for="ea-dd">Daily loss lock (%), 0 = no limit</label><input id="ea-dd" type="number" min="0" max="10" step="0.5" value="${c.dd}"></div><div class="field"><label for="ea-mo">Most open trades</label><input id="ea-mo" type="number" min="1" max="10" value="${c.maxOpen}"></div></div>
      <div class="row"><button class="btn" id="ea-save" type="button">Save settings</button><span class="note" id="ea-msg">The robot picks up changes within about 15 seconds.</span></div></div>`; },
    setup: () => `<div class="epanel"><h3>Your EA key</h3><div class="row"><input id="ea-key" readonly value="${esc(d.key)}" style="flex:1;min-width:200px"><button class="btn ghost" id="ea-copy" type="button">Copy</button><button class="btn ghost" id="ea-new" type="button">New key</button></div>
      <h3>Set up in MT5 (once)</h3><ol class="note"><li>Download the bot and put it in MT5: File, Open Data Folder, MQL5, Experts. Open it in MetaEditor and press F7 to compile.</li><li>MT5: Tools, Options, Expert Advisors, tick "Allow WebRequest for listed URL" and add <b>${esc(CONFIG.payApi)}</b></li><li>Open an XAUUSD chart, drag the robot on, turn on Algo Trading.</li><li>In the robot inputs paste the key above.</li></ol></div>`
  };
  const save = async (patch, msg) => { try { d = await callApi({ cfg: { ...d.cfg, ...patch } }); paint(); const m = $("#ea-msg", box); if (m) m.textContent = msg; } catch (e) { toast(e.message); } };
  const paint = () => {
    const c = d.cfg, st = d.status;
    $("#eTabs", root).querySelectorAll("button").forEach((b) => b.setAttribute("aria-current", String(b.dataset.t === tab)));
    const pill = $("#ePill", root); pill.textContent = st ? (st.online ? "Robot online" : "Robot offline") : "Not connected"; pill.className = "epill " + (st?.online ? "ok" : "off");
    const run = $("#eRun", root); run.hidden = false; run.textContent = c.run ? "STOP robot" : "START robot"; run.className = "btn " + (c.run ? "danger" : ""); run.onclick = () => save({ run: !c.run }, c.run ? "Stopped." : "Started.");
    noteFeed(st);
    box.innerHTML = view[tab](); drawChart();
    box.onclick = (e) => { const b = e.target.closest("[data-t]"); if (b) { tab = b.dataset.t; paint(); } };
    const q = (s) => $(s, box);
    q("#ea-close") && (q("#ea-close").onclick = async () => { if (!confirm("Close every open trade of this robot now?")) return; try { d = await callApi({ closeAll: true }); q("#ea-msg") && (q("#ea-msg").textContent = "Close-all sent."); toast("Close-all sent. The robot does it within about 15 seconds."); } catch (e) { toast(e.message); } });
    q("#ea-mode") && (q("#ea-mode").onclick = (e) => { const b = e.target.closest("[data-m]"); if (b) save({ mode: b.dataset.m }, "Mode saved."); });
    q("#ea-tf") && (q("#ea-tf").onclick = (e) => { const b = e.target.closest("[data-f]"); if (b) save({ scalpTf: b.dataset.f }, "Saved."); });
    q("#ea-lm") && (q("#ea-lm").onclick = (e) => { const b = e.target.closest("[data-l]"); if (b) save({ lotMode: b.dataset.l }, "Lot mode saved."); });
    q("#ea-save") && (q("#ea-save").onclick = () => save({ lot: Number(q("#ea-lot").value), risk: Number(q("#ea-risk").value), dd: Number(q("#ea-dd").value), maxOpen: Number(q("#ea-mo").value), ...(q("#ea-ph") ? { perHour: Number(q("#ea-ph").value), lossStreak: Number(q("#ea-ls").value) } : {}) }, "Saved."));
    q("#ea-copy") && (q("#ea-copy").onclick = async () => { try { await navigator.clipboard.writeText(d.key); toast("Key copied."); } catch { q("#ea-key").select(); } });
    q("#ea-new") && (q("#ea-new").onclick = async () => { if (!confirm("Make a new key? The robot using the old key stops until you paste the new one.")) return; try { d = await callApi({ newKey: true }); paint(); } catch (e) { toast(e.message); } });
  };
  try { d = await callApi(); } catch (e) { box.innerHTML = `<div class="epanel"><h3>Could not load</h3><p class="note">${esc(e.message)}</p><button class="btn" id="eRetry" type="button">Try again</button></div>`; $("#eRetry", box).onclick = () => { close(); eaPanel(); }; return; }
  paint(); startChart();
  timer = setInterval(async () => { try { const n = await callApi(); d.status = n.status; if (document.activeElement?.tagName === "INPUT") return; const keep = box.scrollTop; paint(); box.scrollTop = keep; } catch {} }, 10000);
}

/* ---------- Broker account: pick the broker and MT5 login, see the balance the robots report ---------- */
async function viewBroker(main) {
  const st = state.brk || (state.brk = { name: "", login: "", server: "", lock: false, d: null, err: "", dirty: false });
  main.append(el(`<section class="brokerv"><span class="badge">Forex</span><h1>Broker <em>account</em></h1><p class="lede">Choose your broker, enter your MT5 login ID and connect. The balance comes from the ChartLord robot running in your MT5. Your password is never asked for.</p><div id="bkStatus"></div><div class="epanel"><h3>Your broker</h3><div class="chips" id="bkList"></div>
    <div class="row"><div class="field"><label for="bk-login">MT5 login ID (numbers)</label><input id="bk-login" inputmode="numeric" autocomplete="off" placeholder="e.g. 12345678"></div><div class="field"><label for="bk-server">Server (optional)</label><input id="bk-server" autocomplete="off" placeholder="e.g. Exness-MT5Real8"></div></div>
    <label class="chk"><input type="checkbox" id="bk-lock"> Only let my robots trade on this login</label><p class="note">If you switch account in MT5, the website follows it by itself, unless you tick the box above. With the box ticked, the robots stop on any other login.</p>
    <div class="row"><button class="btn" id="bkSave" type="button">Connect</button><span class="note" id="bkMsg"></span></div></div>
    <div class="epanel"><h3>Switching broker</h3><ol class="note"><li>In MT5 choose File, then Login to Trade Account, and enter the other broker's login and server (open an MT5 account with that broker first).</li><li>Keep the robot on the XAUUSD chart. Within about a minute this page shows the new broker and balance.</li><li>Or pick the broker here, enter its login and tick the lock, so the robots only trade there.</li></ol></div></section>`));
  let timer = 0, dead = false;
  chartStop = () => { dead = true; clearInterval(timer); };
  const fmt = (n) => (Number(n) || 0).toFixed(2), ago = (t) => { const s = Math.max(0, Math.round((Date.now() - t) / 1000)); return s < 90 ? s + " s ago" : Math.round(s / 60) + " min ago"; };
  const api2 = async (body) => {
    const r = await fetch(CONFIG.payApi + "/broker", { method: body ? "POST" : "GET", headers: { "Content-Type": "application/json", "X-Token": tokenOf() }, body: body ? JSON.stringify(body) : undefined });
    const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || "Could not reach the server."); return d;
  };
  const paintList = () => { const L = $("#bkList"); L.innerHTML = (st.d?.brokers || []).map((b) => `<button class="chip" data-b="${esc(b)}" aria-pressed="${st.name === b}" type="button">${esc(b)}</button>`).join(""); };
  const paintStatus = () => {
    const d = st.d, B = $("#bkStatus"); if (!B) return;
    if (st.err) { B.innerHTML = `<div class="epanel"><p class="note">${esc(st.err)}</p></div>`; return; }
    if (!d) { B.innerHTML = ""; return; }
    const live = d.live, bk = d.broker, any = d.has && Object.values(d.has).some(Boolean);
    if (live) {
      const on = !!live.online, diff = bk && bk.login && String(bk.login) !== String(live.login);
      B.innerHTML = `<div class="ecards"><div class="ecard"><i class="ic a">$</i><div><span>Balance</span><b>${fmt(live.balance)}</b></div></div><div class="ecard"><i class="ic b">&#9650;</i><div><span>Equity</span><b>${fmt(live.equity)}</b></div></div><div class="ecard"><i class="ic c">&#8596;</i><div><span>Today</span><b class="${live.today >= 0 ? "up" : "dn"}">${live.today >= 0 ? "+" : ""}${fmt(live.today)}</b></div></div><div class="ecard"><i class="ic d">#</i><div><span>Open trades</span><b>${live.open}</b></div></div></div>
        <p class="note"><span class="epill ${on ? "ok" : "off"}">${on ? "Connected" : "Robot offline"}</span> ${esc(bk?.name || "Broker")} | login ${esc(live.login)} | ${esc(live.server)} | seen ${ago(live.t)}${diff ? `<br><b>MT5 is on login ${esc(live.login)}, not ${esc(bk.login)}.</b> ${bk.lock ? "The robots are blocked until MT5 is on the locked login." : "The website will follow MT5."}` : ""}</p>`;
    } else B.innerHTML = `<div class="epanel"><h3>${bk ? "Waiting for your robot" : "Not connected yet"}</h3><p class="note">${any ? "Open MT5, put the ChartLord robot on an XAUUSD chart with your EA key, and the balance shows here within a minute." : "The balance comes from a ChartLord robot. Buy one in Forex bots and set it up, then it shows here."}</p></div>`;
  };
  const fill = () => { const bk = st.d?.broker; if (bk && !st.dirty) { st.name = bk.name || ""; st.login = bk.login || ""; st.server = bk.server || ""; st.lock = !!bk.lock; } $("#bk-login").value = st.login; $("#bk-server").value = st.server; $("#bk-lock").checked = st.lock; paintList(); };
  const load = async () => { try { st.d = await api2(); st.err = ""; } catch (e) { st.err = e.message; } if (dead) return; if (!st.dirty) fill(); else paintList(); paintStatus(); };
  main.oninput = () => { st.dirty = true; st.login = $("#bk-login").value.trim(); st.server = $("#bk-server").value.trim(); st.lock = $("#bk-lock").checked; };
  main.onclick = async (e) => {
    const b = e.target.closest("[data-b]"); if (b) { if (st.name !== b.dataset.b) { st.server = ""; $("#bk-server").value = ""; } st.name = b.dataset.b; st.dirty = true; paintList(); return; }
    if (e.target.closest("#bkSave")) {
      const m = $("#bkMsg"); if (!st.name) { m.textContent = "Choose your broker first."; return; }
      try { st.d = await api2({ name: st.name, login: st.login, server: st.server, lock: st.lock }); st.dirty = false; m.textContent = "Saved."; fill(); paintStatus(); } catch (er) { m.textContent = er.message; }
    }
  };
  load(); timer = setInterval(load, 10000);
}

/* ---------- Market Engine (AI Analyser): status, source chooser, signals, voice news alerts ---------- */
const ENGINE = { st: null, off: 0, voice: false, spoken: {}, subs: [], timer: 0, tick: 0 };
try { ENGINE.voice = localStorage.getItem("cl.voice") === "1"; } catch {}
async function engGet(path, body, admin) {
  const h = { "Content-Type": "application/json", "X-Token": tokenOf() }; if (admin) h["X-Admin"] = store.get("owner") || "";
  const r = await fetch(CONFIG.payApi + path, { method: body ? "POST" : "GET", headers: h, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || "No answer from the server."); return d;
}
async function engRefresh() {
  if (!tokenOf()) return;
  try { const d = await engGet("/engine/status"); ENGINE.st = d; ENGINE.off = (d.now || Date.now()) - Date.now(); } catch (e) { ENGINE.st = { online: false, on: false, err: e.message }; }
  ENGINE.subs.forEach((f) => { try { f(); } catch {} });
}
window.CL_ENGINE = { refresh: () => engRefresh() };
function engStart() { if (ENGINE.timer) return; engRefresh(); ENGINE.timer = setInterval(engRefresh, 20000); ENGINE.tick = setInterval(engVoice, 1000); }
// colour of the engine: green running, red danger (news close) or error, grey off
function engLook() {
  const s = ENGINE.st; if (!s) return ["x", "CHECKING", ""];
  if (!s.on) return ["x", "ENGINE OFF", "Switched off by the owner."];
  if (!s.online) return ["r", "ENGINE OFFLINE", "The AI Analyser is not running. Use the scanner."];
  const n = s.next, secs = n ? Math.round((n.ts - (Date.now() + ENGINE.off)) / 1000) : null;
  if (n && secs !== null && secs <= 600 && secs > -120) return ["r", "NEWS " + (secs > 0 ? Math.floor(secs / 60) + ":" + String(secs % 60).padStart(2, "0") : "NOW"), n.country + " " + n.title];
  return ["g", "ENGINE ONLINE", n ? "Next news: " + n.country + " " + n.title : "No high impact news soon."];
}
function engPill() { const [c, w, why] = engLook(); return `<span class="enpill ${c}" title="${esc(why)}"><i></i>${esc(w)}</span>`; }
function engSay(text) { try { if (!("speechSynthesis" in window)) return; const u = new SpeechSynthesisUtterance(text); u.rate = 1; u.lang = "en-US"; speechSynthesis.cancel(); speechSynthesis.speak(u); } catch {} }
function engVoice() {
  const s = ENGINE.st; if (!ENGINE.voice || !s || !s.online || !s.next) return;
  const n = s.next, secs = Math.round((n.ts - (Date.now() + ENGINE.off)) / 1000), name = (n.country + " " + n.title).replace(/[^\w .\/%-]/g, " ");
  for (const [thr, say] of [[300, "News in 5 minutes: " + name], [60, "News in 1 minute: " + name + ". Be careful."], [20, "News starts in 20 seconds: " + name], [0, "News released: " + name]]) {
    const key = n.ts + "-" + thr; if (secs <= thr && secs > thr - 20 && !ENGINE.spoken[key]) { ENGINE.spoken[key] = 1; engSay(say); break; }
  }
}
function engVoiceBtn(btn) {
  const paint = () => { btn.textContent = ENGINE.voice ? "Voice: on" : "Voice: off"; btn.classList.toggle("on", ENGINE.voice); };
  btn.onclick = () => { ENGINE.voice = !ENGINE.voice; try { localStorage.setItem("cl.voice", ENGINE.voice ? "1" : "0"); } catch {} paint(); if (ENGINE.voice) engSay("Voice alerts on. I will warn you before high impact news."); else try { speechSynthesis.cancel(); } catch {} };
  paint();
}
const hmsOf = (t) => new Date(t).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
function engCard(s) {
  const res = (r) => (r === "win" ? `<span class="rtag w">WIN</span>` : r === "loss" ? `<span class="rtag l">LOSS</span>` : r === "expired" ? `<span class="rtag x">EXPIRED</span>` : `<span class="rtag o">OPEN</span>`);
  if (s.mkt === "digits") return `<article class="card aicard"><div class="aihead"><b>${esc(s.name)}</b>${res(s.res)}</div><div class="aimain"><span class="dirtag">${esc(s.contract.replace("DIGIT", ""))}${s.barrier !== null && s.barrier !== undefined ? " " + s.barrier : ""}</span><span class="note">1 tick</span></div><p class="note">${esc(s.reason)}</p><p class="note small">Signal time ${hmsOf(s.t)}${s.digit !== undefined ? " | next digit " + s.digit : ""}</p></article>`;
  return `<article class="card aicard"><div class="aihead"><b>${esc(s.name)}</b>${res(s.res)}</div><div class="aimain"><span class="dirtag ${s.dir === "BUY" ? "up" : "dn"}">${s.dir}</span><span class="note">score ${s.score}/5</span></div>
    <div class="aigrid"><span>Entry</span><b>${s.entry}</b><span>Stop loss</span><b>${s.sl}</b><span>Take profit</span><b>${s.tp}</b><span>Scalp SL / TP</span><b>${s.sl1} / ${s.tp1} ${res(s.res1)}</b></div>
    <p class="note">${esc(s.reason)}</p><p class="note small">Signal time ${hmsOf(s.t)}</p></article>`;
}
// the AI Analyser list inside the Signals screens
function viewAIFeed(body, kinds) {
  let kind = kinds[0][0], dead = false, timer = 0;
  body.innerHTML = `${kinds.length > 1 ? `<div class="chips" id="aiK">${kinds.map(([k, n]) => `<button class="chip" data-k="${k}" type="button">${n}</button>`).join("")}</div>` : ""}<div id="aiStats"></div><div id="aiList" class="grid"><p class="note">Loading...</p></div><p class="note">The AI Analyser gives analysis, not advice or a promise of profit. The results shown are measured from its own past signals. Use the stop loss.</p>`;
  const paint = async () => {
    if (dead) return; kinds.length > 1 && body.querySelectorAll("#aiK .chip").forEach((b) => b.setAttribute("aria-pressed", b.dataset.k === kind));
    try {
      const d = await engGet("/engine/signals?mkt=" + kind); if (dead) return;
      const st = d.stats && d.stats[kind], rate = st && st.rate !== null ? st.rate + "% of " + st.n + " signals hit the target" : st && st.n ? st.n + " checked so far, too few for a win rate" : "no checked signals yet";
      $("#aiStats", body).innerHTML = `<p class="note"><b>Measured result (${kind === "digits" ? "if entered at signal time" : "full target before stop loss"}):</b> ${esc(rate)}${st ? ` | wins ${st.w}, losses ${st.l}` : ""}</p>`;
      $("#aiList", body).innerHTML = d.online ? (d.signals.length ? d.signals.map(engCard).join("") : `<p class="note">No signal right now. The engine checks every minute and only publishes a setup that passes its checks.</p>`) : `<div class="warn engoff"><b>ENGINE OFFLINE.</b> The AI Analyser is not running, so there are no AI signals. Use the Scanner.</div>`;
    } catch (e) { $("#aiList", body).innerHTML = `<p class="note">${esc(e.message)}</p>`; }
    timer = setTimeout(paint, 20000);
  };
  body.onclick = (e) => { const b = e.target.closest("[data-k]"); if (b) { kind = b.dataset.k; clearTimeout(timer); paint(); } };
  paint();
  return () => { dead = true; clearTimeout(timer); };
}
// Scanner or AI Analyser: the client chooses. If the engine is offline the AI choice shows the red warning and the scanner is used.
function viewWithSource(main, key, kinds, scannerView, title, lede) {
  let src = (() => { try { return localStorage.getItem("cl.src." + key) === "ai" ? "ai" : "scanner"; } catch { return "scanner"; } })(), stopAI = null;
  main.append(el(`<section class="srcv"><span class="badge">${esc(title)}</span><div class="srcbar"><div class="chips" id="srcChips"><button class="chip" data-s="scanner" type="button">Scanner</button><button class="chip" data-s="ai" type="button">AI Analyser</button></div><span id="enPill"></span><button class="btn ghost sm" id="voiceBtn" type="button"></button></div><p class="note">${esc(lede)}</p><div id="srcBody"></div></section>`));
  engVoiceBtn($("#voiceBtn", main));
  const body = $("#srcBody", main);
  const show = () => {
    main.querySelectorAll("#srcChips .chip").forEach((b) => b.setAttribute("aria-pressed", b.dataset.s === src));
    $("#enPill", main).innerHTML = engPill();
    try { stopAI && stopAI(); } catch {} stopAI = null; stopCharts(); stopScanner(); body.innerHTML = "";
    const offline = !ENGINE.st || !ENGINE.st.online;
    if (src === "ai" && ENGINE.st && !offline) { stopAI = viewAIFeed(body, kinds); return; }
    if (src === "ai" && ENGINE.st && offline) body.append(el(`<div class="warn engoff"><b>ENGINE OFFLINE.</b> The AI Analyser is not running, so only the scanner works right now.</div>`));
    const inner = el(`<div></div>`); body.append(inner); scannerView(inner);
  };
  let lastOnline = null;
  const onSt = () => { if (!$("#enPill", main)) return; $("#enPill", main).innerHTML = engPill(); const o = !!(ENGINE.st && ENGINE.st.online); if (lastOnline !== null && o !== lastOnline && src === "ai") show(); lastOnline = o; };
  ENGINE.subs.push(onSt);
  main.onclick = (e) => { const b = e.target.closest("#srcChips [data-s]"); if (!b || b.dataset.s === src) return; src = b.dataset.s; try { localStorage.setItem("cl.src." + key, src); } catch {} show(); };
  engRefresh().finally(() => { lastOnline = !!(ENGINE.st && ENGINE.st.online); show(); });
}
const viewSignalsSrc = (main) => viewWithSource(main, "fx", [["forex", "Forex and gold"]], viewSignals, "Forex signals", "Choose how you get signals: the scanner on this site, or the AI Analyser (reads prices, news and world events). If the AI Analyser is offline, only the scanner works.");
const viewScannerSrc = (main) => viewWithSource(main, "dv", [["digits", "Digit entries"], ["synth", "Synthetic indices"]], viewScanner, "Deriv", "Scanner = the live scanner on this site. AI Analyser = entries found by the cloud engine. Digit patterns are triggers, not predictions: the next digit is random.");

/* ---------- MT5 Control: live account, open trades, close buttons, start/stop for each robot ---------- */
const MT5_BOTS = [["xauusd-system", "ChartLord System"], ["straddle-system", "Straddle System"]];
async function viewMt5(main) {
  const st = state.mt5 || (state.mt5 = { d: null, err: "", busy: "" });
  main.append(el(`<section class="mt5v"><span class="badge">Forex</span><h1>MT5 <em>Control</em></h1><p class="lede">Your MT5 account and your robots in one place. Start or stop a robot, see the open trades and close them. The MT5 chart shows the same colors: <b class="cg">green</b> on, <b class="cs">amber</b> standby, <b class="cr">red</b> danger, news or error, <b class="cx">grey</b> off.</p><div id="mtAi"></div><div id="mtAcct"></div><div id="mtBots"></div></section>`));
  let timer = 0, dead = false;
  chartStop = () => { dead = true; clearInterval(timer); };
  const f2 = (n) => (Number(n) || 0).toFixed(2), sgn = (n) => (n >= 0 ? "+" : "") + f2(n);
  const ago = (t) => { const s = Math.max(0, Math.round((Date.now() - t) / 1000)); return s < 90 ? s + " s ago" : Math.round(s / 60) + " min ago"; };
  const api2 = async () => {
    const r = await fetch(CONFIG.payApi + "/broker", { headers: { "X-Token": tokenOf() } });
    const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || "Could not reach the server."); return d;
  };
  // color of a robot: grey = off or offline, green = running, red = danger (loss lock, news, error, no licence)
  const colour = (r) => {
    const s = r.status; if (!s || !s.online) return ["x", "OFFLINE", "MT5 is not connected to this robot."];
    const t = String(s.state || "");
    if (/^NO LICENCE/i.test(t)) return ["r", "NO LICENCE", "Check your EA key and licence."];
    if (/^LOCKED/i.test(t)) return ["r", "LOCKED", "Daily loss limit reached. It starts again tomorrow."];
    if (!r.run || /^STOPPED/i.test(t)) return ["x", "OFF", "Stopped from this page."];
    const body = t.replace(/^RUNNING - /, "");
    if (/AI ENGINE OFFLINE/.test(t)) return ["r", "AI ENGINE OFFLINE", body];
    if (/news/i.test(t)) return ["r", "NEWS", body];
    if (/not reachable|WebRequest|error|locked to|Algo Trading is off/i.test(t)) return ["r", "ERROR", body];
    if (!/^ready/.test(body)) return ["s", "STANDBY", body];   // on, but waiting (spread, pause, market closed, trades open)
    return ["g", "ON", body];
  };
  const paintAi = () => {
    const E = $("#mtAi"); if (!E) return; const s = ENGINE.st, [c, w, why] = engLook(), robots = (st.d && st.d.robots) || [], mode = (robots.find((r) => r.ai && r.ai !== "off") || {}).ai || "off", owner = !!store.get("owner");
    E.innerHTML = `<div class="epanel mt5bot ${c}"><div class="mt5head"><h3>AI Analyser</h3><span class="mpill ${c}"><i></i>${esc(w)}</span><button class="btn ghost sm" id="mtVoice" type="button"></button></div><p class="note">${esc(why)}</p>
      <p class="note"><b>AI trading on my MT5:</b> the AI Analyser finds the gold entry, stop loss and take profit and your robot places it. It never trades when the engine is offline.</p>
      <div class="chips" id="mtMode">${[["off", "Off"], ["scalp", "Scalping"], ["intraday", "Intraday (long)"]].map(([k, n]) => `<button class="chip" data-m="${k}" aria-pressed="${mode === k}" type="button">${n}</button>`).join("")}</div>
      <div class="row">${owner ? `<button class="btn ${s && s.on ? "ghost danger" : ""}" id="mtEng" type="button">${s && s.on ? "Switch AI engine OFF" : "Switch AI engine ON"}</button>` : ""}<a class="btn ghost" id="mtOpen" href="${esc(CONFIG.engineUrl || "#")}" target="_blank" rel="noopener">Open AI Analyser site</a></div><p class="note small" id="mtAiMsg"></p></div>`;
    engVoiceBtn($("#mtVoice"));
    $("#mtOpen").onclick = (e) => { if (!CONFIG.engineUrl) return; e.preventDefault(); window.open(CONFIG.engineUrl + "/#t=" + encodeURIComponent(tokenOf()), "_blank", "noopener"); };
  };
  ENGINE.subs.push(() => { if (!dead) paintAi(); });
  const paint = () => {
    paintAi();
    const A = $("#mtAcct"), B = $("#mtBots"); if (!A || !B) return;
    if (st.err) { A.innerHTML = `<div class="epanel"><p class="note">${esc(st.err)}</p></div>`; B.innerHTML = ""; return; }
    const d = st.d; if (!d) { A.innerHTML = `<p class="note">Loading...</p>`; return; }
    const live = d.live, bk = d.broker;
    A.innerHTML = live ? `<div class="ecards"><div class="ecard"><i class="ic a">$</i><div><span>Balance</span><b>${f2(live.balance)}</b></div></div><div class="ecard"><i class="ic b">&#9650;</i><div><span>Equity</span><b>${f2(live.equity)}</b></div></div><div class="ecard"><i class="ic c">&#8596;</i><div><span>Today</span><b class="${live.today >= 0 ? "up" : "dn"}">${sgn(live.today)}</b></div></div><div class="ecard"><i class="ic d">#</i><div><span>Open trades</span><b>${live.open}</b></div></div></div><p class="note">${esc(bk?.name || "Broker")} | login ${esc(live.login)} | ${esc(live.server)} | updated ${ago(live.t)}</p>` : `<div class="epanel"><p class="note">No robot is connected yet. Put a ChartLord robot on an XAUUSD chart with your EA key.</p></div>`;
    const mine = (d.robots || []).filter((r) => d.has && d.has[r.bot]);
    B.innerHTML = mine.length ? mine.map((r) => {
      const [c, word, why] = colour(r), pos = (r.status && r.status.online && r.status.pos) || [], tot = pos.reduce((a, x) => a + x.p, 0);
      return `<div class="epanel mt5bot ${c}" data-bot="${r.bot}"><div class="mt5head"><h3>${esc(r.name)}</h3><span class="mpill ${c}"><i></i>${word}</span><button class="btn ${r.run ? "ghost" : ""}" data-act="run" type="button">${r.run ? "Stop robot" : "Start robot"}</button></div>
        <p class="note">${esc(why)}</p>
        ${pos.length ? `<div class="tblw"><table class="mt5tbl"><thead><tr><th>Ticket</th><th>Type</th><th>Lots</th><th>Open</th><th>Profit</th><th>Open for</th><th></th></tr></thead><tbody>${pos.map((x) => `<tr><td>${esc(x.t)}</td><td class="${x.s === "BUY" ? "up" : "dn"}">${x.s}</td><td>${f2(x.l)}</td><td>${x.o}</td><td class="${x.p >= 0 ? "up" : "dn"}">${sgn(x.p)}</td><td>${x.a < 90 ? x.a + " s" : Math.round(x.a / 60) + " min"}</td><td><button class="btn ghost sm" data-act="close" data-tk="${esc(x.t)}" type="button">Close</button></td></tr>`).join("")}</tbody></table></div><p class="note">Total ${sgn(tot)}</p>
        <div class="row"><button class="btn ghost" data-act="closeProfit" type="button">Close winners</button><button class="btn ghost" data-act="closeLoss" type="button">Close losers</button><button class="btn ghost danger" data-act="closeAll" type="button">Close all</button></div>` : `<p class="note">No open trades.</p>`}
        <p class="note small" data-msg></p></div>`;
    }).join("") : `<div class="epanel"><p class="note">Buy a ChartLord robot in Forex bots to control it here.</p></div>`;
  };
  const load = async () => { try { st.d = await api2(); st.err = ""; } catch (e) { st.err = e.message; } if (!dead && !st.busy) paint(); };
  main.onclick = async (e) => {
    const mb = e.target.closest("#mtMode [data-m]");
    if (mb) { const m = $("#mtAiMsg"); try { await engGet("/engine/mode", { mode: mb.dataset.m }); m.textContent = "Saved. Your robot follows within a few seconds."; await load(); } catch (er) { m.textContent = er.message; } return; }
    if (e.target.closest("#mtEng")) { const m = $("#mtAiMsg"), on = !(ENGINE.st && ENGINE.st.on); try { await engGet("/engine/switch", { on }, true); await engRefresh(); m.textContent = on ? "AI engine switched on." : "AI engine switched off. Everything AI goes grey, on both sites."; } catch (er) { m.textContent = er.message; } return; }
    const b = e.target.closest("button[data-act]"); if (!b) return;
    const box = b.closest("[data-bot]"), bot = box.dataset.bot, act = b.dataset.act, msg = box.querySelector("[data-msg]");
    if (act === "closeAll" && !confirm("Close ALL open trades of this robot?")) return;
    if (act === "closeLoss" && !confirm("Close every losing trade of this robot?")) return;
    st.busy = bot; b.disabled = true;
    try {
      if (act === "run") { const cur = (st.d.robots || []).find((r) => r.bot === bot); await eaApi({ cfg: { run: !cur.run } }, bot); }
      else if (act === "closeAll") await eaApi({ closeAll: true }, bot);
      else await eaApi({ cmd: { op: act, ticket: b.dataset.tk || "" } }, bot);
      if (msg) msg.textContent = act === "run" ? "Done. MT5 follows within a few seconds." : "Sent. MT5 runs it within a few seconds.";
    } catch (er) { if (msg) msg.textContent = er.message; }
    st.busy = ""; setTimeout(load, 1500);
  };
  load(); timer = setInterval(load, 5000);
}
/* ---------- News: impact and non-impact events, countdown, and the after-release signal ---------- */
const NEWS_CCY = ["All", "USD", "EUR", "GBP", "JPY", "AUD", "CAD", "NZD", "CHF"];
async function viewNews(main) {
  const st = state.news || (state.news = { grp: "impact", ccy: "All", sel: "", events: null, err: "" });
  main.append(el(`<section class="newsv"><span class="badge">News</span><h1>Impact and <em>non-impact</em> news</h1><p class="lede">Every event with its day and time (your time zone: ${esc(Intl.DateTimeFormat().resolvedOptions().timeZone || "local")}), a countdown, and a signal after the release.</p>
    <div id="nHero"></div><div class="chips" id="nGrp"><button class="chip" data-g="impact" type="button">Impact news (high and medium)</button><button class="chip" data-g="non" type="button">Non-impact news (low)</button></div>
    <div class="chips" id="nCcy">${NEWS_CCY.map((c) => `<button class="chip" data-c="${c}" type="button">${c}</button>`).join("")}</div>
    <div id="nSig"></div><div id="nList" class="nlist"><p class="note">Loading the calendar...</p></div></section>`));
  let timer = 0, client = null, dead = false, candles = {}, subKey = "";
  chartStop = () => { dead = true; clearInterval(timer); try { client?.close(); } catch {} };
  const day = (t) => new Date(t).toLocaleDateString([], { weekday: "long", day: "numeric", month: "short" });
  const hm = (t) => new Date(t).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });
  const sod = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); };
  const visible = () => (st.events || []).filter((e) => e.ts >= sod() && N.IMPACT_GROUP(e.impact) === st.grp && (st.ccy === "All" || e.country === st.ccy));
  const pickDefault = () => { const now = Date.now(), hi = (st.events || []).filter((e) => /high/i.test(e.impact) && now - e.ts <= N.WINDOW_MS); const e = hi[0] || visible().find((x) => now - x.ts <= N.WINDOW_MS); return e ? e.id : ""; };
  const sel = () => (st.events || []).find((e) => e.id === st.sel);
  const badge = (i) => `<span class="imp ${/high/i.test(i) ? "hi" : /medium/i.test(i) ? "md" : "lo"}">${/high/i.test(i) ? "High impact" : /medium/i.test(i) ? "Medium impact" : /holiday/i.test(i) ? "Holiday" : "Low impact"}</span>`;
  const ago = (ms) => { const m = Math.round(ms / 60000); return m < 1 ? "just now" : m < 60 ? m + " min ago" : Math.round(m / 60) + " h ago"; };
  const paintHero = () => {
    const now = Date.now(), nx = (st.events || []).filter((e) => /high/i.test(e.impact) && e.ts > now)[0], live = (st.events || []).find((e) => /high/i.test(e.impact) && N.eventState(e, now) === "live");
    const e = live || nx; const h = $("#nHero"); if (!h) return;
    h.innerHTML = e ? `<div class="nhero ${live ? "live" : ""}"><div><span class="note">${live ? "Released just now" : "Next high impact news"}</span><h3>${esc(e.country)} ${esc(e.title)}</h3><span class="note">${day(e.ts)} at ${hm(e.ts)}</span></div><div class="ncd" data-cd="${e.ts}">${live ? "LIVE" : N.fmtCountdown(e.ts - now)}</div></div>` : "";
  };
  const tick = () => { const now = Date.now(); document.querySelectorAll("[data-cd]").forEach((n) => { const t = Number(n.dataset.cd), d = t - now; n.textContent = d > 0 ? N.fmtCountdown(d) : d > -N.WINDOW_MS ? "LIVE" : ago(-d); n.classList.toggle("live", d <= 0 && d > -N.WINDOW_MS); }); document.querySelectorAll("#nHero .ncd[data-cd]").forEach((n) => { if (Number(n.dataset.cd) - now > 0) n.textContent = N.fmtCountdown(Number(n.dataset.cd) - now); }); };
  const paintList = () => {
    $("#nGrp").querySelectorAll("button").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.g === st.grp)));
    $("#nCcy").querySelectorAll("button").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.c === st.ccy)));
    const L = $("#nList");
    if (st.err) { L.innerHTML = `<p class="note">${esc(st.err)}</p><button class="btn" id="nRetry" type="button">Try again</button>`; $("#nRetry").onclick = load; return; }
    const v = visible(); if (!v.length) { L.innerHTML = `<p class="note">No ${st.grp === "impact" ? "impact" : "non-impact"} news in this list for ${st.ccy === "All" ? "now" : st.ccy}.</p>`; return; }
    let cur = "", html = "";
    for (const e of v) {
      const dk = day(e.ts); if (dk !== cur) { cur = dk; html += `<h4 class="nday">${new Date(e.ts).toDateString() === new Date().toDateString() ? "Today" : dk}</h4>`; }
      const s = N.eventState(e, Date.now());
      html += `<button class="nrow ${s} ${e.id === st.sel ? "sel" : ""}" data-e="${esc(e.id)}" type="button"><span class="ntime">${hm(e.ts)}</span><span class="nbody"><b>${esc(e.country)} ${esc(e.title)}</b><em>${badge(e.impact)}${e.forecast ? ` Forecast ${esc(e.forecast)}` : ""}${e.previous ? ` | Previous ${esc(e.previous)}` : ""}</em></span><span class="ncd" data-cd="${e.ts}"></span></button>`;
    }
    L.innerHTML = html; tick();
  };
  const hms = (t) => new Date(t).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false });
  const sigCard = (pair, r, tsent) => {
    const nm = pair === "XAUUSD" ? "Gold (XAUUSD)" : pair;
    if (r.status !== "signal") return `<div class="nsig"><div class="nsh"><b>${nm}</b><span class="note">${r.status === "none" ? "No trade" : r.status === "expired" ? "Expired" : "Waiting"}</span></div><p class="note">${esc(r.text)}</p></div>`;
    return `<div class="nsig ${r.dir > 0 ? "buy" : "sell"}"><div class="nsh"><b>${nm}</b><span class="side">${r.side}</span></div>${tsent ? `<p class="stime">Signal sent at <b>${hms(tsent)}</b> (${ago(Date.now() - tsent)})</p>` : ""}<div class="nlv"><div><span>Entry</span><b>${r.fmt(r.entry)}</b></div><div><span>Stop loss</span><b>${r.fmt(r.sl)}</b></div><div><span>Take profit 1</span><b>${r.fmt(r.tp1)}</b></div><div><span>Take profit 2</span><b>${r.fmt(r.tp2)}</b></div></div><p class="note">Why: ${esc(r.text)}</p></div>`;
  };
  st.ai = st.ai || {};
  const aiBox = (e) => {
    const a = st.ai[e.id];
    if (!a) return `<div class="ainews"><button class="btn" data-ai="${esc(e.id)}" type="button">AI analysis of this news</button><p class="note">The AI explains what this news is, what may be spoken about, and how it can move gold, the dollar and indices.</p></div>`;
    if (a.loading) return `<div class="ainews"><p class="note">The AI is reading this news...</p></div>`;
    if (a.err) return `<div class="ainews"><p class="note">${esc(a.err)}</p><button class="btn ghost" data-ai="${esc(e.id)}" type="button">Try again</button></div>`;
    const d = a.data, row = (k, v) => v ? `<div class="airow"><b>${k}</b><span>${esc(v)}</span></div>` : "";
    return `<div class="ainews"><h4>AI analysis</h4><p>${esc(d.summary)}</p>${d.whySpoken?.length ? `<h5>What may be spoken about / what to watch</h5><ul>${d.whySpoken.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : ""}${row("If better than forecast", d.better)}${row("If worse than forecast", d.worse)}${row("If as expected", d.inline)}${row("Gold", d.gold)}${row("US dollar", d.usd)}${row("Indices", d.indices)}${row("Main risk", d.risk)}<p class="note">An AI explanation, not a prediction. It can be wrong. The real number and the price reaction decide.</p></div>`;
  };
  const runAI = async (id) => {
    st.ai[id] = { loading: true }; paintSig();
    try {
      const r = await fetch(CONFIG.payApi + "/news/analyze", { method: "POST", headers: { "Content-Type": "application/json", "X-Token": tokenOf() }, body: JSON.stringify({ id }) });
      const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || "Could not reach the server.");
      st.ai[id] = { data: d };
    } catch (e) { st.ai[id] = { err: e.message }; }
    if (!dead) paintSig();
  };
  const paintSig = () => {
    const e = sel(), B = $("#nSig"); if (!B) return; if (!e) { B.innerHTML = `<p class="note">Tap a news row to see its signal.</p>`; return; }
    const now = Date.now(), s = N.eventState(e, now), pairs = N.PAIRS[e.country] || [];
    let body;
    if (!pairs.length) body = `<p class="note">${esc(e.country)} news has no pair on this screen.</p>`;
    else if (s === "upcoming") body = `<h4>Before the release (lean only)</h4>${N.preLean(e).map((x) => `<p class="lean ${x.dir > 0 ? "up" : x.dir < 0 ? "dn" : ""}">${esc(x.text)}</p>`).join("")}<p class="note"><b>Do not enter before the release.</b> Spreads widen and price jumps both ways. The live signal appears at ${hm(e.ts)} once price has reacted. A forecast lean is a weak guide: the actual number decides.</p>`;
    else body = `<h4>Live signal after the release</h4>${pairs.map((p) => sigCard(p, N.reactionSignal(p, e, candles[p] || [], now), N.signalTime(p, e, candles[p] || []))).join("")}`;
    const ai = /^(high|medium)$/i.test(e.impact) ? aiBox(e) : "";
    B.innerHTML = `<div class="nselect"><div class="ephead"><h3>${esc(e.country)} ${esc(e.title)}</h3>${badge(e.impact)}</div><p class="note">${day(e.ts)} at ${hm(e.ts)} | ${s === "upcoming" ? "starts in" : s === "live" ? "released" : "released"} <b data-cd="${e.ts}"></b></p>${body}${ai}<p class="note">Signals are rules, not promises. News can spike both ways and slippage is common. Use a demo account first and risk only what you can lose.</p></div>`; tick();
  };
  const subscribe = async () => {
    const e = sel(); const pairs = e ? (N.PAIRS[e.country] || []) : []; const key = pairs.join(",");
    if (key === subKey) return; subKey = key; try { client?.close(); } catch {} client = null; candles = {}; if (!pairs.length) return;
    try {
      client = new DerivClient({ mode: "public" }); await client.connect();
      for (const p of pairs) await client.subscribe({ ticks_history: N.derivSymbol(p), adjust_start_time: 1, count: 60, end: "latest", granularity: 60, style: "candles" }, (m, err) => {
        if (dead || err) return;
        if (m.candles) candles[p] = m.candles.map((c) => ({ open: +c.open, high: +c.high, low: +c.low, close: +c.close, epoch: c.epoch }));
        else if (m.ohlc) { const a = candles[p] || (candles[p] = []), o = { open: +m.ohlc.open, high: +m.ohlc.high, low: +m.ohlc.low, close: +m.ohlc.close, epoch: m.ohlc.open_time }, l = a[a.length - 1]; if (l && l.epoch === o.epoch) a[a.length - 1] = o; else { a.push(o); if (a.length > 60) a.shift(); } }
      });
    } catch {}
  };
  async function load() {
    try { const d = await getJ("/news"); if (d.error) throw new Error(d.error); st.events = d.events; st.err = ""; if (!sel()) st.sel = pickDefault(); }
    catch (e) { st.err = e.message || "Could not load the calendar."; }
    if (dead) return; paintHero(); paintList(); paintSig(); subscribe();
  }
  main.onclick = (e) => {
    const g = e.target.closest("[data-g]"), c = e.target.closest("[data-c]"), r = e.target.closest("[data-e]"), ai = e.target.closest("[data-ai]");
    if (ai) return runAI(ai.dataset.ai);
    if (g) { st.grp = g.dataset.g; paintList(); } else if (c) { st.ccy = c.dataset.c; paintList(); }
    else if (r) { st.sel = r.dataset.e; paintList(); paintSig(); subscribe(); $("#nSig").scrollIntoView({ block: "nearest", behavior: "smooth" }); }
  };
  if (st.events) { paintHero(); paintList(); paintSig(); subscribe(); } 
  load();
  let n = 0; timer = setInterval(() => { tick(); n++; if (n % 3 === 0) { paintHero(); if (st.sel) paintSig(); } if (n % 600 === 0) load(); }, 1000);
}

/* ---------- Markets screen: Forex (pairs and metals) and Deriv (synthetics) ---------- */
const FX_LIST = PO.MARKETS.filter((m) => m.cat === "forex" || /XAU|XAG/.test(m.id)).map((m) => [m.id, m.name]);
const DERIV_SYNTH = [["R_10", "Volatility 10 Index"], ["R_25", "Volatility 25 Index"], ["R_50", "Volatility 50 Index"], ["R_75", "Volatility 75 Index"], ["R_100", "Volatility 100 Index"],
  ["1HZ10V", "Volatility 10 (1s) Index"], ["1HZ25V", "Volatility 25 (1s) Index"], ["1HZ50V", "Volatility 50 (1s) Index"], ["1HZ75V", "Volatility 75 (1s) Index"], ["1HZ100V", "Volatility 100 (1s) Index"],
  ["1HZ150V", "Volatility 150 (1s) Index"], ["1HZ250V", "Volatility 250 (1s) Index"],
  ["BOOM300N", "Boom 300 Index"], ["BOOM500", "Boom 500 Index"], ["BOOM1000", "Boom 1000 Index"], ["CRASH300N", "Crash 300 Index"], ["CRASH500", "Crash 500 Index"], ["CRASH1000", "Crash 1000 Index"],
  ["JD10", "Jump 10 Index"], ["JD25", "Jump 25 Index"], ["JD50", "Jump 50 Index"], ["JD75", "Jump 75 Index"], ["JD100", "Jump 100 Index"], ["stpRNG", "Step Index"]];
function viewMarkets(main) {
  const sec = state.mkSec || "";
  if (!sec) {
    main.append(el(`<section><span class="badge">Markets</span><h1>Choose markets</h1><p class="lede">Live candle charts from Deriv.</p>
      <div class="choose"><button class="choice" data-mk="forex" type="button">${ICON_FX}<h2>Forex markets</h2><p>All forex pairs and metals (gold, silver).</p><span class="btn">Open</span></button>
      <button class="choice" data-mk="deriv" type="button">${ICON_BIN}<h2>Deriv markets</h2><p>Deriv synthetic indices only: Volatility, Boom, Crash, Jump and Step.</p><span class="btn">Open</span></button></div></section>`));
    main.onclick = (e) => { const b = e.target.closest("[data-mk]"); if (b) { state.mkSec = b.dataset.mk; render(); } };
    return;
  }
  const list = sec === "forex" ? FX_LIST : DERIV_SYNTH;
  if (!list.some(([id]) => id === state.mkSym)) state.mkSym = list[0][0];
  const gran = state.mkGran || 300, sym = state.mkSym, nm = (list.find(([id]) => id === sym) || [sym, sym])[1];
  main.append(el(`<section><div class="row" style="justify-content:space-between"><div><span class="badge">${sec === "forex" ? "Forex" : "Deriv"}</span><h1>${sec === "forex" ? "Forex markets" : "Deriv markets"}</h1></div><button class="btn ghost" id="mkBack" type="button">Back</button></div>
    <div class="chips mkchips" id="mkSyms">${list.map(([id, n]) => `<button class="chip" data-sym="${esc(id)}" aria-pressed="${id === sym}" type="button">${esc(n.replace(/ Index$/, ""))}</button>`).join("")}</div>
    <div class="chips" id="mkTf">${[[60, "1m"], [300, "5m"], [900, "15m"], [3600, "1h"], [14400, "4h"]].map(([g, n]) => `<button class="chip" data-g="${g}" aria-pressed="${g === gran}" type="button">${n}</button>`).join("")}</div>
    <div class="tickbox"><div class="tickhead"><b>${esc(nm)}</b><span id="mkPx" class="note">Loading chart...</span></div><canvas id="mkCv" width="900" height="420"></canvas></div></section>`));
  $("#mkBack").onclick = () => { state.mkSec = ""; render(); };
  $("#mkSyms").onclick = (e) => { const b = e.target.closest("[data-sym]"); if (b) { state.mkSym = b.dataset.sym; render(); } };
  $("#mkTf").onclick = (e) => { const b = e.target.closest("[data-g]"); if (b) { state.mkGran = Number(b.dataset.g); render(); } };
  $("#mkSyms .chip[aria-pressed=true]")?.scrollIntoView({ inline: "center", block: "nearest" });
  let client = null, dead = false, candles = [];
  const draw = () => {
    const cv = $("#mkCv"); if (!cv || candles.length < 2) return;
    const g = cv.getContext("2d"), W = cv.width, H = cv.height, padR = 120, padB = 26; g.clearRect(0, 0, W, H);
    const lo = Math.min(...candles.map((c) => c.low)), hi = Math.max(...candles.map((c) => c.high)), pad = (hi - lo) * 0.06 || 1;
    const y = (p) => (H - padB) - ((p - lo + pad) / (hi - lo + 2 * pad)) * (H - padB), cw = (W - padR) / candles.length;
    const css = getComputedStyle(document.documentElement), up = css.getPropertyValue("--green").trim() || "#22c55e", dn = css.getPropertyValue("--red").trim() || "#ef4444", mute = css.getPropertyValue("--muted").trim() || "#8b95a7";
    g.font = "20px sans-serif"; g.fillStyle = mute; g.strokeStyle = mute; g.globalAlpha = 0.25; g.lineWidth = 1;
    for (let i = 0; i <= 4; i++) { const v = lo - pad + ((hi - lo + 2 * pad) * i) / 4, yy = y(v); g.beginPath(); g.moveTo(0, yy); g.lineTo(W - padR, yy); g.stroke(); g.globalAlpha = 1; g.fillText(v.toFixed(v > 100 ? 2 : 5), W - padR + 6, yy + 6); g.globalAlpha = 0.25; }
    g.globalAlpha = 1;
    candles.forEach((c, i) => {
      const x = i * cw + cw / 2, col = c.close >= c.open ? up : dn; g.strokeStyle = col; g.fillStyle = col; g.lineWidth = 2;
      g.beginPath(); g.moveTo(x, y(c.high)); g.lineTo(x, y(c.low)); g.stroke();
      const top = y(Math.max(c.open, c.close)), h = Math.max(2, Math.abs(y(c.open) - y(c.close))); g.fillRect(x - cw * 0.32, top, cw * 0.64, h);
    });
    const last = candles[candles.length - 1]; $("#mkPx").textContent = `${last.close}  ·  ${new Date(last.epoch * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
  };
  (async () => {
    try {
      client = new DerivClient({ mode: "public" }); await client.connect();
      await client.subscribe({ ticks_history: sym, adjust_start_time: 1, count: 100, end: "latest", granularity: gran, style: "candles" }, (m, err) => {
        if (dead) return;
        if (err) { $("#mkPx").textContent = "No chart for this market right now."; return; }
        if (m.candles) candles = m.candles.map((c) => ({ open: +c.open, high: +c.high, low: +c.low, close: +c.close, epoch: c.epoch }));
        else if (m.ohlc) { const o = { open: +m.ohlc.open, high: +m.ohlc.high, low: +m.ohlc.low, close: +m.ohlc.close, epoch: m.ohlc.open_time }; const l = candles[candles.length - 1]; if (l && l.epoch === o.epoch) candles[candles.length - 1] = o; else { candles.push(o); if (candles.length > 100) candles.shift(); } }
        draw();
      });
    } catch { if (!dead) { const e = $("#mkPx"); if (e) e.textContent = "Could not reach live prices right now."; } }
  })();
  chartStop = () => { dead = true; try { client?.close(); } catch {} };
}
/* ---------- Trades screen: every trade opened on this device, by hour, day, week or month ---------- */
const tradeKey = () => "trades:" + (me.email || "anon");
const loadTrades = () => { try { return JSON.parse(store.get(tradeKey()) || "[]"); } catch { return []; } };
function saveTrade(t) { const l = loadTrades(); l.unshift(t); store.set(tradeKey(), JSON.stringify(l.slice(0, 1000))); }
const TR_RANGES = [["hour", "Hour", 3600e3], ["day", "Day", 86400e3], ["week", "Week", 7 * 86400e3], ["month", "Month", 30 * 86400e3], ["all", "All", Infinity]];
function viewTrades(main) {
  const rg = state.trRange || "day", span = TR_RANGES.find((r) => r[0] === rg)[2];
  const all = loadTrades(), list = all.filter((t) => Date.now() - t.t <= span);
  const pnl = list.reduce((a, t) => a + (Number(t.profit) || 0), 0), wins = list.filter((t) => t.won).length;
  main.append(el(`<section><span class="badge">Trades</span><h1>Your trades</h1>
    <div class="chips" id="trR">${TR_RANGES.map(([k, n]) => `<button class="chip" data-r="${k}" aria-pressed="${k === rg}" type="button">${n}</button>`).join("")}</div>
    <div class="trsum"><div><span class="note">Trades</span><b>${list.length}</b></div><div><span class="note">Won</span><b>${wins}</b></div><div><span class="note">Lost</span><b>${list.length - wins}</b></div><div><span class="note">Profit / loss</span><b class="${pnl >= 0 ? "up" : "dn"}">${money(pnl)}</b></div></div>
    <div class="mklist">${list.length ? list.slice(0, 300).map((t) => `<div class="hrow ${t.won ? "w" : "l"}"><span>${new Date(t.t).toLocaleString([], { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</span><b>${esc(marketName(t.symbol))}</b><em>${t.won ? "WON" : "LOST"} ${money(t.profit)}</em></div>`).join("") : `<p class="note">No trades in this period yet. Trades placed by your automated bots on this device appear here.</p>`}</div></section>`));
  main.onclick = (e) => { const b = e.target.closest("[data-r]"); if (b) { state.trRange = b.dataset.r; render(); } };
}
function viewHome(main) {
  main.append(el(`<section class="home"><span class="badge">Live trading workspace</span><h1>Choose your <em>market</em></h1>
  <p class="lede">Pick how you trade. Everything loads for the market you choose.</p>
  <div class="choose">
   <button class="choice" data-mode="binary">${ICON_BIN}<h2>Binary trading</h2><p>Deriv bots and automated trading, plus AI signals for Pocket Option, Quotex, IQ Option, ExpertOption and Olymp Trade.</p><span class="btn">Enter</span></button>
   <button class="choice" data-mode="forex">${ICON_FX}<h2>Forex trading</h2><p>SMC and ICT signals with entry, TP and SL, plus MT5 Expert Advisors.</p><span class="btn">Enter</span></button>
  </div></section>`));
  main.onclick = (e) => { const c = e.target.closest("[data-mode]"); if (c) enterMarket(c.dataset.mode); };
}
async function enterMarket(m) {
  await loadingScreen(m);
  if (m === "binary") { state.mode = "binary"; setTab("brokers"); } else setTab("signals");
}
// Brokers with AI signals only: the client trades on the broker's own site, this site never logs in or trades there.
const BROKER_INFO = { pocket: { name: "Pocket Option", url: "https://pocketoption.com" }, expert: { name: "ExpertOption", url: "https://expertoption.com" }, quotex: { name: "Quotex", url: "https://quotex.com" }, iq: { name: "IQ Option", url: "https://iqoption.com" }, olymp: { name: "Olymp Trade", url: "https://olymptrade.com" } };
const BROKERS = [["Deriv", "Bots, automated trading, live scanner and charts.", true, "deriv"], ...Object.entries(BROKER_INFO).map(([k, b]) => [b.name, "AI signals: BUY or SELL, market and time.", true, k])];
function viewBrokers(main) {
  state.mode = "binary";
  main.append(el(`<section><span class="badge">Binary trading</span><h1>Choose a broker</h1><p class="lede">Pick your broker. Deriv trades automatically from this site. The other brokers get AI signals that you place on the broker.</p>
  <div class="grid">${BROKERS.map(([n, d, on, key]) => `<article class="card ${on ? "" : "soon"}"><h3>${esc(n)}</h3><p>${on ? esc(d) : "Coming soon"}</p>${on ? `<div class="row"><button class="btn" data-broker="${key}">Open ${esc(n)}</button></div><span class="tag ok" style="align-self:flex-start">Active</span>` : `<span class="tag">Coming soon</span>`}</article>`).join("")}</div></section>`));
  main.onclick = async (e) => { const b = e.target.closest("[data-broker]"); if (b) { const k = b.dataset.broker; if (k !== "deriv") state.broker = k; await loadingScreen(k === "deriv" ? "deriv" : "binary"); setTab(k === "deriv" ? "deriv" : "pocket"); } };
}

/* ---------- Boot and loading screens ---------- */
function bootEl() { return $("#boot"); }
async function runBoot(title, steps, work) {
  const b = bootEl(); if (!b) return;
  b.hidden = false; b.classList.remove("out");
  const bar = $("#bootBar", b), pct = $("#bootPct", b), msg = $("#bootMsg", b); $("#bootTitle", b).textContent = title || "TRADERSPRO254";
  let p = 0; const set = (v, m) => { p = Math.max(p, v); bar.style.width = p + "%"; pct.textContent = Math.round(p) + "%"; if (m) msg.textContent = m; };
  set(4, steps[0]);
  const t0 = Date.now(); let i = 0;
  const tick = setInterval(() => { if (p < 92) set(p + 1.6); }, 60);
  const stepper = setInterval(() => { i = Math.min(i + 1, steps.length - 1); msg.textContent = steps[i]; }, 800);
  let note = "";
  try { note = (await work?.(set)) || ""; } catch {}
  const wait = Math.max(0, 2000 - (Date.now() - t0)); await new Promise((r) => setTimeout(r, wait));
  clearInterval(tick); clearInterval(stepper);
  set(100, note || "Ready"); await new Promise((r) => setTimeout(r, 450));
  b.classList.add("out"); await new Promise((r) => setTimeout(r, 350)); b.hidden = true;
}
const probeLive = async (set) => {
  const c = new DerivClient({ mode: "public" });
  const ok = await Promise.race([c.connect().then(() => true).catch(() => false), new Promise((r) => setTimeout(() => r(false), 6000))]);
  try { c.close(); } catch {}
  set?.(ok ? 80 : 60);
  return ok ? "Live market connected" : "Live market offline. Retrying inside the app";
};
const loadingScreen = (target) => runBoot(target === "forex" ? "FOREX WORKSPACE" : target === "binary" ? "BINARY WORKSPACE" : target === "deriv" ? "DERIV WORKSPACE" : "TRADERSPRO254",
  target === "forex" ? ["Loading forex pairs...", "Scanning FVG, structure and liquidity...", "Connecting to live market..."] : ["Loading bots...", "Scanning markets...", "Connecting to live market..."], probeLive);

/* ---------- Forex signals: one free signal per email, then 30 days for a fee ---------- */
const ago = (ms) => { const m = Math.max(0, Math.round((Date.now() - ms) / 60000)); return m < 1 ? "just now" : m < 60 ? m + " min ago" : Math.round(m / 60) + " h ago"; };
const left = (end, now) => { const h = Math.max(0, Math.floor((end - now) / 3600000)); return h >= 48 ? Math.floor(h / 24) + " days" : h + " hours"; };
function sigCard(s) {
  const buy = s.dir === "BUY", c = s.checks;
  const chip = (ok, t) => `<span class="tag ${ok ? "on" : "off"}">${ok ? "✓" : "–"} ${t}</span>`;
  return `<article class="card sig ${buy ? "buy" : "sell"}"><div class="sighead"><h3>${esc(s.symbol)} <span class="tag">${esc(s.tf)}</span></h3><span class="dir ${buy ? "buy" : "sell"}">${esc(s.dir)}</span></div>
  <div class="note">${esc(s.status)} · ${esc(s.event)} · score ${s.score}/${s.max}${s.killzone ? " · " + esc(s.killzone) + " killzone" : ""}</div>
  <div class="levels"><div><span>Entry</span><b>${s.entry}</b></div><div><span>Stop loss</span><b class="bad">${s.sl}</b></div><div><span>TP 1</span><b class="ok">${s.tp1}</b></div><div><span>TP 2</span><b class="ok">${s.tp2}</b></div></div>
  <div class="tags">${chip(c.fvg, "FVG")}${chip(c.structure, esc(s.event.split(" ")[0]))}${chip(c.orderBlock, "Order block")}${chip(c.sweep, "Liquidity sweep")}${chip(c.premiumDiscount, buy ? "Discount" : "Premium")}${chip(c.killzone, "Killzone")}</div>
  <div class="note">FVG zone ${s.zone[0]} - ${s.zone[1]} · price now ${s.price} · reward ${s.rr}R</div></article>`;
}
async function viewSignals(main) {
  main.append(el(`<section><span class="badge">Forex signals</span><h1>SMC and ICT signals</h1><div id="sigBody"><p class="note">Loading...</p></div></section>`));
  const body = $("#sigBody"); let timer = null, dead = false;
  scStop = () => { dead = true; clearTimeout(timer); };
  const next = (ms, scan) => { clearTimeout(timer); if (!dead) timer = setTimeout(() => load(scan), ms); };
  const price = () => priceText(SRV.signalsPrice);
  const intro = `<p class="lede">The scanner checks every pair on every timeframe for a fair value gap first, then structure (BOS or CHoCH) and ICT context, and only then gives an entry, TP and SL. Gold is scanned first. Weekdays only.</p>
    <div class="warn"><b>One free signal</b> for every email. After it hits take profit or stop loss, signals cost <b>${price()}</b> for 1 week.</div>`;
  const foot = `<p class="note">Signals are rule-based analysis, not advice or a promise of profit. Risk 1% or less per trade and use the stop loss.</p>`;
  const scanBtn = (label) => `<div class="row"><button class="btn big" id="scanBtn" type="button">${label}</button></div>`;
  const load = async (scan = false) => {
    if (dead) return;
    if (!tokenOf()) { body.innerHTML = intro + `<div id="af"></div>`; authForm($("#af"), () => load()); return; }
    let res;
    try { res = await api(scan ? "/signals/scan" : "/signals", scan ? {} : null, true); }
    catch { if (!$("#scanBtn") && !$("#sigList")) body.innerHTML = `<p class="note">Could not reach the server. Retrying...</p>`; return next(15000, scan); }
    if (dead) return;
    const { status, d } = res;
    if (status === 401 || status === 403) { body.innerHTML = intro + `<div id="af"></div>`; authForm($("#af"), () => load(), esc(d.error || "Please log in again.")); return; }
    if (status >= 500 || (status !== 200 && status !== 402)) { body.innerHTML = `<p class="note">${esc(d.error || "Server problem.")} Retrying...</p>`; return next(20000, scan); }
    if (d.paid) {
      const sc = d.closed ? "Market closed (weekend). Signals resume Monday." : `Scanned ${d.scan.ok} of ${d.scan.total} pair/timeframe charts. Updated ${ago(d.updated * 1)}.`;
      body.innerHTML = `<div class="row" style="justify-content:space-between"><span class="badge">Subscribed: ${left(d.subEnd, d.now)} left</span><span class="note">${sc}</span></div>
      <div id="sigList" class="grid">${d.signals.length ? d.signals.map(sigCard).join("") : `<p class="note">${d.closed ? "" : "No setup that passes every check right now. The scanner keeps looking and refreshes by itself."}</p>`}</div>${foot}`;
      return next(90000);
    }
    const f = d.free || { state: "none" };
    if (f.state === "pending") {
      body.innerHTML = `${intro}<div class="form"><h2 style="margin-top:0">Scanning...</h2><div class="cstat on"><i></i><span>Looking for your free signal. This stays on until one is found. Keep this page open.${d.closed ? " The market is closed at weekends, so it resumes on Monday." : ""}</span></div></div>${foot}`;
      return next(20000, true);
    }
    if (f.state === "active") {
      body.innerHTML = `<div class="warn">Your free signal is below. Trade it with the stop loss. When take profit or stop loss is hit you can scan again.</div><div class="grid">${sigCard(f.sig)}</div>${scanBtn("Scan signal")}${foot}`;
      $("#scanBtn").onclick = () => load(true);
      return next(60000);
    }
    if (f.state === "done") {
      const r = f.result === "tp" ? "Your free signal hit <b>take profit</b>." : f.result === "sl" ? "Your free signal hit <b>stop loss</b>." : "Your free signal expired.";
      body.innerHTML = `<div class="warn">${r} To get more signals, subscribe: <b>${price()}</b> for 1 week.</div>${scanBtn("Scan signal")}${foot}`;
      $("#scanBtn").onclick = () => buyFlow("signals");
      if (scan) buyFlow("signals");
      return;
    }
    body.innerHTML = `${intro}${scanBtn("Scan signal")}${foot}`;
    $("#scanBtn").onclick = () => load(true);
  };
  await load();
}

/* ---------- Forex AI scanner: scans H4, then H1, then M15/M5 for an entry, one market after another ---------- */
function viewAIScan(main) {
  main.append(el(`<section class="aisc"><span class="badge">Forex trading</span><h1>AI <em>Scanner</em></h1>
   <p class="lede">The AI reads the big trend on 4H, then 1H, then looks for the entry on 5 or 15 minutes. It trades with the trend, and for gold it also checks the oil chart. When it finds the best entry it sends the signal with entry, stop loss and take profit, and the checks it passed.</p>
   <div class="aicore idle" id="scCore"><div class="aihero">${CORE_SVG}<div class="aiphase"><b id="scT">AI standing by</b><span id="scS">Press scan to start.</span></div></div></div>
   <p class="note" id="scLeft"></p>
   <div class="row" style="justify-content:center"><button class="btn big" id="scGo" type="button">SCAN MARKETS</button><button class="btn ghost" id="scStop" type="button" hidden>Stop</button></div>
   <div id="scRows" class="scrows"></div>
   <div class="warn">Signals are rule-based analysis, not predictions and not advice. Use the stop loss every time and risk a small amount. The AI cannot promise profit.</div></section>`));
  let stop = false, running = false;
  const wait = (ms) => new Promise((r) => setTimeout(r, ms));
  const T = (a, b) => { $("#scT") && ($("#scT").textContent = a); $("#scS") && ($("#scS").textContent = b || ""); };
  const word = (t) => (t === "up" ? "UPTREND" : t === "down" ? "DOWNTREND" : t ? "NO CLEAR TREND" : "NO DATA");
  const left = (d) => { const e = $("#scLeft"); if (e) e.innerHTML = !d.freeUsed ? "You have <b>1 free signal</b>. After that, a pack of 5 signals is <b>" + priceText(d.price) + "</b>." : d.left > 0 ? `Signals left: <b>${d.left}</b>` : `No signals left. A pack of ${d.pack} costs <b>${priceText(d.price)}</b>.`; };
  (async () => { if (!me.in) return; try { left(await api("/ai/status")); } catch {} })();
  const row = (m) => { const d = document.createElement("div"); d.className = "scrow"; d.innerHTML = `<b>${esc(m.symbol)}</b><span class="note">waiting</span>`; $("#scRows").append(d); return d; };
  const mark = (d, txt, cls) => { d.className = "scrow " + (cls || ""); d.lastElementChild.textContent = txt; };
  const showSignal = (d) => {
    const s = d.signal, buy = s.dir === "BUY", dlg = el(`<dialog class="sheet posheet"><div class="posig ${buy ? "buy" : "sell"}"><span class="note">AI SIGNAL${d.repeat ? " (already sent to you)" : ""}</span><div class="podir">${s.dir}</div><h2>${esc(s.symbol)} · ${esc(s.tf)} entry</h2>
      <dl class="airead"><dt>ENTRY</dt><dd>${s.entry}</dd><dt>STOP LOSS</dt><dd class="dn">${s.sl}</dd><dt>TAKE PROFIT 1</dt><dd class="up">${s.tp1}</dd><dt>TAKE PROFIT 2</dt><dd class="up">${s.tp2}</dd><dt>4H / 1H</dt><dd>${esc(s.htf.h4 || "-")} / ${esc(s.htf.h1 || "-")}</dd></dl>
      <h4 class="note" style="text-align:left;margin:12px 0 4px">CHECKS MET (${s.criteria.length})</h4><ul class="note">${s.criteria.map((c) => `<li>${esc(c)}</li>`).join("")}</ul>
      ${d.others?.length ? `<p class="note">Other entries seen: ${d.others.map((o) => `${esc(o.symbol)} ${o.dir}`).join(", ")}. Only the best one is sent.</p>` : ""}
      <p class="note">Move the stop to break-even after take profit 1. Signals left: ${d.left}.</p>
      <div class="row"><button class="btn" data-x type="button">Close</button></div></div></dialog>`);
    document.body.append(dlg); dlg.showModal(); dlg.onclick = (e) => { if (e.target.closest("[data-x]") || e.target === dlg) { dlg.close(); dlg.remove(); } };
  };
  const sweep = async (d) => {
    $("#scRows").innerHTML = ""; let found = false;
    for (const m of d.markets) {
      if (stop) return false; const r = row(m);
      T(`Scanning 4H · ${m.symbol}`, "Reading the big trend"); mark(r, "4H ...", "on"); await wait(1500); if (stop) return false;
      mark(r, `4H ${word(m.h4)}`, "on"); T(`Scanning 1H · ${m.symbol}`, `4H: ${word(m.h4)}`); await wait(1500); if (stop) return false;
      mark(r, `4H ${word(m.h4)} · 1H ${word(m.h1)}`, "on");
      if (m.symbol === "XAUUSD") { T("Checking oil for gold", d.oil ? `Oil is ${word(d.oil)}. Gold goes the opposite way.` : "Oil chart not available right now"); await wait(1500); if (stop) return false; }
      if (m.bias) { T(`Looking for entry · ${m.symbol}`, `Waiting for a pullback on 15 min and 5 min (${m.bias})`); await wait(1800); }
      if (stop) return false;
      if (m.state === "entry") { mark(r, `${m.bias} ENTRY FOUND on ${m.signal.tf}`, "hit"); T(`Entry found in ${m.symbol}`, "Checking it against the other markets"); found = true; await wait(1200); }
      else mark(r, m.state === "waiting" ? `${m.bias} trend, no entry yet` : m.note || m.state, "");
    }
    return found;
  };
  const run = async () => {
    if (running) return; if (!me.in) return requireLogin(run);
    running = true; stop = false; $("#scGo").hidden = true; $("#scStop").hidden = false; $("#scCore").classList.remove("idle");
    try {
      for (let round = 0; round < 6 && !stop; round++) {
        T("Scanning the markets", "Loading live prices"); let d;
        try { d = await api("/ai/scan", {}); }
        catch (e) { if (e.status === 402 || /pack|signals left/i.test(e.message)) { buyFlow("aiscan"); break; } T("Could not scan", e.message); break; }
        left(d);
        if (d.closed) { T("Forex market is closed", "It opens again Monday. Try then."); break; }
        if (!d.markets.length) { T("No market data", (d.errors || [])[0] || "Try again in a minute."); break; }
        await sweep(d); if (stop) break;
        if (d.signal) { T("Signal sent", `${d.signal.dir} ${d.signal.symbol}`); showSignal(d); break; }
        T("No clean entry yet", "Scanning again in a few seconds"); await wait(5000);
        if (round === 5) T("No clean entry right now", "Press scan to try again later.");
      }
    } finally { running = false; $("#scGo").hidden = false; $("#scStop").hidden = true; $("#scCore").classList.add("idle"); }
  };
  $("#scGo").onclick = run; $("#scStop").onclick = () => { stop = true; T("Stopped", "Press scan to start again."); };
  scStop = () => { stop = true; };
}


/* ---------- Pocket Option: signals only (the site never logs in to Pocket Option) ---------- */
async function poCandles(client, id, gran, count) {
  const r = await client.send({ ticks_history: id, style: "candles", granularity: gran, count, end: "latest" });
  return (r.candles || []).map((k) => ({ o: +k.open, h: +k.high, l: +k.low, c: +k.close, t: k.epoch * 1000 }));
}
function viewPocket(main) {
  const B = BROKER_INFO[state.broker] || BROKER_INFO.pocket, BN = esc(B.name);
  main.append(el(`<section class="po"><span class="badge">Binary trading</span><h1>${BN} <em>AI signals</em></h1>
   <p class="lede">Open ${BN} in its own tab and trade there. Press Scan here: the AI reads every market below and tells you BUY or SELL, the market, the entry time and how long to trade.</p>
   <div class="chips" id="poCats">${PO.CATEGORIES.map(([k, n]) => `<button class="chip" data-c="${k}" type="button" aria-pressed="${(state.poCat || "all") === k}">${n}</button>`).join("")}</div>
   <div class="row"><a class="btn ghost" href="${esc(B.url)}" target="_blank" rel="noopener">Open ${BN}</a><button class="btn big" id="poScan" type="button">SCAN MARKETS</button></div>
   <p class="note" id="poMsg">Loading live prices...</p><div id="poList" class="mrows"></div>
   <div class="warn">Check that each market exists on ${BN}: markets, payouts and weekend OTC prices differ by broker. Signals are only an analysis of price movement. Nobody can promise a win. This page never logs in to ${BN} and never places a trade for you. Trade small and use a demo account first.</div></section>`));
  let dead = false, client = null, timer = null, scanning = false; const px = new Map(), bad = new Set();
  const pool = () => PO.MARKETS.filter((m) => !bad.has(m.id) && (state.poCat || "all") === "all" || (m.cat === state.poCat && !bad.has(m.id)));
  const paintList = () => { $("#poList") && ($("#poList").innerHTML = pool().map((m) => { const p = px.get(m.id); return `<div class="mrow"><div><b>${esc(m.name)}</b><span class="px ${p?.dn ? "d" : "u"}">${p ? p.c : "--"}</span></div><div class="note">${p ? "LIVE" : "loading"}</div></div>`; }).join("")); };
  const refresh = async () => {
    if (dead || !client || scanning) return;
    for (const m of pool()) { if (dead) return; if (px.has(m.id) && !bad.size && Date.now() - (px.get(m.id).t || 0) < 12000) continue; try { const c = await poCandles(client, m.id, 60, 2); if (c.length) px.set(m.id, { t: Date.now(), c: c[c.length - 1].c, dn: c.length > 1 && c[c.length - 1].c < c[c.length - 2].c }); else bad.add(m.id); } catch { bad.add(m.id); } }
    paintList(); const msg = $("#poMsg"); if (msg) msg.textContent = px.size ? "Live markets" : "Could not reach live prices right now.";
  };
  const scan = async () => {
    if (!client || scanning) return; scanning = true; const btn = $("#poScan"); btn.disabled = true;
    const scr = el(`<dialog class="sheet posheet"><div class="aicore idle"><div class="aihero">${CORE_SVG}<div class="aiphase"><b id="poT">SCANNING MARKETS</b><span id="poS">Reading ${pool().length} markets</span></div></div></div></dialog>`);
    document.body.append(scr); scr.showModal(); let n = 3; const cd = setInterval(() => { n = n <= 1 ? 3 : n - 1;  }, 1000);
    const results = [];
    for (const m of pool()) { try { results.push({ market: m, candles: await poCandles(client, m.id, 60, 80) }); } catch { bad.add(m.id); } }
    let sig = PO.bestSignal(results);
    if (sig) { try { const r = results.find((x) => x.market.id === sig.market.id); r.candles5 = await poCandles(client, sig.market.id, 300, 60); sig = PO.bestSignal(results); } catch {} }
    clearInterval(cd);
    if (!sig) { scr.innerHTML = `<div class="sheethead"><h2>No clear setup</h2></div><p class="lede">The AI scanned ${results.length} markets and none has a clean entry right now. Wait a minute and scan again.</p><div class="row"><button class="btn" data-x type="button">Close</button></div>`; }
    else {
      const buy = sig.dir === "BUY", stars = "●".repeat(sig.strength) + "○".repeat(3 - sig.strength);
      const hm = (t) => new Date(t).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
      scr.innerHTML = `<div class="posig ${buy ? "buy" : "sell"}"><span class="note">AI SIGNAL</span><div class="podir">${sig.dir}</div><h2>${esc(sig.market.name)}</h2>
       <dl class="airead"><dt>ENTER AT</dt><dd>${hm(sig.entryAt)} <span id="poCd"></span></dd><dt>TRADE TIME</dt><dd>${sig.expiryMin} min (until ${hm(sig.expireAt)})</dd><dt>STRENGTH</dt><dd>${stars}</dd><dt>PRICE NOW</dt><dd>${sig.price}</dd></dl>
       <ul class="note">${sig.why.map((w) => `<li>${esc(w)}</li>`).join("")}</ul>
       <p class="note">Open ${esc(sig.market.name)} on ${BN}, set the time to ${sig.expiryMin} min and press ${sig.dir} when the entry time starts. No result is guaranteed.</p>
       <div class="row"><a class="btn" href="${esc(B.url)}" target="_blank" rel="noopener">Open ${BN}</a><button class="btn ghost" data-x type="button">Close</button></div></div>`;
      const cd2 = setInterval(() => { const e = $("#poCd", scr); if (!e) return clearInterval(cd2); const s = Math.max(0, Math.round((sig.entryAt - Date.now()) / 1000)); e.textContent = s > 0 ? `(in ${s}s)` : "(now)"; }, 500);
    }
    scr.onclick = (e) => { if (e.target.closest("[data-x]") || e.target === scr) { scr.close(); scr.remove(); } };
    scanning = false; btn.disabled = false;
  };
  $("#poScan").onclick = scan;
  $("#poCats").onclick = (e) => { const b = e.target.closest("[data-c]"); if (!b) return; state.poCat = b.dataset.c; document.querySelectorAll("#poCats .chip").forEach((x) => x.setAttribute("aria-pressed", String(x.dataset.c === state.poCat))); paintList(); refresh(); };
  paintList();
  (async () => { try { client = new DerivClient({ mode: "public" }); await client.connect(); await refresh(); timer = setInterval(refresh, 15000); } catch { $("#poMsg") && ($("#poMsg").textContent = "Could not reach live prices right now."); } })();
  scStop = () => { dead = true; clearInterval(timer); try { client?.close(); } catch {} };
}

/* ---------- Scanner (free, live) ---------- */
const SC_CATS = [["rise-fall", "Rise / Fall", "rise-fall-auto"], ["over-under", "Over / Under", "over-under-auto"], ["even-odd", "Even / Odd", "even-odd-auto"], ["differs", "Differs", "differs-auto"], ["matches", "Matches", "matches-auto"], ["accumulators", "Accumulators", "killer"]];
let scStop = () => {};
function stopScanner() { scStop(); scStop = () => {}; }
function viewScanner(main) {
  let cat = "over-under", sel = "R_100", dead = false, client = null, scanner = null, timer = null;
  main.append(el(`<section><span class="badge">Live scanner</span><h1>Market scanner</h1>
  <p class="lede">Live Deriv markets scanned on their last 100 ticks. Pick a contract type, tap a market to see it live, then open its AI trader.</p>
  <div class="chips" id="scCats">${SC_CATS.map(([id, n]) => `<button class="chip" data-c="${id}" aria-pressed="${id === cat}">${n}</button>`).join("")}</div>
  <div class="form" id="scBest"></div>
  <div class="tickbox"><div class="tickhead"><b id="scPx">--</b><span class="note" id="scMsg">Connecting...</span></div><canvas id="scCv" width="900" height="260" style="width:100%;height:220px;display:block"></canvas>
  <div id="scMoves" class="moves" title="Last 40 ticks: green up, red down"></div><div id="scBars" class="digbars"></div></div>
  <h2>Markets</h2><div id="scList" class="mrows"></div></section>`));
  const sigFor = (c, w) => (c === "accumulators" ? null : LIB.SIGNALS[c](w));
  const draw = () => {
    const w = scanner?.windows.get(sel), cv = $("#scCv"); if (!w || !cv) return;
    const g = cv.getContext("2d"), W = cv.width, H = cv.height; g.clearRect(0, 0, W, H);
    const p = w.prices; if (p.length < 2) return;
    const lo = Math.min(...p), hi = Math.max(...p), pad = (hi - lo) * 0.1 || 1;
    const x = (i) => (i / (p.length - 1)) * W, y = (v) => H - ((v - lo + pad) / (hi - lo + 2 * pad)) * H;
    const up = p[p.length - 1] >= p[0], col = getComputedStyle(document.documentElement).getPropertyValue(up ? "--green" : "--red").trim() || "#22c55e";
    g.beginPath(); p.forEach((v, i) => (i ? g.lineTo(x(i), y(v)) : g.moveTo(x(i), y(v)))); g.strokeStyle = col; g.lineWidth = 2.5; g.stroke();
    $("#scPx").textContent = w.price; $("#scMsg").textContent = `${sel} live, last digit ${w.last}`;
    const pc = w.pct(), mx = Math.max(...pc, 0.01);
    const maxI = pc.indexOf(Math.max(...pc)), minI = pc.indexOf(Math.min(...pc));
    $("#scBars").innerHTML = pc.map((v, d) => `<div class="db ${v >= 0.1 ? "hi" : ""} ${d === maxI ? "top" : ""} ${d === minI ? "low" : ""} ${d === w.last ? "now" : ""}"><i style="height:${Math.max(4, Math.round((v / mx) * 62))}px"></i><b>${d}</b><span>${(v * 100).toFixed(0)}%</span></div>`).join("");
    const pr = w.prices.slice(-41); let mv = "";
    for (let i = 1; i < pr.length; i++) { const dlt = pr[i] - pr[i - 1], hgt = Math.min(44, 8 + Math.abs(dlt) / ((hi - lo) || 1) * 160); mv += `<i class="${dlt >= 0 ? "u" : "d"}" style="height:${Math.round(hgt)}px"></i>`; }
    $("#scMoves").innerHTML = mv;
  };
  const paint = () => {
    if (dead || !scanner) return;
    const rows = [...scanner.windows.entries()].map(([s, w]) => ({ s, w, sig: sigFor(cat, w) })).sort((a, b) => (b.sig?.strength || 0) - (a.sig?.strength || 0));
    const top = rows.find((r) => r.sig), bot = SC_CATS.find((c) => c[0] === cat)[2], item = autos().find((i) => i.id === bot);
    $("#scBest").innerHTML = cat === "accumulators"
      ? `<b>Accumulators</b><p class="note">The Killer scans every market for a crash of more than 15 ticks, waits 5 ticks and enters, then exits at 15.</p><button class="btn" data-bot="${bot}">Open the AI trader</button>`
      : top ? `<b>Best now: ${esc(top.s)} - ${esc(top.sig.label)}</b><p class="note">${esc(top.sig.why)}.</p><button class="btn" data-bot="${bot}">Open the AI trader</button>`
      : `<b>No clear entry right now</b><p class="note">The scanner keeps looking on all markets. The AI trader does the same and waits for a setup.</p><button class="btn ghost" data-bot="${bot}">Open the AI trader</button>`;
    $("#scList").innerHTML = rows.map((r) => { const pp = r.w.prices, dn = pp.length > 1 && pp[pp.length - 1] < pp[pp.length - 2], str = r.sig ? Math.round(Math.min(1, r.sig.strength) * 100) : 0;
      return `<div class="mrow ${r.s === sel ? "sel" : ""}" data-s="${r.s}"><div><b>${esc(r.s)}</b><span class="px ${dn ? "d" : "u"}">${r.w.price ?? "--"}</span></div><div class="meter" title="Signal strength"><i style="width:${r.sig ? Math.max(8, str) : 0}%"></i></div><div class="lab ${r.sig ? "go" : ""}">${r.sig ? esc(r.sig.label) : cat === "accumulators" ? "Live feed" : "No entry"}</div></div>`; }).join("");
    draw();
  };
  const unlockedBot = (id) => autos().find((i) => i.id === id && unlocked(i));
  main.onclick = (e) => {
    const c = e.target.closest("[data-c]"); if (c) { cat = c.dataset.c; document.querySelectorAll("#scCats .chip").forEach((b) => b.setAttribute("aria-pressed", String(b === c))); return paint(); }
    const s = e.target.closest("[data-s]"); if (s) { sel = s.dataset.s; return paint(); }
    const b = e.target.closest("[data-bot]"); if (b) { state.preBot = b.dataset.bot; if (!unlockedBot(b.dataset.bot)) toast("That bot is locked. Buy it in the Deriv bots tab or use the owner key."); setTab("automated"); }
  };
  (async () => {
    try {
      client = new DerivClient({ mode: "public" }); await client.connect();
      scanner = new LIB.MarketScanner(client, LIB.SYMBOLS, { size: 100, onTick: (s) => { if (s === sel) draw(); } });
      await scanner.start(); paint(); timer = setInterval(paint, 1500);
    } catch (e) { if (!dead) $("#scMsg").textContent = "Could not reach Deriv live data right now."; }
  })();
  scStop = () => { dead = true; clearInterval(timer); try { scanner?.stop(); } catch {} try { client?.close(); } catch {} };
}
const autos = () => pub().filter((i) => i.section === "automated").sort(autoSort);

/* ---------- Live charts ---------- */
let chartStop = () => {};
function stopCharts() { chartStop(); chartStop = () => {}; }
const TV = [["XAUUSD", "OANDA:XAUUSD"], ["EURUSD", "FX:EURUSD"], ["GBPUSD", "FX:GBPUSD"], ["USDJPY", "FX:USDJPY"], ["BTCUSD", "BITSTAMP:BTCUSD"], ["US100", "OANDA:NAS100USD"]];
function viewCharts(main) {
  main.append(el(`<section><span class="badge">Live markets</span><h1>Live charts</h1>
  <p class="lede">Real-time charts for forex and gold, plus a live tick stream from Deriv volatility indices.</p>
  <div class="chips" id="tvChips">${TV.map(([n, s], i) => `<button class="chip" data-tv="${s}" aria-pressed="${i === 0}">${n}</button>`).join("")}</div>
  <div class="chartbox" id="tvBox"></div>
  <h2>Deriv live ticks</h2>
  <div class="chips" id="dvChips">${["R_10", "R_25", "R_50", "R_75", "R_100", "1HZ100V"].map((s, i) => `<button class="chip" data-dv="${s}" aria-pressed="${i === 4}">${s}</button>`).join("")}</div>
  <div class="tickbox"><div class="tickhead"><b id="tickPx">--</b><span id="tickMsg" class="note">Connecting...</span></div><canvas id="tickCv" width="900" height="260"></canvas></div></section>`));
  const loadTV = (sym) => {
    const box = $("#tvBox"); box.innerHTML = "";
    const w = document.createElement("div"); w.className = "tradingview-widget-container"; w.style.height = "100%";
    w.innerHTML = `<div class="tradingview-widget-container__widget" style="height:100%"></div>`;
    const s = document.createElement("script");
    s.src = "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js"; s.async = true;
    s.textContent = JSON.stringify({ autosize: true, symbol: sym, interval: "5", timezone: "Africa/Nairobi", theme: document.documentElement.dataset.theme === "light" ? "light" : "dark", style: "1", locale: "en", allow_symbol_change: true, hide_side_toolbar: true, support_host: "https://www.tradingview.com" });
    w.append(s); box.append(w);
  };
  loadTV(TV[0][1]);
  let client = null, un = null, prices = [], dead = false;
  const draw = () => {
    const cv = $("#tickCv"); if (!cv) return;
    const g = cv.getContext("2d"), W = cv.width, H = cv.height; g.clearRect(0, 0, W, H);
    if (prices.length < 2) return;
    const lo = Math.min(...prices), hi = Math.max(...prices), pad = (hi - lo) * 0.1 || 1;
    const x = (i) => (i / (prices.length - 1)) * W, y = (p) => H - ((p - lo + pad) / (hi - lo + 2 * pad)) * H;
    const up = prices[prices.length - 1] >= prices[0];
    const col = getComputedStyle(document.documentElement).getPropertyValue(up ? "--green" : "--red").trim() || (up ? "#22c55e" : "#ef4444");
    g.beginPath(); prices.forEach((p, i) => (i ? g.lineTo(x(i), y(p)) : g.moveTo(x(i), y(p))));
    g.strokeStyle = col; g.lineWidth = 2.5; g.stroke();
    g.lineTo(W, H); g.lineTo(0, H); g.closePath(); g.globalAlpha = 0.12; g.fillStyle = col; g.fill(); g.globalAlpha = 1;
  };
  const startTicks = async (sym) => {
    try { await un?.(); } catch {}
    prices = []; $("#tickMsg").textContent = "Connecting..."; $("#tickPx").textContent = "--";
    try {
      if (!client || client.closed) { client = new DerivClient({ mode: "public" }); await client.connect(); }
      un = await client.subscribe({ ticks: sym }, (m, err) => {
        if (dead || err || !m?.tick) return;
        prices.push(m.tick.quote); if (prices.length > 150) prices.shift();
        $("#tickPx").textContent = m.tick.quote; $("#tickMsg").textContent = sym + " live"; draw();
      });
    } catch (e) { if (!dead) $("#tickMsg").textContent = "Could not reach Deriv live ticks right now."; }
  };
  startTicks("R_100");
  $("#tvChips").onclick = (e) => { const b = e.target.closest("[data-tv]"); if (!b) return; document.querySelectorAll("#tvChips .chip").forEach((c) => c.setAttribute("aria-pressed", String(c === b))); loadTV(b.dataset.tv); };
  $("#dvChips").onclick = (e) => { const b = e.target.closest("[data-dv]"); if (!b) return; document.querySelectorAll("#dvChips .chip").forEach((c) => c.setAttribute("aria-pressed", String(c === b))); startTicks(b.dataset.dv); };
  main.onclick = (e) => { const b = e.target.closest("button[data-go]"); if (b) setTab(b.dataset.go); };
  chartStop = () => { dead = true; try { client?.close(); } catch {} };
}

/* ---------- Settings ---------- */
/* ---------- Hidden owner area: footer long-press or #admin, then the key ---------- */
const admKey = () => sess.get("adm") || "";
async function admApi(path, body) {
  const r = await fetch(CONFIG.payApi + path, { method: body ? "POST" : "GET", headers: { "Content-Type": "application/json", "X-Admin": admKey() }, body: body ? JSON.stringify(body) : undefined });
  const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || "Failed."); return d;
}
function openAdmin() {
  closeSheets();
  if (admKey()) return admPanel();
  const dlg = el(`<dialog class="pay"><form id="akF"><div class="field"><input id="ak" type="password" autocomplete="off" aria-label="Key"></div><div class="row"><button class="btn">Enter</button><button class="btn ghost" id="akX" type="button">Close</button></div><p class="note" id="akM"></p></form></dialog>`);
  document.body.append(dlg); dlg.showModal();
  const close = () => { dlg.close(); dlg.remove(); };
  $("#akX", dlg).onclick = close;
  $("#akF", dlg).onsubmit = async (e) => {
    e.preventDefault(); const k = $("#ak", dlg).value.trim(); if (!k) return;
    sess.set("adm", k);
    try {
      await admApi("/admin/ping");
      // if it is also the owner key of the bot files, every bot opens free on this device
      try { const probe = ITEMS.find((i) => i.locked && !i.extra); const out = await openEntry(await fetchEntry(probe.id), k); if (out?.via === "owner") store.set("owner", k); } catch {}
      close(); admPanel();
    } catch (er) { sess.del("adm"); $("#akM", dlg).textContent = er.message; }
  };
}
let admTab = "orders", admFilter = "";
function admPanel() {
  closeSheets();
  const dlg = el(`<dialog class="sheet red"><div class="sheethead"><div><span class="badge">Admin</span><h2>Control panel</h2></div><div class="row"><button class="btn ghost" id="admOut" type="button">Lock</button><button class="btn ghost" data-x type="button">Close</button></div></div>
    <div class="chips" id="admTabs">${[["orders", "Orders"], ["clients", "Clients"], ["bots", "Bots"], ["studio", "Bot Studio"], ["settings", "Settings"]].map(([id, n]) => `<button class="chip" data-t="${id}" aria-pressed="${admTab === id}" type="button">${n}</button>`).join("")}</div>
    <div id="admBody"></div></dialog>`);
  document.body.append(dlg); dlg.showModal();
  const box = $("#admBody", dlg);
  const show = async (t) => {
    admTab = t; dlg.querySelectorAll("#admTabs .chip").forEach((c) => c.setAttribute("aria-pressed", String(c.dataset.t === t)));
    box.innerHTML = `<p class="note">Loading...</p>`;
    try { await ({ orders: admOrders, clients: admClients, bots: admBots, studio: admStudio, settings: admSettings })[t](box, show); } catch (e) { box.innerHTML = `<p class="note">${esc(e.message)}</p>`; }
  };
  dlg.onclick = (e) => {
    if (e.target === dlg) return closeSheets();
    const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.x !== undefined) closeSheets();
    else if (b.id === "admOut") { sess.del("adm"); closeSheets(); }
    else if (b.dataset.t) show(b.dataset.t);
  };
  show(admTab);
}
const botLabel = (id) => (id === "signals" ? "Forex signals" : id === "aiscan" ? "AI Scanner pack" : ITEMS.find((i) => i.id === id)?.name || id);
const dt = (t) => new Date(t).toLocaleString();

async function admOrders(box, show) {
  const { orders } = await admApi("/admin/orders");
  box.innerHTML = orders.length ? orders.map((o) => {
    const i = o.info || {}, flags = `${i.amountOk ? "Amount OK" : "AMOUNT LOW/UNKNOWN"} (${i.amount || "?"}) | ${i.toOwner ? "To your number" : "NOT to your number"} | Code ${esc(i.code || "none")}`;
    const wa = "https://wa.me/" + o.whatsapp + "?text=" + encodeURIComponent(o.status === "approved" ? `Payment confirmed. Log in to TRADERSPRO254 with ${o.email} and open ${o.botName}. Thank you!` : "Hello, about your TRADERSPRO254 order " + o.ref + ".");
    return `<div class="form" style="margin:0 0 10px"><b>${esc(o.botName || botLabel(o.botId))}</b> ${CURRENCY} ${o.price} <span class="note">${esc(o.status)} | ${dt(o.t)}</span>
      <p class="note">${esc(o.name || "")} | ${esc(o.email || "")} | WhatsApp ${esc(o.whatsapp)}</p>${o.method && o.method !== "pochi" ? `<p class="note"><b>${esc(o.method.toUpperCase())}</b> $${esc(o.usd)} | Transaction: <code>${esc(o.proof)}</code></p>` : `<p class="note">${flags}</p><pre style="white-space:pre-wrap;font-size:12px">${esc(o.mpesa)}</pre>`}
      <div class="row">${o.status === "pending" ? `<button class="btn" data-ref="${esc(o.ref)}" data-act="approve" type="button">Accept</button><button class="btn ghost" data-ref="${esc(o.ref)}" data-act="reject" type="button">Reject</button>` : ""}<a class="btn ghost" href="${wa}" target="_blank" rel="noopener">WhatsApp</a><button class="btn ghost" data-manage="${esc(o.email || "")}" type="button">Manage</button><button class="btn danger" data-del="${esc(o.ref)}" type="button">Delete order</button></div></div>`;
  }).join("") : `<p class="note">No orders yet.</p>`;
  box.onclick = async (e) => {
    const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.manage !== undefined) { admFilter = b.dataset.manage; return show("clients"); }
    if (b.dataset.del) { if (!confirm("Delete this order for good?")) return; try { await admApi("/admin/order", { ref: b.dataset.del, action: "delete" }); toast("Order deleted."); show("orders"); } catch (er) { toast(er.message); } return; }
    if (!b.dataset.ref) return;
    try { await admApi("/admin/approve", { ref: b.dataset.ref, action: b.dataset.act }); toast(b.dataset.act === "approve" ? "Accepted. Client unlocked and emailed." : "Rejected."); show("orders"); } catch (er) { toast(er.message); }
  };
}

async function admClients(box, show) {
  const { clients } = await admApi("/admin/clients");
  const opts = [["signals", "Forex signals (1 week)"], ...ITEMS.filter((i) => i.locked).map((i) => [i.id, i.name])].map(([v, n]) => `<option value="${esc(v)}">${esc(n)}</option>`).join("");
  const draw = () => {
    const q = admFilter.toLowerCase(), list = clients.filter((c) => !q || c.email.toLowerCase().includes(q) || c.name.toLowerCase().includes(q));
    $("#cl", box).innerHTML = list.length ? list.map((c) => `<div class="form" style="margin:0 0 10px"><b>${esc(c.name)}</b> <span class="note">${esc(c.email)}${c.blocked ? " | BLOCKED" : ""}${c.verified ? "" : " | not confirmed"} | joined ${c.created ? dt(c.created) : "?"}</span>
      <div class="tags" style="margin:8px 0">${c.bots.map((b) => `<span class="tag on">${esc(botLabel(b))} <button class="btn ghost" data-a="revoke" data-acc="${esc(c.account)}" data-bot="${esc(b)}" type="button">Clear</button></span>`).join("") || `<span class="note">No bots bought.</span>`}
      ${c.subActive ? `<span class="tag on">Signals until ${dt(c.subEnd)} <button class="btn ghost" data-a="revoke" data-acc="${esc(c.account)}" data-bot="signals" type="button">Clear</button></span>` : ""}</div>
      <p class="note">Free signal: ${esc(c.free)}${c.freeResult ? " (" + esc(c.freeResult) + ")" : ""} ${c.free !== "none" ? `<button class="btn ghost" data-a="resetfree" data-acc="${esc(c.account)}" type="button">Give a new free signal</button>` : ""}</p>
      <div class="row"><select data-sel="${esc(c.account)}">${opts}</select><button class="btn" data-a="grant" data-acc="${esc(c.account)}" type="button">Give</button><button class="btn ghost" data-a="logout" data-acc="${esc(c.account)}" type="button">Log out</button><button class="btn ghost" data-a="${c.blocked ? "unblock" : "block"}" data-acc="${esc(c.account)}" type="button">${c.blocked ? "Unblock" : "Block"}</button><button class="btn danger" data-a="delete" data-acc="${esc(c.account)}" type="button">Delete account</button></div></div>`).join("") : `<p class="note">No clients found.</p>`;
  };
  box.innerHTML = `<div class="row" style="margin-bottom:10px"><div class="field" style="flex:1;min-width:180px;margin:0"><input id="cf" placeholder="Search name or email" value="${esc(admFilter)}"></div><button class="btn danger" id="logAll" type="button">Clear all logins</button></div><div id="cl"></div>`; draw();
  $("#logAll", box).onclick = async () => { if (!confirm("Log EVERY client out? They keep their accounts and bots, but must log in again.")) return; try { await admApi("/admin/logoutall", {}); toast("Everyone was logged out."); } catch (er) { toast(er.message); } };
  $("#cf", box).oninput = (e) => { admFilter = e.target.value; draw(); };
  box.onclick = async (e) => {
    const b = e.target.closest("button[data-a]"); if (!b) return;
    const a = b.dataset.a, acc = b.dataset.acc;
    try {
      if (a === "delete") { if (!confirm("Delete this client for good? Their account, bots and logins are removed. They must register again.")) return; await admApi("/admin/client", { account: acc, action: "delete" }); }
      else if (a === "logout") { if (!confirm("Log this client out on all devices?")) return; await admApi("/admin/client", { account: acc, action: "logout" }); }
      else if (["block", "unblock"].includes(a)) await admApi("/admin/client", { account: acc, action: a });
      else if (a === "grant") await admApi("/admin/license", { account: acc, botId: box.querySelector(`[data-sel="${CSS.escape(acc)}"]`).value, action: "grant" });
      else { if (a === "revoke" && !confirm("Clear this? The client goes back to being asked for payment.")) return; await admApi("/admin/license", { account: acc, botId: b.dataset.bot, action: a }); }
      toast("Done."); show("clients");
    } catch (er) { toast(er.message); }
  };
}

async function admBots(box, show) {
  const prices = await (await fetch(CONFIG.payApi + "/prices")).json();
  const cats = CATEGORIES.deriv;
  box.innerHTML = `<div class="form"><h2 style="margin-top:0">Add a bot</h2><p class="note">Upload the bot file (XML for Deriv, .ex5 or .mq5 for a forex robot). It is locked in your browser before it is sent, and clients get it only after paying. Files up to about 3 MB.</p>
    <div class="field"><label for="nb-sec">Where does it go?</label><select id="nb-sec"><option value="deriv">Deriv bot (TRADERSPRO BOTS)</option><option value="forex">Forex robot (Forex bots tab, MT5)</option></select></div>
    <div class="row"><div class="field"><label for="nb-id">Short id</label><input id="nb-id" placeholder="my-new-bot"></div><div class="field"><label for="nb-name">Name</label><input id="nb-name"></div><div class="field"><label for="nb-price">Price (KSh)</label><input id="nb-price" type="number" min="10"></div></div>
    <div class="field"><label for="nb-desc">Description</label><input id="nb-desc"></div>
    <div class="row"><div class="field" id="nb-catbox"><label for="nb-cat">Category</label><select id="nb-cat">${cats.map((c) => `<option value="${c.id}">${esc(c.name)}</option>`).join("")}</select></div><div class="field"><label for="nb-file">Bot file</label><input id="nb-file" type="file"></div></div>
    <div class="row"><button class="btn" id="nb-add" type="button">Add bot</button><span class="note" id="nb-msg"></span></div></div>
    <h2>All bots</h2><div id="bl">${ITEMS.filter((i) => i.locked).map((i) => `<div class="form" style="margin:0 0 8px"><div class="row"><b style="flex:1;min-width:140px">${esc(i.name)}</b><span class="note">${i.extra ? "added" : "built-in"}${i.hidden ? " | HIDDEN" : ""}</span></div>
      <div class="row"><input data-n="${esc(i.id)}" value="${esc(i.name)}" aria-label="Name" style="flex:1;min-width:140px"><input data-p="${esc(i.id)}" type="number" min="10" value="${prices[i.id] ?? i.price}" style="width:110px" aria-label="Price"><button class="btn" data-ba="edit" data-id="${esc(i.id)}" type="button">Save</button>${i.hidden ? `<button class="btn ghost" data-ba="unhide" data-id="${esc(i.id)}" type="button">Show</button>` : `<button class="btn danger" data-ba="delete" data-id="${esc(i.id)}" type="button">Delete</button>`}</div></div>`).join("")}</div>`;
  $("#nb-sec", box).onchange = (e) => { $("#nb-catbox", box).hidden = e.target.value === "forex"; };
  $("#nb-add", box).onclick = async () => {
    const g = (id) => $("#" + id, box).value.trim(), msg = $("#nb-msg", box), f = $("#nb-file", box).files[0];
    if (!g("nb-id") || !g("nb-name") || !g("nb-price") || !f) return (msg.textContent = "Fill id, name, price and choose the file.");
    msg.textContent = "Locking and uploading...";
    try {
      const key = "TP-" + crypto.randomUUID().replace(/-/g, "").slice(0, 16).toUpperCase();
      const entry = await sealEntry(f.name, f.type || "application/octet-stream", new Uint8Array(await f.arrayBuffer()), key, admKey());
      await admApi("/admin/bot", { action: "add", id: g("nb-id"), name: g("nb-name"), desc: g("nb-desc"), price: Number(g("nb-price")), section: g("nb-sec"), category: g("nb-cat"), key, entry });
      await loadCatalog(); toast("Bot added. It is live now."); show("bots");
    } catch (er) { msg.textContent = er.message; }
  };
  box.onclick = async (e) => {
    const b = e.target.closest("button[data-ba]"); if (!b) return;
    const id = b.dataset.id, a = b.dataset.ba;
    try {
      if (a === "delete" && !confirm("Remove this bot from the store?")) return;
      const body = { action: a, id };
      if (a === "edit") { body.name = $(`[data-n="${CSS.escape(id)}"]`, box).value; body.price = $(`[data-p="${CSS.escape(id)}"]`, box).value; }
      await admApi("/admin/bot", body);
      await loadCatalog(); toast("Saved."); show("bots");
    } catch (er) { toast(er.message); }
  };
}


/* ---------- Bot Studio: create, change and delete automated digit bots by their rules ---------- */
const DIGIT_BOTS = ["under-auto", "over-auto", "differs-auto", "even-odd-auto", "matches-auto", "rise-fall-auto", "over-under-auto", "digit-trader"];
const optList = (arr, sel) => arr.map(([v, n]) => `<option value="${v}" ${String(v) === String(sel) ? "selected" : ""}>${n}</option>`).join("");
const DIG = Array.from({ length: 10 }, (_, i) => [i, String(i)]);
const trigHtml = (p, t) => `<div class="row"><div class="field"><label>Signal when</label><select id="${p}k">${optList([["digit", "the last digit is..."], ["least-digit", "the least appearing digit prints again"], ["streak", "same type of digit N times in a row"], ["always", "every tick"]], t.kind)}</select></div>
  <div class="field" data-for="${p}digit"><label>Compare</label><select id="${p}c">${optList([["gte", "this or higher"], ["lte", "this or lower"], ["eq", "exactly"], ["ne", "not"]], t.cmp || "gte")}</select></div>
  <div class="field" data-for="${p}digit"><label>Digit</label><select id="${p}v">${optList(DIG, t.value ?? 8)}</select></div>
  <div class="field" data-for="${p}streak"><label>Type</label><select id="${p}par">${optList([["even", "even"], ["odd", "odd"]], t.parity || "even")}</select></div>
  <div class="field" data-for="${p}streak"><label>How many</label><input id="${p}len" type="number" min="2" max="12" value="${t.length ?? 4}"></div></div>`;
const contHtml = (p, c) => `<div class="row"><div class="field"><label>Then place</label><select id="${p}t">${optList(Object.entries(CONTRACTS), c.type)}</select></div>
  <div class="field" data-for="${p}bar"><label>Barrier digit</label><select id="${p}b">${optList([...DIG, ["trigger", "the digit that touched"], ["least", "the least appearing digit"]], c.barrier ?? 5)}</select></div>
  <div class="field"><label>Ticks</label><input id="${p}n" type="number" min="1" max="10" value="${c.ticks ?? 1}"></div></div>`;
function readTrig(box, p) { const k = $("#" + p + "k", box).value; if (k === "least-digit") return { kind: k }; if (k === "always") return { kind: k }; if (k === "streak") return { kind: k, parity: $("#" + p + "par", box).value, length: Number($("#" + p + "len", box).value) }; return { kind: "digit", cmp: $("#" + p + "c", box).value, value: Number($("#" + p + "v", box).value) }; }
function readCont(box, p) { const t = $("#" + p + "t", box).value, o = { type: t, ticks: Number($("#" + p + "n", box).value) }; if (NEEDS_BARRIER.includes(t)) { const b = $("#" + p + "b", box).value; o.barrier = b === "trigger" || b === "least" ? b : Number(b); } return o; }
function showFields(box, p, t) { box.querySelectorAll(`[data-for="${p}digit"]`).forEach((e) => (e.hidden = t !== "digit")); box.querySelectorAll(`[data-for="${p}streak"]`).forEach((e) => (e.hidden = t !== "streak")); }
function ruleEditor(box, show, bot, rulesIn, textIn) {
  const R = cleanRules(rulesIn || DEFAULT_RULES), rec = R.recovery, hasOv = !!(rec.trigger || rec.contract);
  box.innerHTML = `<div class="form"><h2 style="margin-top:0">${bot ? "Change " + esc(bot.name) : "Build a new automated bot"}</h2>
    <div class="row"><div class="field"><label for="rb-name">Bot name</label><input id="rb-name" value="${esc(bot ? bot.name : "")}" placeholder="My Under bot"></div><div class="field"><label for="rb-price">Price (KSh)</label><input id="rb-price" type="number" min="10" value="${esc(bot ? bot.price : 2500)}"></div></div>
    <div class="field"><label for="rb-desc">Short description</label><input id="rb-desc" value="${esc(bot ? bot.desc : "Automated digit bot with my own rules.")}"></div>
    <h3>Tell the AI the rules</h3><p class="note">Write it like you talk to me, for example: "only trade after 2 losing signals", or "use Over 2 and recover with Over 3". The AI changes the settings below. You can fix anything by hand before saving.</p>
    <div class="field"><textarea id="rb-text" rows="3" placeholder="Describe the rules in your own words...">${esc(textIn || "")}</textarea></div>
    <div class="row"><button class="btn" id="rb-ai" type="button">Apply my words</button><span class="note" id="rb-aimsg"></span></div>
    <h3>Rules (the exact settings)</h3>
    <div id="rb-form">${trigHtml("t", R.trigger)}${contHtml("c", R.contract)}
      <div class="row"><div class="field"><label for="g-n">Only place real trades after this many losing signals in a row (0 = every signal)</label><input id="g-n" type="number" min="0" max="10" value="${R.gate.afterLosses}"></div></div>
      <div class="row"><div class="field"><label><input type="checkbox" id="r-on" ${rec.enabled ? "checked" : ""}> Recover after a loss</label></div><div class="field"><label for="r-m">Stake multiplier</label><input id="r-m" type="number" min="1" max="10" step="0.1" value="${rec.multiplier}"></div><div class="field"><label for="r-s">Max recovery steps</label><input id="r-s" type="number" min="0" max="8" value="${rec.maxSteps}"></div></div>
      <div class="field"><label><input type="checkbox" id="r-ov" ${hasOv ? "checked" : ""}> Use a different signal and trade while recovering</label></div>
      <div id="r-box" ${hasOv ? "" : "hidden"}>${trigHtml("rt", rec.trigger || R.trigger)}${contHtml("rc", rec.contract || R.contract)}</div>
      <div class="row"><div class="field"><label for="l-m">Stop after this many trades (0 = no limit)</label><input id="l-m" type="number" min="0" value="${R.limits.maxTrades}"></div><div class="field"><label for="l-c">Wait this many ticks between trades</label><input id="l-c" type="number" min="0" value="${R.limits.cooldownTicks}"></div></div></div>
    <h3>What this bot will do</h3><ul class="note" id="rb-sum"></ul>
    <div class="row"><button class="btn" id="rb-save" type="button">${bot ? "Save changes" : "Create bot"}</button><button class="btn ghost" id="rb-cancel" type="button">Cancel</button><span class="note" id="rb-msg"></span></div></div>`;
  const read = () => cleanRules({ markets: "all", trigger: readTrig(box, "t"), contract: readCont(box, "c"), gate: { afterLosses: Number($("#g-n", box).value) },
    recovery: { enabled: $("#r-on", box).checked, multiplier: Number($("#r-m", box).value), maxSteps: Number($("#r-s", box).value), trigger: $("#r-ov", box).checked ? readTrig(box, "rt") : null, contract: $("#r-ov", box).checked ? readCont(box, "rc") : null },
    limits: { maxTrades: Number($("#l-m", box).value), cooldownTicks: Number($("#l-c", box).value) } });
  const sync = () => {
    for (const [p, tp] of [["t", "t"], ["rt", "rt"]]) showFields(box, p, $("#" + p + "k", box).value);
    for (const p of ["c", "rc"]) box.querySelectorAll(`[data-for="${p}bar"]`).forEach((e) => (e.hidden = !NEEDS_BARRIER.includes($("#" + p + "t", box).value)));
    $("#r-box", box).hidden = !$("#r-ov", box).checked;
    $("#rb-sum", box).innerHTML = describeRules(read()).map((l) => `<li>${esc(l)}</li>`).join("");
  };
  box.querySelector("#rb-form").oninput = sync; box.querySelector("#rb-form").onchange = sync; sync();
  $("#rb-cancel", box).onclick = () => show("studio");
  $("#rb-ai", box).onclick = async () => {
    const m = $("#rb-aimsg", box); m.textContent = "Thinking...";
    try { const d = await admApi("/admin/rules-ai", { text: $("#rb-text", box).value, current: read() }); ruleEditor2(d.rules); m.textContent = "Done. Check the settings below."; } catch (e) { m.textContent = e.message; }
  };
  const ruleEditor2 = (r) => { const name = $("#rb-name", box).value, price = $("#rb-price", box).value, desc = $("#rb-desc", box).value, txt = $("#rb-text", box).value; ruleEditor(box, show, bot, r, txt); $("#rb-name", box).value = name; $("#rb-price", box).value = price; $("#rb-desc", box).value = desc; };
  $("#rb-save", box).onclick = async () => {
    const msg = $("#rb-msg", box), name = $("#rb-name", box).value.trim(), price = Number($("#rb-price", box).value);
    if (!name) return (msg.textContent = "Give the bot a name."); if (!(price >= 10)) return (msg.textContent = "Set a price of at least 10.");
    msg.textContent = "Locking and publishing...";
    try {
      const rules = read(), src = await (await fetch("rules-bot.js", { cache: "no-store" })).text();
      const key = "TP-" + crypto.randomUUID().replace(/-/g, "").slice(0, 16).toUpperCase();
      const entry = await sealEntry("rules-bot.js", "text/javascript", new TextEncoder().encode(`const RULES = ${JSON.stringify(rules)};\n` + src), key, admKey());
      const id = bot ? bot.id : "rb-" + name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 22) + "-" + Math.random().toString(36).slice(2, 6);
      const body = { action: bot ? "update" : "add", id, name, desc: $("#rb-desc", box).value, price, section: "automated", category: "", sub: "rules", key, entry, rules, rulesText: $("#rb-text", box).value };
      await admApi("/admin/bot", body); await loadCatalog(); toast(bot ? "Saved. Clients get the new rules the next time they start the bot." : "Bot created. It is live in Automated bots."); show("studio");
    } catch (e) { msg.textContent = e.message; }
  };
}
async function admStudio(box, show) {
  const mine = ITEMS.filter(isRuleBot), built = ITEMS.filter((i) => DIGIT_BOTS.includes(i.id));
  box.innerHTML = `<div class="form"><h2 style="margin-top:0">Bot Studio</h2><p class="note">Build automated digit bots from rules, change them any time, or delete them. Rule bots appear for clients in Automated bots and are sold like the others.</p>
    <div class="row"><select id="st-from" aria-label="Start from">${optList([["", "Start from a blank bot"], ["under-auto", "Start like the Under bot"], ["over-auto", "Start like the Over bot"], ["differs-auto", "Start like the Differs bot"], ["even-odd-auto", "Start like the Even/Odd bot"]], "")}</select><button class="btn" id="st-new" type="button">Build a new bot</button></div></div>
    <h3>Your rule bots</h3>${mine.length ? mine.map((i) => `<div class="form" style="margin:0 0 8px"><div class="row"><b style="flex:1;min-width:140px">${esc(i.name)}</b><span class="note">KSh ${esc(i.price)}${i.hidden ? " | HIDDEN" : ""}</span><button class="btn" data-ed="${esc(i.id)}" type="button">Change rules</button><button class="btn danger" data-del="${esc(i.id)}" type="button">Delete</button></div></div>`).join("") : `<p class="note">None yet. Build one above.</p>`}
    <h3>Ready-made digit bots</h3><p class="note">Their rules are built into the bot code and cannot be edited in place. Press "Copy as rule bot" to get an editable copy with similar rules, then delete the original if you do not want it.</p>
    ${built.map((i) => `<div class="form" style="margin:0 0 8px"><div class="row"><b style="flex:1;min-width:140px">${esc(i.name)}</b>${RULE_PRESETS[i.id] ? `<button class="btn ghost" data-copy="${esc(i.id)}" type="button">Copy as rule bot</button>` : ""}<button class="btn danger" data-del="${esc(i.id)}" type="button">${i.hidden ? "Deleted" : "Delete"}</button></div></div>`).join("")}`;
  $("#st-new", box).onclick = () => ruleEditor(box, show, null, RULE_PRESETS[$("#st-from", box).value] || DEFAULT_RULES, "");
  box.onclick = async (e) => {
    const b = e.target.closest("button[data-ed],button[data-del],button[data-copy]"); if (!b) return;
    try {
      if (b.dataset.copy) { const it = ITEMS.find((i) => i.id === b.dataset.copy); return ruleEditor(box, show, null, RULE_PRESETS[b.dataset.copy], ""), ($("#rb-name", box).value = it.name + " (my rules)"); }
      if (b.dataset.ed) { const it = ITEMS.find((i) => i.id === b.dataset.ed), d = await admApi("/admin/botrules?id=" + encodeURIComponent(it.id)); return ruleEditor(box, show, it, d.rules, d.text); }
      if (!confirm("Delete this bot? Clients who bought it lose access to it. Built-in bots are hidden from the store, not erased.")) return;
      await admApi("/admin/bot", { action: "delete", id: b.dataset.del }); await loadCatalog(); toast("Deleted."); show("studio");
    } catch (er) { toast(er.message); }
  };
}

async function admSettings(box) {
  const c = await (await fetch(CONFIG.payApi + "/config")).json(), h = await (await fetch(CONFIG.payApi + "/health")).json();
  box.innerHTML = `<div class="form"><h2 style="margin-top:0">Payments and contact</h2>
    <div class="field"><label for="s-pochi">Pochi la Biashara number</label><input id="s-pochi" value="${esc(c.pochi)}"></div>
    <div class="field"><label for="s-pp">PayPal email (empty = PayPal hidden)</label><input id="s-pp" type="email" value="${esc(c.paypal || "")}"></div>
    <div class="field"><label for="s-ua">USDT wallet address (empty = USDT hidden)</label><input id="s-ua" value="${esc(c.usdtAddress || "")}"></div>
    <div class="field"><label for="s-un">USDT network</label><input id="s-un" value="${esc(c.usdtNetwork || "TRC20")}" placeholder="TRC20"></div>
    <div class="field"><label for="s-rate">KSh per 1 US dollar (sets the dollar prices)</label><input id="s-rate" type="number" min="20" max="1000" step="0.5" value="${esc(c.usdRate || 130)}"></div>
    <div class="field"><label for="s-sig">Forex signals price (KSh for 1 week)</label><input id="s-sig" type="number" min="10" value="${esc(c.signalsPrice ?? SRV.signalsPrice)}"></div>
    <div class="field"><label for="s-ai">AI scanner pack price (KSh for 5 signals)</label><input id="s-ai" type="number" min="10" value="${esc(c.aiPrice ?? SRV.aiPrice)}"></div>
    <div class="field"><label for="s-wa">WhatsApp number</label><input id="s-wa" value="${esc(c.whatsapp)}"></div>
    <div class="field"><label for="s-mode">Payment options shown</label><select id="s-mode"><option value="auto">Automatic (prompt and Pochi once the prompt is live, else Pochi only)</option><option value="prompt">M-Pesa prompt and Pochi (client chooses)</option><option value="manual">Pochi only</option></select></div>
    <p class="note">${c.provider ? "The M-Pesa prompt is live (" + c.provider + ")." : "The M-Pesa prompt is NOT live yet. If you choose prompt now, clients who try it are told to use Pochi."}</p>
    <div class="row"><button class="btn" id="s-save" type="button">Save settings</button><span class="note" id="s-msg"></span></div></div>
    <div class="form"><h2 style="margin-top:0">System check</h2><p class="note">Server version ${h.version} | storage ${h.kv ? "OK" : "MISSING"} | admin key ${h.admin ? "OK" : "MISSING"} | bot keys ${h.botKeys ? "OK" : "MISSING"} | emails ${h.email ? "OK" : "not set"} | M-Pesa prompt: ${h.promptLive ? "LIVE (" + h.provider + ")" : "not live"}</p></div>`;
  $("#s-mode", box).value = c.mode || "auto";
  $("#s-save", box).onclick = async () => {
    try { await admApi("/admin/config", { paypal: $("#s-pp", box).value, usdtAddress: $("#s-ua", box).value, usdtNetwork: $("#s-un", box).value, usdRate: $("#s-rate", box).value, pochi: $("#s-pochi", box).value, whatsapp: $("#s-wa", box).value, payMode: $("#s-mode", box).value }); await admApi("/admin/prices", { prices: { signals: $("#s-sig", box).value, aiscan: $("#s-ai", box).value } }); await loadCatalog(); await loadConfig(); $("#s-msg", box).textContent = "Saved."; } catch (er) { $("#s-msg", box).textContent = er.message; }
  };
}

function viewSettings(main) {
  const theme = store.get("theme", "dark");
  main.append(el(`<section><h1>Settings</h1><div class="form"><h2 style="margin-top:0">Theme</h2>
   <div class="chips" id="themes">${["system", "light", "dark"].map((t) => `<button class="chip" data-theme="${t}" aria-pressed="${theme === t}">${t[0].toUpperCase() + t.slice(1)}</button>`).join("")}</div></div>
   <div class="form"><h2 style="margin-top:0">Account</h2>${me.in ? `<p class="note">Signed in as ${esc(me.email)}. Bots on this account: ${me.licenses.length}.</p><button class="btn ghost" id="lout">Log out</button>` : `<p class="note">Log in to see your bots and signals on any device.</p><button class="btn" id="lin">Log in or create account</button>`}</div>
   <div class="form"><h2 style="margin-top:0">This device</h2><p class="note">Clear removes the login and anything saved on this device. Bots you bought stay on your account.</p><button class="btn ghost" id="clear">Clear this device</button></div></section>`));
  main.onclick = (e) => {
    const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.theme) { store.set("theme", b.dataset.theme); applyTheme(); render(); }
    if (b.id === "lout") { logoutLocal(); render(); }
    if (b.id === "lin") authDialog(() => render());
    if (b.id === "clear") { store.del("owner"); sess.del("token"); sess.del("adm"); logoutLocal(); toast("Cleared."); render(); }
  };
}

function applyTheme() {
  const t = store.get("theme", "dark");
  if (t === "light" || t === "dark") document.documentElement.dataset.theme = t; else delete document.documentElement.dataset.theme;
}

const getJ = (p) => fetch(CONFIG.payApi + p, { signal: AbortSignal.timeout(7000) }).then((r) => r.json());
async function loadConfig() { try { const c = await getJ("/config"); Object.assign(SRV, { pochi: c.pochi, whatsapp: c.whatsapp, payMode: c.payMode, provider: c.provider, paypal: c.paypal || "", usdtAddress: c.usdtAddress || "", usdtNetwork: c.usdtNetwork || "TRC20", usdRate: c.usdRate || 130, country: c.country || "", currency: c.currency || null }); } catch {} }
function applyCatalog(c) {
  for (let i = ITEMS.length - 1; i >= 0; i--) if (ITEMS[i].extra && !(c.extra || []).some((x) => x.id === ITEMS[i].id)) ITEMS.splice(i, 1);
  for (const x of c.extra || []) if (!ITEMS.some((i) => i.id === x.id)) ITEMS.push({ ...x, extra: true, how: x.section === "forex" ? MT5_HOW : x.how });
  for (const it of ITEMS) { it.hidden = (c.hide || []).includes(it.id); const e = (c.edit || {})[it.id]; if (e) Object.assign(it, e); }
}
async function loadCatalog() {
  try { applyCatalog(await getJ("/catalog")); } catch {}
  try { const p = await getJ("/prices"); for (const it of ITEMS) if (Number.isFinite(p[it.id])) it.price = p[it.id]; if (Number.isFinite(p.signals)) SRV.signalsPrice = p.signals; if (Number.isFinite(p.engine)) SRV.enginePrice = p.engine; if (Number.isFinite(p.aiscan)) SRV.aiPrice = p.aiscan; } catch {}
}

captureOAuth(); applyTheme();
// Install as an app (Chrome shows its own prompt; this button opens it)
let installEvt = null;
const standalone = window.matchMedia("(display-mode: standalone)").matches || navigator.standalone;
window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); installEvt = e; if (!standalone) $("#installBtn").hidden = false; });
window.addEventListener("appinstalled", () => { installEvt = null; $("#installBtn").hidden = true; });
$("#installBtn").onclick = async () => { if (!installEvt) return; installEvt.prompt(); try { await installEvt.userChoice; } catch {} installEvt = null; $("#installBtn").hidden = true; };
if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});
$("#backBtn").onclick = goBack;
$("#nav").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; openDrawer(false); if (b.dataset.act === "ea") return eaPanel(); if (b.dataset.act === "ea2") return eaPanel("straddle-system"); if (b.dataset.market) enterMarket(b.dataset.market); else setTab(b.dataset.tab); };
$("#menuBtn").onclick = () => openDrawer(!$("#drawer").classList.contains("open"));
$("#drawX").onclick = $("#scrim").onclick = () => openDrawer(false);
$("#drawAcct").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; openDrawer(false); if (b.dataset.d === "in") authDialog(() => render()); else { logoutLocal(); render(); } };
document.addEventListener("keydown", (e) => { if (e.key === "Escape") openDrawer(false); });
$("#acctBtn").onclick = acctMenu;
// Hidden owner entrance 1: hold the footer for 3 seconds. Entrance 2: open the site with #admin on the end.
{
  const foot = $(".foot"); let lp = 0;
  foot.addEventListener("pointerdown", () => { clearTimeout(lp); lp = setTimeout(openAdmin, 3000); });
  for (const ev of ["pointerup", "pointerleave", "pointercancel"]) foot.addEventListener(ev, () => clearTimeout(lp));
  foot.addEventListener("contextmenu", (e) => e.preventDefault());
}
const checkAdminHash = () => { if (location.hash === "#admin") { history.replaceState(null, "", location.pathname + location.search); openAdmin(); } };
window.addEventListener("hashchange", checkAdminHash);
const h0 = location.hash.slice(1);
for (const m of ["binary", "forex"]) if (TABS[m].some(([id]) => id === h0) || (m === "binary" && h0 === "automated" && sess.get("token"))) { state.mode = state.mode || m; state.tab = h0; }
(async () => {
  const setup = Promise.allSettled([loadConfig(), loadCatalog(), refreshMe()]);
  await runBoot("TRADERSPRO254", ["Initializing workspace...", "Scanning markets...", "Connecting to live market...", "Loading bots..."], probeLive);
  await setup; state.booted = true; render(); checkAdminHash(); watchOrders(); if (/^#buy=engine/.test(location.hash)) { history.replaceState(null, "", location.pathname + location.search); buyFlow("engine"); }
})();
